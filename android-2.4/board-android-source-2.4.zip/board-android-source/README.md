# -board

A live home-server dashboard and home screen widget for [Scriptable](https://scriptable.app) on iOS.
The whole app is one file: `board_Blank.js`.

**iPhone app (work in progress):** a real app (Swift, with a home screen widget) to install for free with SideStore or
AltStore. Not built yet; see [`ios/README.md`](ios/README.md).

**Android:** a native version (Kotlin + Jetpack Compose) is in [`android/`](android/). Install
[`android/dist/board.apk`](android/dist/board.apk); the step-by-step guide is the
[Android user manual](board_User_Manual_Android.docx). See also [Android app](#android-app) below.

The full step-by-step guide is the [iOS user manual](board_User_Manual_iOS.docx) (Word document).

## Works with

-board needs your **server's IP or name** (Settings > Server). The **LIVE / OFFLINE** status shows whether anything
on the server answers: its web ports, the server system's own address, Glances and your service buttons.

**Monitoring** (CPU, RAM, drives, network, temperatures) comes from Glances and works on every server. It's optional:
turn it off in *Settings > Monitoring* and the Monitoring panel and widget gauges go away, and -board sends no requests
to Glances (the widget then shows your service buttons). The panel is folded away by default.

Reboot / Shut down depends on the system the server runs:

| Server | Reboot / Shut down |
| --- | --- |
| **ZimaOS** | ZimaOS login. Nothing to install |
| **Proxmox VE** | Proxmox API (port 8006) with your Proxmox login, e.g. `root@pam`. Nothing to install |
| **TrueNAS** (SCALE / Community Edition, CORE) | TrueNAS login, over the WebSocket JSON-RPC API on 25.04 and newer, the REST API on older versions. Nothing to install |
| **Unraid** | Unraid login (`root`); sends what Unraid's own Reboot / Shut down buttons send. Nothing to install |
| **Synology DSM** | DSM Web API (port 5000 / 5001) with an administrator account. Nothing to install |
| **OpenMediaVault** | OpenMediaVault's API with an administrator account (`admin`). Nothing to install |
| **Linux** (Debian, Ubuntu Server, Fedora ...) | A tiny helper service. Settings gives you a one-time setup command |

**Pick your server type** in *Settings > Server > Server type* (ZimaOS, Proxmox, TrueNAS, Unraid, Synology, OMV or Linux).
A new install has none picked, so there's no Reboot / Shut down menu until you choose one. Settings then shows
only that system's options.

Accounts with two-factor login can't be used for Reboot / Shut down; make a separate administrator account for -board.
Logins are stored in the iOS Keychain. Enter a login ahead of time with **Enter login** under the server type in Settings
(it is checked against the server before it is saved), or wait to be asked the first time you use Reboot / Shut down.

## Several servers

Swipe the server name left or right to switch servers. The dots under the name show how many there are and which
one is on screen. Swipe left past the last one (or tap **+**) to add a server: it asks the same as Settings, in the same
order (name, server type, server address, and the login if the type uses one, checked before the server is added).

- Each server has its **own settings window** (the gear, titled with the server's name): server address and type,
  logins, Monitoring / Glances, and its own buttons, stacks and layout.
- Theme & look, the widget's refresh and rows, button options and export / import are **shared by all servers**
  (shown under "Shared by all servers" in every settings window).
- A **widget** shows one server: long-press it, **Edit Widget**, and type the server's name or number (`1`, `2` ...)
  under **Parameter**. Empty = the first server. Tapping the widget opens the dashboard on that server.
- **Delete server** is at the very bottom of each server's settings and asks to confirm first (your only server can't be deleted).
  Export / import covers every server.

Existing setups become server 1 with everything kept, including saved logins.

## 1. Run Glances on the server (optional, for Monitoring)

Docker (any OS):

```sh
docker run -d --name glances --restart unless-stopped -p 61208:61208 --pid host \
  -e GLANCES_OPT="-w" -v /var/run/docker.sock:/var/run/docker.sock:ro nicolargo/glances
```

Without Docker (Debian, Ubuntu, Proxmox host): `sudo apt install glances`, then run `glances -w`
(for example as a systemd service). Distro packages are often Glances 3.x, so pick **API version 3** in Settings.
*Test connection* tells you if the other API version answers.

## 2. Install the script

1. In Scriptable tap **+**, paste `board_Blank.js` and give it a name.
2. Run it. Settings opens: under **Server**, give it a name, pick your **server type**, and type the **server address**:
   an http / https list plus the IP or name, with a port only if it isn't the usual one for that type
   (e.g. `192.168.1.10` or `192.168.1.10:90`). This one address is used for LIVE / OFFLINE, Reboot / Shut down and logins.
   Tap **Enter login** if the type uses one. Under **Monitoring**, leave the Glances address empty if Glances runs on
   the same server on port 61208, or turn Monitoring off if you don't use Glances. Tap **Test connection**, then **Save**.
3. Add a Scriptable widget to your home screen and pick this script.

## Looks

*Settings > Theme & look* has two optional extras, both off by default:

- **Style**: *Classic* (the plain -board look) or *Liquid Glass* (iOS 26 style glass cards with a bright rim,
  a third background glow, springy animation on presses, menus, sheets and drags, and glass rings and pills on the widget).
  The change previews live behind the Settings sheet.
- **Startup animation**: a short animated -board logo when the dashboard opens (tap to skip). Works with either style.

Themes, accent colours, glow, corners, font and button size work with both styles.

## Reboot / Shut down per server type

- **ZimaOS**: you're asked for your ZimaOS login the first time; it's saved in the iOS Keychain.
- **TrueNAS**: your admin login (`truenas_admin`, or `root` on older versions). Use plain http on your home network or VPN,
  or https with a certificate the iPhone trusts (TrueNAS's own self-signed certificate doesn't work for its WebSocket API).
- **Unraid**: `root` and your password. If Unraid redirects to an `https://...myunraid.net` address, -board tells you to use that as the server address.
- **Synology**: an administrator account without two-factor login. Pick https in the server address and port 5001 is used.
- **OpenMediaVault**: an administrator account, `admin` by default.
- **Proxmox**: you're asked for your Proxmox login (`root` or `root@pam`; any user with the `Sys.PowerMgmt` permission works).
  Accounts with two-factor login can't be used. In a cluster, enter the node name in Settings (otherwise it's found automatically).
- **Linux**: tap **Create key & copy setup command**, SSH into the server, paste and press Enter. It asks for sudo once and:
  - installs `/usr/local/bin/board-power` (one Python 3 file, standard library only),
  - stores the random secret key in `/etc/board-power.key` (readable by root only),
  - starts the `board-power` systemd service on port 61209 and opens that port in ufw / firewalld if they're active.

  The helper only answers `/health`, `/reboot` and `/shutdown`, and only with the right key. Keep it on your LAN or VPN.
  To remove it:

  ```sh
  sudo systemctl disable --now board-power
  sudo rm /usr/local/bin/board-power /etc/board-power.key /etc/systemd/system/board-power.service
  ```

## Android app

[`android/`](android/) is a native Android port of the script (Kotlin, Jetpack Compose, a Jetpack Glance home screen widget)
with the same features, logic and look: several servers, LIVE / OFFLINE, Glances monitoring with the enlarged cards
(history graph, per-core load, top processes, drives, temperatures), service buttons with up/down dots, stacks,
drag to rearrange, Widget layout, Reboot / Shut down for ZimaOS, Proxmox, TrueNAS, Unraid, Synology, OpenMediaVault
and Linux (the same helper setup command), every theme and accent, Classic and Liquid Glass, the startup animation,
and Settings with Test connection.

Full guide: the [Android user manual](board_User_Manual_Android.docx) (Word document).

### New in Android 2.4

- **App Store install fixed**: OkHttp sends text bodies as `application/yaml; charset=utf-8`, and ZimaOS's install
  (`POST /v2/app_management/compose`) answers 415 to anything but exactly `application/yaml`. `Net.request` has
  `exactType` (body sent as bytes, no charset); `Zima.install` uses it, and tries JSON once if ZimaOS still says 415.
  Test in `NetTest`.
- **Store list**: icons that don't load (none, SVG) fall back to `AutoLogo.find`; apps with the same title show their
  author.

### New in Android 2.3

- **ZimaOS App Store** (`Zima.store` / `install` / `uninstall`, `ZimaStoreDialog`): + > App Store lists the store
  (`GET /v2/app_management/apps`, parsed by `Zima.parseStore`), with search and category chips. Install fetches the
  app's compose file (`/apps/{id}/compose`, YAML) and posts it to `/v2/app_management/compose`, as ZimaOS's own App
  Store does; `BoardVM.zInstall` then checks the app list every 5 s (up to 10 min) and adds a button once the app is
  running. Hold menu: Uninstall (`DELETE /compose/{id}?delete_config_folder=`), optional data removal, deletes the
  button. Tests in `ZimaTest`.

### New in Android 2.2

- **Pick from gets the same logo as Auto** (`AutoLogo.kt`): every "Pick from ..." (ZimaOS too) and the Auto chip in
  the add / edit form use `AutoLogo.find`. A dashboard-icons logo (no background) comes first; the server's own icon
  (TrueNAS / ZimaOS store icons, often with a background, sometimes SVG that Android can't show) only when there's none.
  Before, Pick from put the server's icon first, tried the image name before the button name, and checked every
  logo at once, so some checks timed out.
- **Loose matching**: the collection's file list (`tree.json`, plus the aliases in `metadata.json`) is downloaded once a
  week and kept as `board-logo-index.json`; names are compared without spaces, dashes or capitals and with common
  endings removed (-server, -media-server, -ce, -app ...), then the first word. Without the list, the likeliest six
  names are checked one by one. At most 4 lookups run at once. Tests in `AutoLogoTest`.

### New in Android 2.1

- **Trust on first use for https** (`Certs.kt`): requests that carry logins (Glances, server logins, Reboot / Shut down,
  containers) no longer accept any certificate. A certificate Android trusts for the name is accepted as usual;
  any other (self-signed) one is remembered per address and port the first time (`CertStore`), and a different one
  later stops the connection (`CertChanged`) and the app asks "Certificate changed. Trust the new one?". Cancel is
  remembered until the app restarts. The up / down and LIVE checks send no logins and keep accepting any certificate.
  Settings > This server > Forget saved certificates. Fingerprints are not exported.
- **Proxmox Force stop** in the hold menu (`Ctrs.action(..., "kill")` -> `status/stop`), tap twice.
- **Pick from**: Select all / Select none, running containers first, repeated names get " 2", " 3" (`Store.uniqueName`).
- **Unencrypted logins said out loud**: if EncryptedSharedPreferences can't open, `Secrets.plain` is set; Settings >
  About says so and the dashboard tells you once.
- Fixes: a refused TrueNAS login gives the "Enter login again" button (`tnErr` sets `fix`); Pick its container shows
  the setup buttons (`CtrProblem`); the + popup can't stick on "Adding..."; Synology sid and Unraid cookie + csrf are
  kept 10 minutes and renewed once when refused (106 / 107 / 119, or 401 / 403 / redirect to login); helper v3 reads
  port ranges (`0.0.0.0:6881-6889->...`); `tnRpc`'s cross-thread flags are `@Volatile`. New tests: `CertTest`,
  `CtrTest.repeatedNamesGetNumbers`.

### New in Android 2.0

- **Pick from your server** on every server type, like *Pick from ZimaOS apps*: the + popup shows *Pick from
  Proxmox*, *Pick from TrueNAS apps* or *Pick from <type> containers* (`CtrAddDialog` in `ui/Dialogs.kt`). It lists
  the server's containers / apps / guests (the same `Ctrs.list` as the hold menu), greys out ones that already have a
  button, and adds the picked ones with `BoardVM.addCtrButtons` -> `Store.addCtrButtons`:
  - address: the server's (follows it and the failover address), or for Proxmox the guest's first IPv4 address;
  - port: `Ctrs.webPort`, the lowest published port that isn't a known non-web port (DNS, discovery, torrents, ...);
  - logo: TrueNAS's app icon, else a dashboard-icons logo named after the image or the name (`Ctrs.logoSlugs`);
  - `ctr` set to the container, so Start / Stop / Restart / Logs work at once.
- Missing login / helper / Monitoring shows the same setup buttons as the hold menu (`CtrProblem`).
- `Ctr` gained `image` and `icon`. New tests in `CtrTest.pickFromServer`.

### New in Android 1.9

- **A setup button instead of a red error in the hold menu**: when the container controls can't work because
  something isn't set up, `CtrErr.fix` says what ("login", "loginAgain", "helper", "helperAgain", "helperOld",
  "monitoring") and the menu shows a button (Add Proxmox login, Set up the helper, Update the helper, Turn on
  Monitoring ...). `BoardVM.openSetup` opens Settings > This server, opens the login form when a login is needed, and
  scrolls to the login / helper part or to Monitoring (`SettingsForm.focus`, `BringIntoViewRequester`). Errors that
  setup can't fix (no answer) keep their text and get Try again.

### New in Android 1.8

- **Start / Stop / Restart / Logs on every server type** (hold a button), not only ZimaOS. `Ctr.kt` has one driver per
  type: Proxmox VE (LXC containers and VMs via `/cluster/resources` and `status/start|shutdown|reboot`; Logs = the
  guest's recent tasks and the last task log, since Proxmox keeps no console log), TrueNAS 24.10+ (`app.query`,
  `app.start` / `app.stop` / `app.redeploy`; logs through the `app.container_log_follow` subscription, 25.04+),
  Synology DSM (`SYNO.Docker.Container`, `SYNO.Docker.Container.Log`), Unraid (list from Glances' containers plugin,
  commands through `dynamix.docker.manager/include/Events.php`, logs from the ttyd log window), OpenMediaVault and
  Linux (Docker / Podman through the helper).
- **Helper v2** (`assets/helper.py`): adds `GET /containers`, `GET /containers/NAME/logs?lines=N` and
  `POST /containers/NAME/start|stop|restart` (names checked against a strict pattern, key required as before).
  A helper set up before 1.8 answers 404 and the app asks to run the setup command again. OpenMediaVault gets a
  "Containers helper" setup button in Settings > This server.
- **Which container**: picked by hand (saved as `ctr` on the button), else the guest at the button's address
  (Proxmox), else the only one publishing the button's port on the server, else the only one with the button's
  name. "Pick its container" in the menu when nothing matches. Unit tests in `CtrTest`.
- Not tried against real Proxmox / TrueNAS / Synology / Unraid servers yet: the drivers follow those systems' APIs.

### New in Android 1.7

- **Save and Cancel in Settings**: Done is renamed Save; a new Cancel button on the opposite side puts back the
  settings, the server name and the Glances password as they were when Settings opened (`BoardVM.cancelSettings`).
  Actions with their own button (checked login, Restore, Clear logo cache, Reset layout, Import) stay done.
  Back to the list of pages is now the "‹ All settings" chip under the header.
- **No closing by tapping outside**: a tap outside Settings or any popup no longer closes it (`Modal` in
  `ui/Components.kt`); popups close with their own buttons, or Back. The widget's server picker got a Cancel button.

### New in Android 1.6

- **Old figures no longer look live**: when Glances stops answering (or hasn't answered for 3 refresh intervals,
  at least 15 s), the Monitoring cards keep the last figures but dim them, and the bar shows "updated 40 s ago"
  (above the cards when the panel is kept open). NO DATA is only shown before the first answer.
- **Rounded font**: the *Sans* option was Android's sans-serif, the same as System. It is now *Rounded* and uses
  Nunito (variable font in `app/src/main/res/font`, SIL Open Font License, see `android/licenses/Nunito-OFL.txt`).
- Glances errors: an HTTP error (e.g. 401 for a wrong password) is now reported as such instead of "not JSON".

### New in Android 1.5

- **Press feedback in the Classic style**: anything you tap shrinks slightly and dims while pressed (Liquid Glass keeps
  its springy squish).
- **Glances no longer queues behind the checks**: OkHttp allows only 5 requests at a time to one server by default, so
  Glances waited behind up / down and LIVE checks of dead services (each up to its timeout), causing NO DATA flicker
  and a slow LIVE pill. The checks now have their own request queue, both queues allow far more requests per server
  (24 / 32), and Glances is asked first. While Glances answers on the main address, the dashboard and the widget count
  that as LIVE and send no LIVE checks at all.

### New in Android 1.4

- **Test connection** is at the bottom of *Settings > This server*, right after the server and Monitoring details,
  so you reach it naturally once you've typed them.

### New in Android 1.3

- **Settings in pages**: This server, Widget, Buttons, Appearance, Backup and About. Failed connection checks come with one-tap fixes (Edit address, Use API version 3, Turn Monitoring off, Switch Failover off,
  Enter login again, Copy setup command).
- **Saved as you go**: every setting is saved as soon as it changes. Only a value that can't be saved yet (an empty
  address, a letter in a number field) is held back, and closing then asks **Discard changes?** The add / edit popups ask
  the same. Rotating the phone, switching dark mode or changing the font size no longer closes Settings or a popup.
- **Safe saving**: `board-data.json` is never overwritten in place. Each save goes to a `.tmp` file (flushed to disk),
  the current file is kept as `.bak`, then the new file is renamed into place. A damaged file is never treated as a
  fresh install: the backup is used, the damaged file is kept aside, and a message says so. (The Scriptable script
  does the same.)
- **Pull to refresh** on the dashboard, and **haptic feedback** when lifting and dropping a button and confirming deletes.
- **Folded Monitoring bar shows one line**: `CPU 12% · RAM 48% · DISK 61% · ↓2.1 MB/s`.
- **Reboot follow-through**: the LIVE pill shows **REBOOTING…** and the server is watched until it answers again
  ("Back online after 1 m 12 s").
- **Widget snapshot**: leaving the dashboard hands its latest figures to the widgets of that server, so they're fresh
  with no extra requests.

### ZimaOS integration (Android, ZimaOS servers only)

Only on servers whose type is **ZimaOS**, and only with the ZimaOS login saved (*Settings > Server > Enter login*).
Other server types don't show any of this.

- **Start, stop and restart apps:** hold a button that points at a ZimaOS app. The menu shows whether it's running and
  gives **Start** or **Stop** (Stop asks for a second tap), plus **Restart**, **Logs**, and **Update** when the App Store
  has a newer version. Buttons are linked to apps automatically by port (a button on the server's address and the port
  of exactly one app), so Jellyfin, Immich and the others work with no setup. Apps are checked once a minute.
- **App logs:** the last 300 lines in a scrollable popup with a **Refresh** button.
- **App updates:** when the App Store has newer versions, a **↑ 2 updates** chip appears next to *Widget layout*.
  It opens a list with an **Update** button per app. With nothing to update it stays hidden.
- **Add apps from ZimaOS:** the **+** popup has **Pick from ZimaOS apps** (with the login saved), which lists everything installed. Apps that
  already have a button are greyed out; the rest are added with their real address and icon.
- **CPU power draw:** the enlarged CPU card shows watts (the same figure ZimaOS shows; it needs a CPU with Intel RAPL
  and appears from the second reading on). If Glances has no CPU temperature, ZimaOS's is used.
- **Drive health:** the enlarged storage card shows each drive's health check (**OK** / **FAILING**) and temperature
  from ZimaOS, and drives without a Glances temperature get ZimaOS's, so no `drivetemp` module is needed.

These work the same way as in the Scriptable script's ZimaOS integration, and buttons added from ZimaOS stay linked
when settings are exported from one to the other.

**Install:** copy [`android/dist/board.apk`](android/dist/board.apk) to the phone and open it (allow installing from
that source when asked). Android 8.0 or newer. The APK is signed with the project's development key
(`android/keystore/board-dev.jks`), so it installs directly but isn't from the Play Store, and every build from this
source installs as an update over the last one.

**From 1.2 (once):** 1.2 was signed with a different key, so 1.3 and newer can't install over it. In 1.2 use
*Settings > Data > Export settings* and keep the copied text, uninstall 1.2, install the new version, then *Settings > Backup >
Import settings*. Logins and the widget have to be set up again.

Differences from the iPhone version:
- **Settings move between the two.** *Export settings* (Android: *Settings > Backup*) on either one copies the same format, and *Import*
  on the other reads it (all servers, buttons, stacks and layout; passwords stay on each phone).
- Logins are stored encrypted on the phone (Android Keystore) instead of the iOS Keychain.
- **Widget:** add it from the home screen's widget list. It asks which server to show (the Scriptable Parameter);
  long-press it and pick *Reconfigure* to change it on Android 12 and newer. Resize it for the small, medium or
  large layout. Android refreshes widgets at most every 15 minutes in the background; when you leave the dashboard,
  widgets showing that server take its latest figures straight away (no extra requests).
- Self-signed https certificates are accepted for every request (as the script does for the server systems).
- The *Rounded* font option uses the bundled Nunito font (SF Pro Rounded is Apple-only). The widget uses the system font.

**Build it yourself:** with JDK 17+ and the Android SDK (platform 35), run `./gradlew assembleRelease` in `android/`;
the APK is `app/build/outputs/apk/release/app-release.apk`. `./gradlew testReleaseUnitTest` runs the unit tests.

## iPhone app (SideStore / AltStore)

> **Work in progress:** not compiled or tested yet, so there is no build to install. See [`ios/README.md`](ios/README.md).

[`ios/`](ios/) is a native iPhone app version of the script. Its dashboard is the script's own page (so it looks and
behaves exactly the same), backed by a Swift port of the script's logic, plus a WidgetKit home screen widget. It needs
no Scriptable and no paid Apple account: you install it with SideStore or AltStore, which sign it with your own free
Apple ID.

GitHub Actions builds it on every change ([workflow](.github/workflows/ios.yml)) and publishes the latest build to the
[`ios-latest` release](../../releases/tag/ios-latest), together with a SideStore / AltStore source.

**Install:**
1. Install **SideStore** (or **AltStore**) on the iPhone, following its own setup guide (it needs a computer once, for
   the first install).
2. In SideStore, open **Sources**, tap **+** and add this source:
   `https://github.com/borissiivanov1-crypto/-board/releases/download/ios-latest/apps.json`
3. Open the source and install **-board**. On iOS 16 and newer, turn on **Developer Mode** when iOS asks
   (Settings > Privacy & Security > Developer Mode) and restart.
4. Open -board: Settings opens by itself on first run, as in the script. To bring your setup over from Scriptable,
   use *Settings > Data > Export settings* there and *Import settings* in the app.
5. Add the widget: hold the home screen > **Edit** > **Add Widget** > **-board**. Hold it > **Edit Widget** to pick the
   server (name or number), as with the Scriptable widget's Parameter.

**Keep it working:** with a free Apple ID an app signed this way stops opening after 7 days unless it's refreshed;
SideStore refreshes it from the phone (open SideStore and tap **Refresh** at least once a week). New builds of -board
show up as updates in SideStore. A free Apple ID allows only a few sideloaded apps at a time.

The app needs iOS 17 or newer.
