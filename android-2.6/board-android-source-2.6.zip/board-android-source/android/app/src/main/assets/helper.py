#!/usr/bin/env python3
# board-power: lets the -board app reboot or shut down this server, and start / stop / restart its
# Docker or Podman containers and show their logs.
# Remove it with: systemctl disable --now board-power; rm /usr/local/bin/board-power /etc/board-power.key /etc/systemd/system/board-power.service
import hmac, json, os, re, shutil, socket, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

VERSION = 3
KEY = open("/etc/board-power.key").read().strip()
PORT = int(os.environ.get("BOARD_POWER_PORT", "61209"))
CMDS = {"/reboot": ["systemctl", "reboot"], "/shutdown": ["systemctl", "poweroff"]}
NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
ACTIONS = ("start", "stop", "restart")


class Err(Exception):
    pass


def engine():
    for e in ("docker", "podman"):
        p = shutil.which(e)
        if p:
            return p
    return None


def need_engine():
    e = engine()
    if not e:
        raise Err("Docker (or Podman) isn't installed on this server")
    return e


def containers():
    e = need_engine()
    r = subprocess.run([e, "ps", "-a", "--no-trunc", "--format", "{{json .}}"], capture_output=True, text=True, timeout=30)
    if r.returncode:
        raise Err(r.stderr.strip() or "docker ps failed")
    out = []
    for line in r.stdout.splitlines():
        try:
            j = json.loads(line)
        except ValueError:
            continue
        name = j.get("Names") or ""
        if isinstance(name, list):
            name = name[0] if name else ""
        name = name.split(",")[0].lstrip("/")
        ports = j.get("Ports")
        if isinstance(ports, list):  # podman
            pl = [str(p.get("host_port")) for p in ports if isinstance(p, dict) and p.get("host_port")]
        else:
            # "0.0.0.0:8080->80/tcp" and ranges "0.0.0.0:6881-6889->6881-6889/tcp" (the range's first port)
            pl = re.findall(r":(\d+)(?:-\d+)?->", ports or "")
        out.append({
            "id": name, "name": name, "state": str(j.get("State") or "").lower(),
            "status": j.get("Status") or "", "image": j.get("Image") or "", "ports": sorted(set(pl)),
        })
    return out


def name_of(part):
    n = unquote(part)
    if not NAME.match(n):
        raise Err("not a container name")
    return n


class Handler(BaseHTTPRequestHandler):
    def reply(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authed(self):
        given = self.headers.get("Authorization", "").encode()
        if hmac.compare_digest(given, ("Bearer " + KEY).encode()):
            return True
        time.sleep(1)  # slows down guessing
        self.reply(401, {"ok": False, "error": "wrong key"})
        return False

    def do_GET(self):
        u = urlsplit(self.path)
        parts = [p for p in u.path.split("/") if p]
        if u.path == "/health":
            if self.authed():
                e = engine()
                self.reply(200, {"ok": True, "host": socket.gethostname(), "version": VERSION, "containers": os.path.basename(e) if e else None})
            return
        if parts[:1] != ["containers"] or len(parts) not in (1, 3) or (len(parts) == 3 and parts[2] != "logs"):
            return self.reply(404, {"ok": False})
        if not self.authed():
            return
        try:
            if len(parts) == 1:
                return self.reply(200, {"ok": True, "containers": containers()})
            name = name_of(parts[1])
            try:
                lines = max(1, min(2000, int(parse_qs(u.query).get("lines", ["300"])[0])))
            except ValueError:
                lines = 300
            r = subprocess.run([need_engine(), "logs", "--tail", str(lines), name], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            text = r.stdout.decode("utf-8", "replace")
            if r.returncode:
                raise Err(text.strip() or "docker logs failed")
            self.reply(200, {"ok": True, "text": text})
        except Err as e:
            self.reply(200, {"ok": False, "error": str(e)})
        except subprocess.TimeoutExpired:
            self.reply(200, {"ok": False, "error": "the server took too long to answer"})

    def do_POST(self):
        u = urlsplit(self.path)
        cmd = CMDS.get(u.path)
        if cmd:
            if self.authed():
                self.reply(200, {"ok": True})
                threading.Timer(1.0, subprocess.run, [cmd]).start()
            return
        parts = [p for p in u.path.split("/") if p]
        if len(parts) != 3 or parts[0] != "containers" or parts[2] not in ACTIONS:
            return self.reply(404, {"ok": False})
        if not self.authed():
            return
        try:
            r = subprocess.run([need_engine(), parts[2], name_of(parts[1])], capture_output=True, text=True, timeout=110)
            if r.returncode:
                raise Err(r.stderr.strip() or "docker %s failed" % parts[2])
            self.reply(200, {"ok": True})
        except Err as e:
            self.reply(200, {"ok": False, "error": str(e)})
        except subprocess.TimeoutExpired:
            self.reply(200, {"ok": False, "error": "the container took too long to %s" % parts[2]})

    def log_message(self, *args):
        pass


ThreadingHTTPServer(("", PORT), Handler).serve_forever()
