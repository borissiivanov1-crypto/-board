package app.board

import android.content.Context
import org.json.JSONObject

/**
 * What the dashboard last saw for a server, saved when you leave the dashboard. A widget showing that server
 * then draws these figures straight away, without asking the server again.
 */
data class WidgetSnap(
    val at: Long,
    val key: String,
    val reach: Boolean,
    val glancesOk: Boolean,
    val stats: Stats?,
    val up: Map<String, Boolean>,
) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("at", at).put("key", key).put("reach", reach).put("glancesOk", glancesOk)
        stats?.let { s ->
            val so = JSONObject().put("cpu", s.cpu).put("ram", s.ram).put("down", s.net.down).put("up", s.net.up)
            s.storage?.let { st -> so.put("storage", JSONObject().put("percent", st.percent).put("used", st.used).put("size", st.size).put("free", st.free).put("count", st.count)) }
            o.put("stats", so)
        }
        o.put("svc", JSONObject().also { j -> up.forEach { (k, v) -> j.put(k, v) } })
        return o
    }

    companion object {
        // a snapshot younger than this is used as it is; an older one makes the widget ask the server itself
        const val FRESH_MS = 3 * 60 * 1000L

        // the settings that change what the widget asks for: a snapshot taken with others is not used
        fun keyOf(s: Settings) = listOf(serverUrlOf(s), s.platform, s.monitoring, s.baseUrl, s.apiVersion, s.failover, s.failoverHost, s.diskMounts, s.maxDisks, s.networkInterface).joinToString("|")

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("board-widgets", Context.MODE_PRIVATE)

        fun save(ctx: Context, sid: String, snap: WidgetSnap) {
            prefs(ctx).edit().putString("snap:$sid", snap.toJson().toString()).apply()
        }

        fun forget(ctx: Context, sid: String) { prefs(ctx).edit().remove("snap:$sid").apply() }

        fun fromJson(o: JSONObject): WidgetSnap {
            val stats = o.optJSONObject("stats")?.let { so ->
                val st = so.optJSONObject("storage")?.let { Storage(it.optDouble("percent"), it.optDouble("used"), it.optDouble("size"), it.optDouble("free"), it.optInt("count")) }
                Stats(so.optDouble("cpu"), so.optDouble("ram"), emptyList(), st, NetRate(so.optDouble("down"), so.optDouble("up")))
            }
            val svc = o.optJSONObject("svc") ?: JSONObject()
            return WidgetSnap(o.optLong("at"), o.optString("key"), o.optBoolean("reach"), o.optBoolean("glancesOk"), stats, svc.keys().asSequence().associateWith { svc.optBoolean(it) })
        }

        // the server's snapshot if it's recent and was taken with the same settings, else null
        fun fresh(ctx: Context, sid: String, s: Settings): WidgetSnap? {
            val raw = prefs(ctx).getString("snap:$sid", null) ?: return null
            val snap = try { fromJson(JSONObject(raw)) } catch (e: Exception) { return null }
            val age = System.currentTimeMillis() - snap.at
            return if (age in 0 until FRESH_MS && snap.key == keyOf(s)) snap else null
        }
    }
}
