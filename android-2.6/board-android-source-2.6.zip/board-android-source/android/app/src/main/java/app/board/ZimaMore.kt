package app.board

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

// ---------- More of ZimaOS (2.5): the ZimaOS panel ----------
// System, storage, USB, shares, network drives, remote access (ZeroTier), notifications, app sources, app settings,
// ZimaOS modules and an app's details / compose file. These are the CasaOS services ZimaOS is built on
// (casaos, local-storage, user-service, app-management), read from their open-source code. Each part is asked on its
// own: one that this ZimaOS doesn't have (HTTP 404) just shows "not offered" and the rest still work.

data class ZNet(val name: String, val state: String, val sent: Double, val recv: Double)
data class ZInfo(
    val version: String = "", val deviceName: String = "", val model: String = "", val arch: String = "",
    val cpuPct: Double? = null, val cores: Int = 0, val cpuKind: String = "",
    val memTotal: Double = 0.0, val memUsed: Double = 0.0, val memPct: Double? = null,
    val nets: List<ZNet> = emptyList(), val extra: List<Pair<String, String>> = emptyList(),
)
data class ZVolume(val label: String, val mount: String, val path: String, val fs: String, val size: Double, val used: Double, val avail: Double, val disk: String)
data class ZPool(val mount: String, val fs: String, val count: Int)
data class ZUsbPart(val name: String, val mount: String, val size: Double, val avail: Double)
data class ZUsb(val name: String, val model: String, val size: Double, val parts: List<ZUsbPart>)
data class ZShare(val id: String, val path: String, val anonymous: Boolean, val name: String = "")
data class ZConn(val id: String, val host: String, val port: String, val user: String, val mount: String)
data class ZEvent(val uuid: String, val source: String, val name: String, val title: String, val message: String, val time: Long, val ysk: Boolean = false, val progress: Double? = null)
data class ZZt(val id: String, val name: String, val status: String) { val online get() = status.equals("online", true) || status.equals("ok", true) }
data class ZHealth(val running: List<String>, val stopped: List<String>)
data class ZSource(val id: String, val url: String)
data class ZGlobal(val key: String, val value: String, val desc: String)
data class ZModule(val name: String, val title: String, val icon: String, val entry: String)
data class ZCtrInfo(val name: String, val image: String, val state: String, val health: String)
// ZimaOS 1.8 storage (/v2/local_storage): a storage (system, raid, disk, usb) and the drives it is on
data class ZDisk(val name: String, val model: String, val size: Double, val healthy: Boolean, val missing: Boolean, val temp: Double?, val hours: Int?)
data class ZStorage(
    val name: String, val dir: String, val kind: String, val size: Double, val used: Double,
    val health: String,               // ok, busy, warn, bad or "" (unknown)
    val state: String = "", val level: Int? = null, val progress: Double? = null, val drives: List<ZDisk> = emptyList(),
)
// ZimaOS updates (/v2/installer)
data class ZOta(val current: String, val latest: String, val notes: String, val important: Boolean, val status: String, val beta: Boolean?, val notice: String) {
    val installing get() = status.equals("installing", true)
    val failed get() = status.equals("installError", true)
    val available get() = notice.endsWith("-update") && notice != "no-update" ||
        (latest.isNotEmpty() && current.isNotEmpty() && latest.trimStart('v', 'V') != current.trimStart('v', 'V') && notice != "no-update")
}
// An app's compose file and its version (ZimaOS 1.8 checks the version when saving)
data class ZCompose(val text: String, val etag: String, val v2: Boolean)
data class ZAppDetail(
    val status: String, val update: Boolean, val main: String, val containers: List<ZCtrInfo>,
    val ports: List<String>, val folders: List<String>, val env: List<Pair<String, String>>, val images: List<String>,
)

object ZimaMore {
    const val NOT_OFFERED = "This ZimaOS doesn't offer this."

    private fun enc(x: String) = URLEncoder.encode(x, "UTF-8").replace("+", "%20")
    private fun num(x: Any?) = Zima.numOf(x)

    // one call; HTTP 404 / 405 become NOT_OFFERED
    private suspend fun get(s: Settings, path: String, method: String = "GET", body: String? = null, timeout: Double = 12.0,
                            headers: Map<String, String> = emptyMap(), exactType: Boolean = false, dropOk: Boolean = false): Any? {
        val r = Zima.call(s, path, method, body, timeout = timeout, headers = headers, exactType = exactType, dropOk = dropOk)
        if (r != null && (r.code == 404 || r.code == 405)) throw ZimaErr(NOT_OFFERED)
        return Zima.data(r)
    }
    private suspend fun opt(s: Settings, path: String): Any? = try { get(s, path, timeout = 8.0) } catch (e: Exception) {
        if (e is kotlinx.coroutines.CancellationException) throw e
        if (e is ZimaErr && e.auth) throw e
        null
    }

    private fun arrOf(d: Any?, vararg keys: String): JSONArray = when (d) {
        is JSONArray -> d
        is JSONObject -> keys.firstNotNullOfOrNull { d.optJSONArray(it) } ?: JSONArray()
        is String -> try { JSONArray(d) } catch (e: Exception) { JSONArray() }
        else -> JSONArray()
    }
    private fun str(o: JSONObject, vararg k: String) = k.firstNotNullOfOrNull { key -> o.opt(key)?.takeIf { it != JSONObject.NULL }?.toString()?.trim()?.takeIf { it.isNotEmpty() } } ?: ""

    // ---------- System ----------
    fun parseUtil(d: Any?, into: ZInfo): ZInfo {
        val o = d as? JSONObject ?: return into
        val cpu = o.optJSONObject("cpu")
        val mem = o.optJSONObject("mem")
        val nets = arrOf(o.opt("net")).objs().map { n ->
            ZNet(n.optString("name"), n.optString("state"), num(n.opt("bytesSent")) ?: 0.0, num(n.opt("bytesRecv")) ?: 0.0)
        }.filter { it.name.isNotEmpty() }
        return into.copy(
            cpuPct = num(cpu?.opt("percent")), cores = (num(cpu?.opt("num")) ?: 0.0).toInt(), cpuKind = cpu?.optString("model").orEmpty(),
            memTotal = num(mem?.opt("total")) ?: 0.0, memUsed = num(mem?.opt("used")) ?: 0.0, memPct = num(mem?.opt("usedPercent")),
            nets = nets,
        )
    }

    // /v1/sys/version: { current_version, need_update, version: {...} } or a plain string
    fun parseVersion(d: Any?): String = when (d) {
        is String -> d.trim()
        is JSONObject -> str(d, "current_version", "version_name").ifEmpty { d.optJSONObject("version")?.let { str(it, "version") } ?: str(d, "version") }
        else -> ""
    }

    // ZimaOS's own device info: name, model and whatever else it sends that is short and readable
    fun parseDevice(d: Any?, into: ZInfo): ZInfo {
        val o = d as? JSONObject ?: return into
        // left out: what is shown on its own line already, ids and pictures
        val skip = setOf("device_name", "name", "hash", "device_image_path", "image", "icon", "token", "password", "arch", "os_version",
            "version", "device_model", "model", "device_code", "serial", "serial_number", "uuid", "id")
        val extra = o.keys().asSequence().filter { it !in skip && !it.startsWith("can_") }.mapNotNull { k ->
            val v = o.opt(k)
            if (v is JSONObject || v is JSONArray || v == null || v == JSONObject.NULL) return@mapNotNull null
            val t = if (v is Boolean) (if (v) "Yes" else "No") else v.toString().trim()
            if (t.isEmpty() || t.length > 60) null else k.replace('_', ' ').replaceFirstChar { it.uppercase() } to t
        }.take(12).toList()
        return into.copy(
            deviceName = str(o, "device_name", "name"), model = cleanModel(str(o, "device_model", "model")).ifEmpty { into.model },
            version = into.version.ifEmpty { str(o, "os_version", "version") }, extra = extra,
        )
    }

    suspend fun info(s: Settings): ZInfo {
        var i = ZInfo()
        get(s, "/v1/sys/utilization", timeout = 8.0).let { i = parseUtil(it, i) }
        i = i.copy(version = parseVersion(opt(s, "/v1/sys/version")))
        (opt(s, "/v1/sys/hardware") as? JSONObject)?.let { h -> i = i.copy(model = cleanModel(str(h, "drive_model", "model")), arch = str(h, "arch")) }
        i = parseDevice(opt(s, "/v2/zimaos/device/info"), i)
        return i
    }

    // ZimaOS 1.8 on a PC sends the error of reading the board name ("cat: /proc/device-tree/model: No such file ...")
    fun cleanModel(m: String): String {
        val x = m.trim().trim('\u0000').trim()
        return if (x.isEmpty() || x.startsWith("cat:") || x.contains("No such file", true) || x.contains("not found", true)) "" else x
    }

    fun parseHealth(d: Any?): ZHealth {
        val o = d as? JSONObject ?: return ZHealth(emptyList(), emptyList())
        fun l(k: String) = arrOf(o.opt(k)).let { a -> (0 until a.length()).map { a.optString(it).removeSuffix(".service") }.filter { it.isNotEmpty() } }
        return ZHealth(l("running"), l("not_running"))
    }
    suspend fun health(s: Settings) = parseHealth(get(s, "/v2/casaos/health/services"))

    suspend fun errorLog(s: Settings, lines: Int = 200): String {
        val d = get(s, "/v1/sys/logs?line=$lines", timeout = 15.0)
        val t = when (d) {
            is JSONArray -> (0 until d.length()).joinToString("\n") { d.opt(it).toString() }
            null -> ""
            else -> d.toString()
        }
        return t.replace(Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]"), "").replace("\r", "").trimEnd()
    }

    // ---------- Storage ----------
    // /v1/storage: [ { disk_name, path, size, type, children: [ { label, mount_point, size, used, avail (strings, bytes), type, path } ] } ]
    fun parseVolumes(d: Any?): List<ZVolume> = arrOf(d, "list").objs().flatMap { disk ->
        val dn = str(disk, "disk_name", "model").ifEmpty { disk.optString("path").substringAfterLast("/") }
        arrOf(disk.opt("children")).objs().map { c ->
            ZVolume(
                str(c, "label").ifEmpty { c.optString("mount_point").substringAfterLast("/").ifEmpty { "Volume" } },
                c.optString("mount_point"), c.optString("path"), c.optString("type"),
                num(c.opt("size")) ?: 0.0, num(c.opt("used")) ?: 0.0, num(c.opt("avail")) ?: 0.0, dn,
            )
        }
    }.filter { it.mount.isNotEmpty() && it.fs != "swap" && it.mount != "/boot/efi" }.distinctBy { it.mount }

    suspend fun volumes(s: Settings) = parseVolumes(get(s, "/v1/storage?system=show", timeout = 15.0))

    // /v2/local_storage/merge: the storage pool (several drives seen as one /DATA)
    fun parsePools(d: Any?): List<ZPool> = arrOf(d, "list").objs().map { m ->
        ZPool(m.optString("mount_point"), m.optString("fstype"), arrOf(m.opt("source_volume_uuids")).length())
    }.filter { it.mount.isNotEmpty() }
    suspend fun pools(s: Settings): List<ZPool> = try { parsePools(get(s, "/v2/local_storage/merge")) } catch (e: Exception) {
        if (e is kotlinx.coroutines.CancellationException) throw e
        if (e is ZimaErr && e.auth) throw e
        emptyList()   // 503 when the pool isn't set up
    }

    fun parseUsb(d: Any?): List<ZUsb> = arrOf(d, "list").objs().map { u ->
        ZUsb(
            u.optString("name"), u.optString("model").trim(), num(u.opt("size")) ?: 0.0,
            arrOf(u.opt("children")).objs().map { c -> ZUsbPart(c.optString("name"), c.optString("mount_point"), num(c.opt("size")) ?: 0.0, num(c.opt("avail")) ?: 0.0) }
                .filter { it.mount.isNotEmpty() },
        )
    }
    suspend fun usb(s: Settings) = parseUsb(get(s, "/v1/disks/usb"))
    // Safe removal: ZimaOS unmounts it, then it can be pulled out
    suspend fun eject(s: Settings, mount: String) { get(s, "/v1/disks/usb", "DELETE", JSONObject().put("mount_point", mount).toString(), timeout = 30.0) }

    suspend fun usbAuto(s: Settings): Boolean = get(s, "/v1/usb/usb-auto-mount").toString().equals("true", true)
    suspend fun setUsbAuto(s: Settings, on: Boolean) { get(s, "/v1/usb/usb-auto-mount", "PUT", JSONObject().put("state", if (on) "on" else "off").toString()) }

    // ---------- Shares (Samba) ----------
    fun parseShares(d: Any?) = arrOf(d, "list", "shares").objs().map { ZShare(str(it, "id"), it.optString("path"), it.optBoolean("anonymous", true), str(it, "name")) }.filter { it.path.isNotEmpty() }
    // ZimaOS 1.8 keeps shares in its Files service (/v2_1/files); older versions in /v1/samba
    private suspend fun <T> v2or1(v2: suspend () -> T, v1: suspend () -> T): T = try { v2() } catch (e: ZimaErr) {
        if (e.message != NOT_OFFERED) throw e
        v1()
    }
    suspend fun shares(s: Settings) = v2or1({ parseShares(get(s, "/v2_1/files/share")) }, { parseShares(get(s, "/v1/samba/shares")) })
    suspend fun addShare(s: Settings, path: String) = v2or1(
        { get(s, "/v2_1/files/share", "POST", JSONObject().put("name", path.trimEnd('/').substringAfterLast("/")).put("path", path).put("anonymous", true).toString(), timeout = 20.0); Unit },
        { get(s, "/v1/samba/shares", "POST", JSONArray().put(JSONObject().put("path", path).put("anonymous", true)).toString(), timeout = 20.0); Unit },
    )
    suspend fun delShare(s: Settings, id: String) = v2or1(
        { get(s, "/v2_1/files/share/${enc(id)}", "DELETE", timeout = 20.0); Unit },
        { get(s, "/v1/samba/shares/${enc(id)}", "DELETE", timeout = 20.0); Unit },
    )

    fun parseConns(d: Any?) = arrOf(d, "list").objs().map {
        ZConn(str(it, "id"), it.optString("host"), str(it, "port").ifEmpty { "445" }, it.optString("username"), it.optString("mount_point"))
    }.filter { it.host.isNotEmpty() }
    suspend fun conns(s: Settings) = v2or1({ parseConns(get(s, "/v2_1/files/connect")) }, { parseConns(get(s, "/v1/samba/connections")) })
    // Mounts a share of another computer on ZimaOS (it shows in ZimaOS's Files)
    suspend fun addConn(s: Settings, host: String, port: String, user: String, pass: String) {
        val body = JSONObject().put("host", host).put("port", port.ifEmpty { "445" }).put("username", user).put("password", pass).toString()
        v2or1({ get(s, "/v2_1/files/connect", "POST", body, timeout = 30.0); Unit }, { get(s, "/v1/samba/connections", "POST", body, timeout = 30.0); Unit })
    }
    suspend fun delConn(s: Settings, id: String) = v2or1(
        { get(s, "/v2_1/files/connect/${enc(id)}", "DELETE", timeout = 20.0); Unit },
        { get(s, "/v1/samba/connections/${enc(id)}", "DELETE", timeout = 20.0); Unit },
    )

    // ---------- Remote access (ZeroTier) ----------
    fun parseZt(d: Any?): ZZt? {
        val o = (d as? JSONObject) ?: (d as? JSONArray)?.optJSONObject(0) ?: return null
        val id = str(o, "id", "network_id", "nwid")
        return if (id.isEmpty()) null else ZZt(id, str(o, "name"), str(o, "status"))
    }
    suspend fun zt(s: Settings) = parseZt(get(s, "/v2/casaos/zt/info"))
    suspend fun setZt(s: Settings, id: String, online: Boolean) {
        get(s, "/v2/casaos/zt/${enc(id)}/status", "PUT", JSONObject().put("status", if (online) "online" else "offline").toString(), timeout = 20.0)
    }

    // ---------- Notifications ----------
    // /v2/users/events: [ { uuid, source_id, name, properties (a map, a JSON string of one, or [{name, value}]), timestamp (ms) } ]
    fun parseEvents(d: Any?): List<ZEvent> = arrOf(d, "list", "events").objs().map { e ->
        val props = HashMap<String, String>()
        var p: Any? = e.opt("properties")
        if (p is String) p = try { org.json.JSONTokener(p).nextValue() } catch (x: Exception) { null }
        when (p) {
            is JSONObject -> p.keys().forEach { k -> props[k] = p.optString(k) }
            is JSONArray -> p.objs().forEach { props[it.optString("name")] = it.optString("value") }
        }
        val name = str(e, "name")
        val title = props["casaos-ui:title"].orEmpty().ifEmpty { props["title"].orEmpty() }.ifEmpty {
            name.substringAfter(":").replace(':', ' ').replace('-', ' ').replace('_', ' ').trim().replaceFirstChar { it.uppercase() }
        }
        val msg = props["casaos-ui:message-1"].orEmpty().ifEmpty { props["message"].orEmpty() }.ifEmpty {
            props.filterKeys { !it.startsWith("casaos-ui:") }.entries.take(3).joinToString(" · ") { it.value }
        }
        var t = (num(e.opt("timestamp")) ?: 0.0).toLong()
        if (t in 1..99_999_999_999L) t *= 1000   // seconds
        ZEvent(str(e, "uuid", "event_uuid"), str(e, "source_id", "sourceID"), name, title, msg, t)
    }.filter { it.uuid.isNotEmpty() || it.title.isNotEmpty() }.sortedByDescending { it.time }

    // ZimaOS's dashboard cards ("You should know"): /v2/message_bus/ysk
    // [ { id, cardType: task | long-notice | short-notice, content: { titleText, bodyIconWithText: { description },
    //     bodyList: [ { description, rightText } ], bodyProgress: { label, progress } } } ]
    fun parseYsk(d: Any?): List<ZEvent> = arrOf(d, "list", "cards").objs().mapNotNull { c ->
        val id = str(c, "id")
        val ct = c.optJSONObject("content") ?: JSONObject()
        val title = str(ct, "titleText", "title")
        val iw = ct.optJSONObject("bodyIconWithText")?.let { str(it, "description") }.orEmpty()
        val list = arrOf(ct.opt("bodyList")).objs().map { li -> listOf(str(li, "description"), str(li, "rightText")).filter { it.isNotEmpty() }.joinToString(": ") }
            .filter { it.isNotEmpty() }
        val pr = ct.optJSONObject("bodyProgress")
        val pct = pr?.let { num(it.opt("progress")) }
        val msg = listOf(iw, list.take(6).joinToString("\n"), pr?.let { str(it, "label") }.orEmpty()).filter { it.isNotEmpty() }.joinToString("\n")
        if (id.isEmpty() && title.isEmpty()) null
        else ZEvent(id, str(c, "cardType"), "ysk", title.ifEmpty { "ZimaOS" }, msg, 0L, ysk = true, progress = pct)
    }

    suspend fun events(s: Settings): List<ZEvent> {
        val cards = try { parseYsk(get(s, "/v2/message_bus/ysk")) } catch (e: ZimaErr) { if (e.message != NOT_OFFERED) throw e; null }
        val old = try { parseEvents(get(s, "/v2/users/events")) } catch (e: ZimaErr) { if (e.message != NOT_OFFERED || cards == null) throw e; emptyList() }
        return cards.orEmpty() + old
    }
    suspend fun delEvent(s: Settings, e: ZEvent) {
        if (e.ysk) get(s, "/v2/message_bus/ysk/${enc(e.uuid)}", "DELETE") else get(s, "/v2/users/event/${enc(e.uuid)}", "DELETE")
    }

    // ---------- App sources and app settings ----------
    fun parseSources(d: Any?) = arrOf(d, "list").objs().map { ZSource(str(it, "id"), str(it, "url")) }.filter { it.url.isNotEmpty() }
    suspend fun sources(s: Settings) = parseSources(get(s, "/v2/app_management/appstore"))
    suspend fun addSource(s: Settings, url: String) { get(s, "/v2/app_management/appstore?url=${enc(url)}", "POST", "", timeout = 120.0) }
    suspend fun delSource(s: Settings, id: String) { get(s, "/v2/app_management/appstore/${enc(id)}", "DELETE", timeout = 30.0) }

    fun parseGlobals(d: Any?) = arrOf(d, "list").objs().map { ZGlobal(str(it, "key"), it.optString("value"), str(it, "description")) }.filter { it.key.isNotEmpty() }
    suspend fun globals(s: Settings) = parseGlobals(get(s, "/v2/app_management/global"))
    suspend fun setGlobal(s: Settings, key: String, value: String) {
        get(s, "/v2/app_management/global/${enc(key)}", "PUT", JSONObject().put("key", key).put("value", value).toString())
    }
    suspend fun delGlobal(s: Settings, key: String) { get(s, "/v2/app_management/global/${enc(key)}", "DELETE") }

    // ---------- ZimaOS modules (Files, Backup, Photos ...) ----------
    fun parseModules(d: Any?) = arrOf(d, "list").objs().mapNotNull { m ->
        val ui = m.optJSONObject("ui")
        val name = str(m, "name")
        if (name.isEmpty()) return@mapNotNull null
        ZModule(name, Zima.locText(ui?.opt("title")).ifEmpty { Zima.locText(m.opt("title")) }.ifEmpty { name.replaceFirstChar { it.uppercase() } },
            ui?.optString("icon").orEmpty(), ui?.optString("entry").orEmpty())
    }
    suspend fun modules(s: Settings) = parseModules(get(s, "/v2/mod_management/modules"))

    // a module's page: entry is a path on the server ("/modules/files/") or a full address
    fun moduleUrl(m: ZModule, base: String) = when {
        m.entry.isEmpty() -> ""
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(m.entry) -> m.entry
        else -> base.trimEnd('/') + (if (m.entry.startsWith("/")) "" else "/") + m.entry
    }
    fun iconUrl(icon: String, base: String) = when {
        icon.isEmpty() -> ""
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(icon) -> icon
        else -> base.trimEnd('/') + (if (icon.startsWith("/")) "" else "/") + icon
    }

    // ---------- One app: details and its compose file ----------
    fun parseDetail(d: Any?, ctrs: Any?): ZAppDetail {
        val o = d as? JSONObject ?: JSONObject()
        val comp = o.optJSONObject("compose") ?: JSONObject()
        val svcs: List<JSONObject> = when (val sv = comp.opt("services")) {
            is JSONArray -> sv.objs()
            is JSONObject -> sv.keys().asSequence().mapNotNull { k -> sv.optJSONObject(k)?.also { if (!it.has("name")) it.put("name", k) } }.toList()
            else -> emptyList()
        }
        val ports = svcs.flatMap { sv ->
            arrOf(sv.opt("ports")).let { a -> (0 until a.length()).map { a.opt(it) } }.mapNotNull { p ->
                when (p) {
                    is JSONObject -> {
                        val pub = str(p, "published"); val tgt = str(p, "target"); val pr = str(p, "protocol").ifEmpty { "tcp" }
                        if (tgt.isEmpty()) null else (if (pub.isNotEmpty()) "$pub → $tgt" else tgt) + if (pr != "tcp") "/$pr" else ""
                    }
                    is String -> p.takeIf { it.isNotBlank() }
                    else -> null
                }
            }
        }.distinct()
        val folders = svcs.flatMap { sv ->
            arrOf(sv.opt("volumes")).let { a -> (0 until a.length()).map { a.opt(it) } }.mapNotNull { v ->
                when (v) {
                    is JSONObject -> { val src = str(v, "source"); val tgt = str(v, "target"); if (tgt.isEmpty()) null else if (src.isNotEmpty()) "$src → $tgt" else tgt }
                    is String -> v.takeIf { it.isNotBlank() }?.replaceFirst(":", " → ")
                    else -> null
                }
            }
        }.distinct()
        val env = svcs.flatMap { sv ->
            when (val e = sv.opt("environment")) {
                is JSONObject -> e.keys().asSequence().map { k -> k to (e.opt(k)?.takeIf { it != JSONObject.NULL }?.toString() ?: "") }.toList()
                is JSONArray -> (0 until e.length()).map { e.optString(it) }.map { it.substringBefore("=") to it.substringAfter("=", "") }
                else -> emptyList()
            }
        }.distinctBy { it.first }
        val images = svcs.mapNotNull { str(it, "image").takeIf { i -> i.isNotEmpty() } }.distinct()
        val co = ctrs as? JSONObject
        val list = co?.optJSONObject("containers")?.let { m -> m.keys().asSequence().mapNotNull { m.optJSONObject(it) }.toList() }
            ?: arrOf(ctrs, "containers").objs()
        val cs = list.map { c ->
            ZCtrInfo(str(c, "Name", "name", "Service").removePrefix("/"), str(c, "Image", "image"), str(c, "State", "state"), str(c, "Health", "health"))
        }
        return ZAppDetail(str(o, "status"), o.optBoolean("update_available", false), co?.optString("main").orEmpty(), cs, ports, folders, env, images)
    }

    suspend fun detail(s: Settings, app: String): ZAppDetail {
        val d = get(s, "/v2/app_management/compose/${enc(app)}", timeout = 15.0)
        val c = opt(s, "/v2/app_management/compose/${enc(app)}/containers")
        return parseDetail(d, c)
    }

    // ZimaOS 1.8: an app's compose file at /zimaapp/v2app/files/compose, with its version (Etag) that saving must send back
    private fun zimaappPath(app: String) = "/v2/app_management/zimaapp/v2app/files/compose?zimaapp_id=" + URLEncoder.encode("zimaapp://v2app/$app", "UTF-8")

    // A compose answer to text: YAML as is; JSON (the file itself, or { data: ... }) pretty-printed (JSON is valid YAML too)
    fun composeText(body: String): String {
        val b = body.trim()
        if (!b.startsWith("{")) return body.replace("\r", "")
        val j = try { JSONObject(b) } catch (e: Exception) { return body }
        val d = if (j.has("data") && !j.has("services")) j.opt("data") else j
        return when {
            d is String -> d.replace("\r", "")
            d is JSONObject && d.opt("compose") is String -> d.optString("compose").replace("\r", "")
            d is JSONObject && d.optJSONObject("compose") != null -> d.optJSONObject("compose")!!.toString(2).replace("\\/", "/")
            d is JSONObject -> d.toString(2).replace("\\/", "/")
            else -> body
        }
    }

    suspend fun compose(s: Settings, app: String): ZCompose {
        val r = Zima.call(s, zimaappPath(app), timeout = 15.0, headers = mapOf("Accept" to "application/yaml"))!!
        if (r.code in 200..299 && r.body.isNotBlank()) return ZCompose(composeText(r.body), r.headers["Etag"].orEmpty(), true)
        // older ZimaOS: GET /compose/{id}
        val o = Zima.call(s, "/v2/app_management/compose/${enc(app)}", timeout = 15.0, headers = mapOf("Accept" to "application/yaml"))!!
        if (o.code == 404) throw ZimaErr(NOT_OFFERED)
        if (o.code >= 400) Zima.data(o)
        return ZCompose(composeText(o.body), "", false)
    }

    // Saves a changed compose file: ZimaOS recreates the app with it (its data stays)
    suspend fun saveCompose(s: Settings, app: String, c: ZCompose) {
        val h = mutableMapOf("Content-Type" to "application/yaml")
        val path = if (c.v2) { if (c.etag.isNotEmpty()) h["If-Match"] = c.etag; zimaappPath(app) + "&sync=false" }
            else "/v2/app_management/compose/${enc(app)}?check_port_conflict=false"
        val r = Zima.call(s, path, "PUT", c.text, timeout = 300.0, headers = h, exactType = true, dropOk = true) ?: return
        if (r.code == 404 || r.code == 405) throw ZimaErr(NOT_OFFERED)
        if (r.code == 412) throw ZimaErr("The app's settings changed in ZimaOS meanwhile. Open Edit settings again.")
        try { Zima.data(r) } catch (e: ZimaErr) {
            if (e.message.orEmpty().contains("invalid user override")) throw ZimaErr("ZimaOS can't apply changes to this app's file. Change it in ZimaOS's app settings.")
            throw e
        }
    }

    // ---------- ZimaOS 1.8 storage: /v2/local_storage storages, raid, disk ----------
    fun parseDisks(d: Any?): List<Pair<ZDisk, JSONObject>> = arrOf(d, "list", "disks").objs().map { o ->
        val h = o.opt("health")
        ZDisk(
            str(o, "name").ifEmpty { o.optString("path").substringAfterLast("/") }, str(o, "model").let { if (it == "System") "" else it },
            num(o.opt("size")) ?: 0.0, !(h == false || (h is String && h.equals("false", true))), false,
            num(o.opt("temperature"))?.takeIf { it > 0 && it < 150 }, num(o.opt("power_on_hours"))?.toInt()?.takeIf { it > 0 },
        ) to o
    }

    private fun raidHealth(st: String) = when (st.lowercase()) {
        "", "ok" -> "ok"
        "rebuilding", "resyncing", "reshape", "recovering", "creating" -> "busy"
        "degraded", "inactive" -> "warn"
        "fail", "urge" -> "bad"
        else -> ""
    }
    private val rank = mapOf("" to 0, "ok" to 1, "busy" to 2, "warn" to 3, "bad" to 4)
    private fun worst(a: String, b: String) = if ((rank[b] ?: 0) > (rank[a] ?: 0)) b else a

    fun buildStorages(storages: Any?, raids: Any?, disks: Any?): List<ZStorage> {
        val dl = parseDisks(disks)
        fun diskFor(path: String, name: String) = dl.find { (_, o) -> o.optString("path") == path && path.isNotEmpty() }?.first
            ?: dl.find { it.first.name == name && name.isNotEmpty() }?.first
        val rl = arrOf(raids, "list", "raids").objs()
        val used = HashSet<Int>()
        fun raidFor(name: String, dir: String): JSONObject? {
            for ((i, r) in rl.withIndex()) {
                if (i in used) continue
                if ((name.isNotEmpty() && (str(r, "name") == name || str(r, "storage_name") == name)) || (dir.isNotEmpty() && str(r, "mount_point") == dir)) { used.add(i); return r }
            }
            return null
        }
        fun withRaid(p: ZStorage, r: JSONObject): ZStorage {
            val st = str(r, "raid_status").ifEmpty { "ok" }
            val pct = num(r.opt("percentage"))
            val drives = arrOf(r.opt("devices")).objs().map { dv ->
                val nm = str(dv, "name").ifEmpty { dv.optString("path").removePrefix("/dev/") }
                val k = diskFor(dv.optString("path"), nm)
                val h = dv.opt("health")
                val ok = !(h == false || (h is String && h.equals("false", true))) && !dv.optBoolean("faulty", false) && (k?.healthy ?: true)
                ZDisk(nm, str(dv, "model").ifEmpty { k?.model.orEmpty() }, num(dv.opt("size")) ?: k?.size ?: 0.0, ok, dv.optBoolean("missing", false), k?.temp, k?.hours)
            }
            var hl = worst(p.health, raidHealth(st))
            for (x in drives) hl = worst(hl, if (x.missing) "warn" else if (!x.healthy) "bad" else "")
            return p.copy(
                kind = "raid", state = st, level = num(r.opt("raid_level"))?.toInt(),
                progress = pct?.takeIf { st != "ok" && it > 0 && it < 100 }, drives = drives, health = hl,
                size = if (p.size > 0) p.size else num(r.opt("size")) ?: 0.0, used = if (p.size > 0) p.used else num(r.opt("used")) ?: 0.0,
            )
        }
        val out = ArrayList<ZStorage>()
        for (o in arrOf(storages, "list", "storages").objs()) {
            val ext = o.optJSONObject("extensions") ?: JSONObject()
            val h = ext.opt("health")
            var p = ZStorage(
                str(o, "name"), str(o, "path"), str(o, "type").lowercase(), num(ext.opt("size")) ?: num(o.opt("size")) ?: 0.0, num(ext.opt("used")) ?: num(o.opt("used")) ?: 0.0,
                when (h) { true -> "ok"; false -> "bad"; is String -> if (h.equals("true", true)) "ok" else if (h.equals("false", true)) "bad" else ""; else -> "" },
            )
            val r = raidFor(p.name, p.dir)
            if (r != null) p = withRaid(p, r)
            else {
                // the drives it is on: a partition mounted at its folder, or named after it; the system storage is /DATA
                val ds = dl.filter { (dk, dj) ->
                    (p.kind == "system" && dj.optString("model") == "System") || arrOf(dj.opt("children")).objs().any { ch ->
                        val mp = ch.optString("mount_point")
                        (mp.isNotEmpty() && (mp == p.dir || (p.kind == "system" && mp == "/DATA"))) || (str(ch, "storage_name").let { it.isNotEmpty() && it == p.name })
                    }
                }.map { it.first }
                var hl = p.health
                for (x in ds) if (!x.healthy) hl = worst(hl, "bad")
                p = p.copy(drives = ds, health = hl)
            }
            if (p.name.isNotEmpty() || p.dir.isNotEmpty()) out.add(p)
        }
        // a RAID ZimaOS has but doesn't list as a storage (not mounted yet)
        for ((i, r) in rl.withIndex()) if (i !in used) out.add(withRaid(ZStorage(str(r, "name"), str(r, "mount_point"), "raid", 0.0, 0.0, ""), r))
        return out
    }

    // Every storage: ZimaOS 1.8's list, else the older volumes (/v1/storage) and storage pool
    suspend fun storageList(s: Settings): List<ZStorage> = storages(s) ?: run {
        val drives = try { Zima.drives(s) } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; emptyList() }
        volumes(s).map { v ->
            val d = Zima.driveFor(v.path, drives)
            ZStorage(v.label, v.mount, v.fs, v.size, v.used, if (d == null) "" else if (d.health == false) "bad" else "ok",
                drives = listOfNotNull(d?.let { ZDisk(it.name, it.model, it.size, it.health != false, false, it.temp, null) }))
        } + pools(s).map { ZStorage("Storage pool", it.mount, "pool", 0.0, 0.0, "", state = if (it.count > 0) "${it.count} drives" else "") }
    }

    // ZimaOS 1.8 storages; null when this ZimaOS has only the older /v1/storage
    suspend fun storages(s: Settings): List<ZStorage>? {
        val st = try { get(s, "/v2/local_storage/storages", timeout = 15.0) } catch (e: ZimaErr) { if (e.message == NOT_OFFERED) return null; throw e }
        val raids = opt(s, "/v2/local_storage/raid?all=true")
        val disks = opt(s, "/v2/local_storage/disk")
        return buildStorages(st, raids, disks)
    }

    // ---------- ZimaOS updates: /v2/installer (ZimaOS's OTA service) ----------
    fun parseRelease(d: Any?): Triple<String, String, Boolean> {
        val o = d as? JSONObject ?: return Triple(if (d is String) d.trim() else "", "", false)
        return Triple(str(o, "version"), o.optString("release_note").replace("\\n", "\n").trim(), o.optBoolean("important", false))
    }

    suspend fun ota(s: Settings): ZOta {
        val cur = parseRelease(get(s, "/v2/installer/release/current"))
        val notice = (opt(s, "/v2/installer/web/notice") as? String).orEmpty().trim()
        val latest = try { parseRelease(get(s, "/v2/installer/release/latest", timeout = 20.0)) } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            if (e is ZimaErr && e.auth) throw e
            Triple("", "", false)
        }
        val st = (opt(s, "/v2/installer/status") as? JSONObject)?.let { str(it, "status") }.orEmpty()
        val beta = (opt(s, "/v2/installer/beta-subscription") as? JSONObject)?.let { str(it, "status") }?.takeIf { it.isNotEmpty() }?.equals("enabled", true)
        return ZOta(cur.first, latest.first, latest.second, latest.third, st, beta, notice)
    }
    // Downloads and installs the newest ZimaOS; ZimaOS restarts when it's done
    suspend fun otaInstall(s: Settings) { get(s, "/v2/installer/install", "POST", "", timeout = 60.0) }
    suspend fun otaReset(s: Settings) { get(s, "/v2/installer/reset", "PUT", "", timeout = 20.0) }
    suspend fun otaBeta(s: Settings, on: Boolean) { get(s, "/v2/installer/beta-subscription?status=${if (on) "enable" else "disable"}", "PUT", "", timeout = 20.0) }

}
