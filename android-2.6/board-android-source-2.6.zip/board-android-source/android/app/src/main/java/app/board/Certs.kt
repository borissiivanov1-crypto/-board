package app.board

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import okhttp3.internal.tls.OkHostnameVerifier
import java.net.Socket
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLSession
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509ExtendedTrustManager

// ---------- HTTPS certificates: trust on first use ----------
// Most home servers use a self-signed certificate, which Android doesn't trust. -board accepts a server's certificate
// the first time it connects and remembers it (per address and port). If that server later shows a different
// certificate, the connection is stopped and the app asks once whether to trust the new one. That keeps saved logins
// from going to a device that only pretends to be the server. Certificates Android already trusts for that name
// (e.g. Let's Encrypt) are accepted as usual and not remembered, so their renewals don't ask anything.

class CertChanged(val host: String, val port: Int, val fp: String) : CertificateException("The certificate of $host changed")

object CertStore {
    private var prefs: SharedPreferences? = null
    private val mem = HashMap<String, String>() // when there are no prefs (unit tests)
    private val declined = HashSet<String>()     // "host:port|fp" answered Cancel, until the app restarts

    // the question for the dashboard ("The certificate of HOST changed. Trust the new one?")
    var asked by mutableStateOf<CertChanged?>(null)

    fun init(ctx: Context) { if (prefs == null) prefs = ctx.getSharedPreferences("board-certs", Context.MODE_PRIVATE) }

    fun key(host: String, port: Int) = host.lowercase().trim('[', ']') + ":" + port
    fun saved(host: String, port: Int): String? = get(key(host, port))
    private fun get(k: String): String? = prefs?.getString(k, null) ?: synchronized(mem) { mem[k] }
    private fun put(k: String, fp: String) { val p = prefs; if (p != null) p.edit().putString(k, fp).apply() else synchronized(mem) { mem[k] = fp } }

    fun count(): Int = prefs?.all?.size ?: synchronized(mem) { mem.size }
    fun forgetAll() { prefs?.edit()?.clear()?.apply(); synchronized(mem) { mem.clear() }; synchronized(declined) { declined.clear() }; asked = null }

    fun fingerprint(c: X509Certificate): String = MessageDigest.getInstance("SHA-256").digest(c.encoded).joinToString(":") { "%02X".format(it) }

    // A certificate Android doesn't trust for this name: remember it the first time, then it must stay the same
    fun check(host: String, port: Int, fp: String) {
        val k = key(host, port)
        val was = get(k)
        if (was == null) { put(k, fp); return }
        if (was == fp) return
        val e = CertChanged(host, port, fp)
        val seen = synchronized(declined) { "$k|$fp" in declined }
        if (!seen && asked?.let { it.host == host && it.port == port && it.fp == fp } != true) asked = e
        throw e
    }

    fun trust(e: CertChanged) { put(key(e.host, e.port), e.fp); if (asked === e || asked?.fp == e.fp) asked = null }
    fun decline(e: CertChanged) { synchronized(declined) { declined.add(key(e.host, e.port) + "|" + e.fp) }; asked = null }

    fun matches(host: String, port: Int, c: X509Certificate?) = c != null && saved(host, port) == fingerprint(c)
}

// Android's own check first (chain + name); anything else goes through CertStore.check
class PinTrust : X509ExtendedTrustManager() {
    private val sys: X509ExtendedTrustManager? = try {
        TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(null as KeyStore?) }
            .trustManagers.filterIsInstance<X509ExtendedTrustManager>().firstOrNull()
    } catch (e: Exception) { null }

    fun verify(chain: Array<out X509Certificate>?, host: String, port: Int, system: () -> Unit) {
        val leaf = chain?.firstOrNull() ?: throw CertificateException("no certificate")
        val sysOk = try { system(); true } catch (e: CertificateException) { false } catch (e: IllegalArgumentException) { false }
        if (sysOk && host.isNotEmpty() && OkHostnameVerifier.verify(host, leaf)) return
        CertStore.check(host, port, CertStore.fingerprint(leaf))
    }

    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?, socket: Socket?) {
        val host = (socket as? SSLSocket)?.handshakeSession?.peerHost ?: socket?.inetAddress?.hostAddress ?: ""
        verify(chain, host, socket?.port ?: 0) { sys?.checkServerTrusted(chain, authType, socket) ?: throw CertificateException("no system trust") }
    }
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?, engine: SSLEngine?) {
        verify(chain, engine?.peerHost ?: "", engine?.peerPort ?: 0) { sys?.checkServerTrusted(chain, authType, engine) ?: throw CertificateException("no system trust") }
    }
    // without a socket the address isn't known: only certificates Android trusts
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        sys?.checkServerTrusted(chain, authType) ?: throw CertificateException("no system trust")
    }
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?, socket: Socket?) { throw CertificateException("not a server") }
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?, engine: SSLEngine?) { throw CertificateException("not a server") }
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) { throw CertificateException("not a server") }
    override fun getAcceptedIssuers(): Array<X509Certificate> = sys?.acceptedIssuers ?: arrayOf()
}

// The name check: a certificate valid for the name, or the one remembered for this address
object PinHostnames : HostnameVerifier {
    override fun verify(host: String, session: SSLSession): Boolean =
        OkHostnameVerifier.verify(host, session) || CertStore.matches(host, session.peerPort, try { session.peerCertificates?.firstOrNull() as? X509Certificate } catch (e: Exception) { null })
}
