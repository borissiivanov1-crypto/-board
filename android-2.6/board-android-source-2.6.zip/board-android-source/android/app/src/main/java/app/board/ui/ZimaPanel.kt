package app.board.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import app.board.BoardVM
import app.board.ZApp
import app.board.ZAppDetail
import app.board.Zima
import app.board.ZimaMore
import app.board.formatBytes
import app.board.serverHostOf
import kotlinx.coroutines.launch

// ---------- The ZimaOS panel (2.5): the "ZimaOS" chip above the buttons, ZimaOS servers with a login only ----------
// Tabs: System, Storage, Shares, Apps, Alerts. Each part loads on its own; one this ZimaOS lacks says so.

private val TABS = listOf("sys" to "System", "disk" to "Storage", "share" to "Shares", "apps" to "Apps", "alerts" to "Alerts")

@Composable
fun ZimaPanelDialog(vm: BoardVM, onClose: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf("sys") }
    Modal(onClose, wide = true, scrollKey = tab) {
        ModalTitle("ZIMAOS")
        val n = vm.zEvents.size
        Seg(TABS.map { (k, v) -> k to if (k == "alerts" && n > 0) "$v $n" else v }, tab, wrap = true) { tab = it }
        when (tab) {
            "sys" -> SystemTab(vm)
            "disk" -> StorageTab(vm)
            "share" -> SharesTab(vm)
            "apps" -> AppsTab(vm, onClose)
            "alerts" -> AlertsTab(vm)
        }
        Btn("Close", modifier = Modifier.fillMaxWidth()) { onClose() }
    }
}

// A part of the panel: a heading, then what ZimaOS answered (or Loading / the problem with Try again)
@Composable
private fun <T> Part(title: String, key: Any?, load: suspend () -> Pair<T?, String?>, hideMissing: Boolean = false, content: @Composable ColumnScope.(T, () -> Unit) -> Unit) {
    var seq by remember(key) { mutableIntStateOf(0) }
    var v by remember(key) { mutableStateOf<T?>(null) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var loading by remember(key) { mutableStateOf(true) }
    LaunchedEffect(key, seq) {
        loading = true
        val (r, e) = load()
        if (r != null) v = r
        err = if (r == null) e else null
        loading = false
    }
    // a part this ZimaOS version doesn't have: left out (ZimaOS 1.8 dropped some of the older CasaOS ones)
    if (hideMissing && err == ZimaMore.NOT_OFFERED && v == null) return
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Caps(title, 11.sp, .6f, Modifier.padding(start = 2.dp, top = 4.dp))
        val cur = v
        when {
            cur != null && err == null -> content(cur) { seq++ }
            loading -> Hint("Loading...")
            err == ZimaMore.NOT_OFFERED -> Hint(ZimaMore.NOT_OFFERED)
            else -> {
                T(err ?: "", 12.sp, color = RED, lineHeight = 16.sp, modifier = Modifier.padding(horizontal = 4.dp))
                Chip("Try again") { seq++ }
            }
        }
    }
}

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .05f)).padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp), content = content,
)

@Composable
private fun KV(k: String, v: String, color: Color = Color.White) {
    if (v.isEmpty()) return
    Row(Modifier.fillMaxWidth()) {
        T(k, 13.sp, alpha = .55f, modifier = Modifier.width(110.dp), maxLines = 1)
        T(v, 13.sp, FontWeight.Bold, color, modifier = Modifier.weight(1f), maxLines = 2)
    }
}

@Composable
private fun UseBar(frac: Double) {
    val f = frac.coerceIn(0.0, 1.0)
    val c = if (f >= .85) RED else if (f >= .6) ORANGE else GREEN
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = .1f))) {
        Box(Modifier.fillMaxWidth(f.toFloat()).height(6.dp).clip(RoundedCornerShape(3.dp)).background(c))
    }
}

// Runs a change, shows the result as a toast, then reloads the part
private fun act(vm: BoardVM, busy: String, done: String, reload: () -> Unit, block: suspend (app.board.Settings) -> Unit) {
    vm.showToast(busy, 60000)
    vm.viewModelScope.launch { vm.showToast(vm.zDo(done, block), 4000); reload() }
}

fun agoText(ms: Long): String {
    if (ms <= 0) return ""
    val s = (System.currentTimeMillis() - ms) / 1000
    return when {
        s < 60 -> "just now"
        s < 3600 -> "${s / 60} min ago"
        s < 86400 -> "${s / 3600} h ago"
        else -> "${s / 86400} d ago"
    }
}

// ---------- System ----------
@Composable
private fun SystemTab(vm: BoardVM) {
    val view = LocalView.current
    Part("DEVICE", vm.cur, { vm.zTry { ZimaMore.info(it) } }) { i, _ ->
        Card {
            KV("Name", i.deviceName)
            KV("Model", i.model)
            KV("ZimaOS", i.version)
            KV("Type", i.arch)
            i.cpuPct?.let { KV("CPU", "${jsPct(it)}%" + if (i.cores > 0) " of ${i.cores} cores" else "") }
            vm.zSys?.watts?.let { KV("CPU power", String.format(java.util.Locale.US, "%.1f W", it)) }
            vm.zSys?.cpuTemp?.let { KV("CPU temp", "${it.toInt()}°C") }
            if (i.memTotal > 0) {
                KV("Memory", "${formatBytes(i.memUsed)} of ${formatBytes(i.memTotal)}")
                UseBar(i.memUsed / i.memTotal)
            }
            for ((k, v) in i.extra) KV(k, v)
        }
        if (i.nets.isNotEmpty()) Card {
            for (n in i.nets) {
                val up = n.state.equals("up", true)
                KV(n.name, (if (n.state.isNotEmpty()) n.state + " · " else "") + "↓ ${formatBytes(n.recv)} ↑ ${formatBytes(n.sent)}", if (up || n.state.isEmpty()) Color.White else RED)
            }
            Hint("Totals since ZimaOS started.")
        }
    }
    Part("ZIMAOS UPDATE", vm.cur, { vm.zTry { ZimaMore.ota(it) } }, hideMissing = true) { o, reload ->
        var armed by remember(o) { mutableStateOf(false) }
        var notes by rememberSaveable { mutableStateOf(false) }
        Card {
            KV("Installed", o.current)
            when {
                o.installing -> KV("Status", "installing...", ORANGE)
                o.failed -> KV("Status", "the last update failed", RED)
                o.available -> KV("New", o.latest.ifEmpty { "available" } + if (o.important) " (important)" else "", GREEN)
                else -> KV("Status", "up to date", GREEN)
            }
            if (o.available && o.notes.isNotEmpty()) {
                Chip(if (notes) "Hide what's new" else "What's new") { notes = !notes }
                if (notes) T(o.notes.replace(Regex("<[^>]+>"), "").replace(Regex("(?m)^#+\\s*"), "").take(3000), 12.sp, alpha = .75f, lineHeight = 17.sp)
            }
        }
        if (o.failed) Btn("Clear the failed update", modifier = Modifier.fillMaxWidth()) { act(vm, "Clearing...", "Cleared. Check for updates again.", reload) { ZimaMore.otaReset(it) } }
        if (o.available && !o.installing) {
            if (armed) Note("ZimaOS downloads ${o.latest.ifEmpty { "the update" }}, installs it and restarts. Apps stop for a few minutes.")
            Btn(if (armed) "Tap again to update ZimaOS" else "Update ZimaOS", BtnKind.GreenText, Modifier.fillMaxWidth()) {
                if (!armed) { armed = true; return@Btn }
                Haptic.confirm(view)
                act(vm, "Starting the ZimaOS update...", "ZimaOS is updating. It restarts when it's done.", reload) { ZimaMore.otaInstall(it) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip(if (o.installing) "Check progress" else "Check again") { reload() }
            Spacer(Modifier.weight(1f))
            if (o.beta != null) {
                T("Beta versions", 13.sp, alpha = .75f)
                Spacer(Modifier.width(8.dp))
                Switch(o.beta) { on -> act(vm, "Saving...", if (on) "Beta versions on" else "Beta versions off", reload) { ZimaMore.otaBeta(it, on) } }
            }
        }
    }
    Part("SERVICES", vm.cur, { vm.zTry { ZimaMore.health(it) } }, hideMissing = true) { h, reload ->
        Card {
            T("${h.running.size} running" + if (h.stopped.isNotEmpty()) ", ${h.stopped.size} stopped" else "", 13.sp, FontWeight.Bold, if (h.stopped.isEmpty()) GREEN else ORANGE)
            for (x in h.stopped) T("Stopped: $x", 12.sp, color = RED)
        }
        Chip("Check again") { reload() }
    }
    Part("REMOTE ACCESS (ZEROTIER)", vm.cur, { vm.zTry { ZimaMore.zt(it) ?: app.board.ZZt("", "", "") } }, hideMissing = true) { z, reload ->
        if (z.id.isEmpty()) Hint("Remote access isn't set up on this ZimaOS.")
        else {
            var armed by remember(z) { mutableStateOf(false) }
            Card {
                KV("Network", z.name.ifEmpty { "ZimaOS" })
                KV("ID", z.id)
                KV("Status", z.status.ifEmpty { "unknown" }, if (z.online) GREEN else ORANGE)
            }
            if (armed) Note("Turning it off cuts remote access, also this app's, if you're away from home.")
            Btn(if (z.online) (if (armed) "Tap again to turn off" else "Turn off remote access") else "Turn on remote access",
                if (z.online) BtnKind.RedText else BtnKind.GreenText, Modifier.fillMaxWidth()) {
                if (z.online && !armed) { armed = true; return@Btn }
                Haptic.confirm(view)
                act(vm, "Changing remote access...", "Remote access turned ${if (z.online) "off" else "on"}", reload) { ZimaMore.setZt(it, z.id, !z.online) }
            }
        }
    }
    var showLog by rememberSaveable { mutableStateOf(false) }
    if (!showLog) Btn("Show ZimaOS log", modifier = Modifier.fillMaxWidth()) { showLog = true }
    else Part("ZIMAOS LOG", vm.cur, { vm.zTry { ZimaMore.errorLog(it).ifEmpty { "(no log lines)" } } }) { log, reload ->
        val sc = rememberScrollState()
        LaunchedEffect(log) { sc.scrollTo(sc.maxValue) }
        Box(Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = .3f)).verticalScroll(sc).padding(10.dp)) {
            Text(log, color = Color.White.copy(alpha = .88f), fontSize = 11.sp, lineHeight = 15.sp, fontFamily = FontFamily.Monospace)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Refresh") { reload() }; Chip("Hide") { showLog = false } }
    }
}

private fun jsPct(x: Double) = if (x >= 10) x.toInt().toString() else String.format(java.util.Locale.US, "%.1f", x)

// ---------- Storage ----------
@Composable
private fun StorageTab(vm: BoardVM) {
    val view = LocalView.current
    Part("STORAGE", vm.cur, { vm.zTry { ZimaMore.storageList(it) } }) { list, reload ->
        if (list.isEmpty()) Hint("No storage listed.")
        for (p in list) Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T(p.name.ifEmpty { p.dir.substringAfterLast("/").ifEmpty { "Storage" } }, 14.sp, FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                if (p.size > 0) T("${formatBytes((p.size - p.used).coerceAtLeast(0.0))} free", 12.sp, alpha = .65f)
            }
            val kind = when (p.kind) {
                "system" -> "System"; "raid" -> "RAID" + when (p.level) { null -> ""; -1 -> " (JBOD)"; else -> " ${p.level}" }
                "usb" -> "USB"; "disk" -> "Disk"; "pool" -> "Storage pool"; else -> p.kind
            }
            T(listOf(kind, p.dir).filter { it.isNotEmpty() }.joinToString(" · "), 11.sp, alpha = .5f, maxLines = 1)
            if (p.size > 0) {
                UseBar(p.used / p.size)
                T("${formatBytes(p.used)} of ${formatBytes(p.size)} used", 11.sp, alpha = .5f)
            }
            val (txt, col) = when (p.health) {
                "ok" -> (if (p.kind == "raid") "RAID OK" else "Healthy") to GREEN
                "busy" -> (p.state.replaceFirstChar { it.uppercase() } + (p.progress?.let { " ${it.toInt()}%" } ?: "")) to ORANGE
                "warn" -> (if (p.kind == "raid") "RAID ${p.state.ifEmpty { "degraded" }}" else "Check it") to ORANGE
                "bad" -> (if (p.kind == "raid") "RAID ${p.state.ifEmpty { "failing" }}" else "Drive FAILING") to RED
                else -> (if (p.kind == "pool") p.state else "") to Color.White
            }
            if (txt.isNotEmpty()) T(txt, 12.sp, FontWeight.Bold, col)
            for (d in p.drives) {
                val bits = listOf(d.name, d.model, if (d.size > 0) formatBytes(d.size) else "", d.temp?.let { "${it.toInt()}°C" } ?: "",
                    d.hours?.let { "${it / 24} days on" } ?: "").filter { it.isNotEmpty() }.joinToString(" · ")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(bits, 11.sp, alpha = .6f, modifier = Modifier.weight(1f), maxLines = 1)
                    T(if (d.missing) "MISSING" else if (d.healthy) "OK" else "FAILING", 11.sp, FontWeight.Bold, if (d.missing) ORANGE else if (d.healthy) GREEN else RED)
                }
            }
        }
        Chip("Refresh") { reload() }
    }
    Part("USB DRIVES", vm.cur, { vm.zTry { ZimaMore.usb(it) to (try { ZimaMore.usbAuto(it) } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; null }) } }, hideMissing = true) { (list, auto), reload ->
        if (list.isEmpty()) Hint("No USB drive plugged in.")
        for (u in list) Card {
            T(u.name.ifEmpty { u.model.ifEmpty { "USB drive" } }, 14.sp, FontWeight.Bold, maxLines = 1)
            T(listOf(u.model, if (u.size > 0) formatBytes(u.size) else "").filter { it.isNotEmpty() }.joinToString(" · "), 11.sp, alpha = .5f)
            for (p in u.parts) {
                var armed by remember(p.mount) { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(p.name.ifEmpty { p.mount }, 13.sp, maxLines = 1)
                        T(p.mount + if (p.size > 0) " · ${formatBytes(p.avail)} free" else "", 11.sp, alpha = .5f, maxLines = 1)
                    }
                    Chip(if (armed) "Tap again" else "Eject") {
                        if (!armed) { armed = true; return@Chip }
                        Haptic.confirm(view)
                        act(vm, "Ejecting...", "Ejected. You can unplug it now.", reload) { ZimaMore.eject(it, p.mount) }
                    }
                }
            }
        }
        if (auto != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                T("Mount USB drives when plugged in", 14.sp, modifier = Modifier.weight(1f))
                Switch(auto) { on -> act(vm, "Saving...", "USB auto-mount ${if (on) "on" else "off"}", reload) { ZimaMore.setUsbAuto(it, on) } }
            }
        }
    }
}

// ---------- Shares ----------
@Composable
private fun SharesTab(vm: BoardVM) {
    val host = serverHostOf(vm.set)
    Part("SHARED FOLDERS (SMB)", vm.cur, { vm.zTry { ZimaMore.shares(it) } }) { list, reload ->
        if (list.isEmpty()) Hint("No folders shared.")
        for (sh in list) {
            var armed by remember(sh.id) { mutableStateOf(false) }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(sh.path.substringAfterLast("/").ifEmpty { sh.path }, 14.sp, FontWeight.Bold, maxLines = 1)
                        T("smb://$host/${sh.path.substringAfterLast("/")}" + if (sh.anonymous) " · no login" else "", 11.sp, alpha = .5f, maxLines = 1)
                        T(sh.path, 11.sp, alpha = .4f, maxLines = 1)
                    }
                    Chip(if (armed) "Tap again" else "Stop sharing") {
                        if (!armed) { armed = true; return@Chip }
                        act(vm, "Removing the share...", "Not shared any more. The folder and its files stay.", reload) { ZimaMore.delShare(it, sh.id) }
                    }
                }
            }
        }
        var path by rememberSaveable { mutableStateOf("") }
        Field(path, { path = it }, "/DATA/Media", maxLength = 200)
        Btn("Share this folder", BtnKind.GreenText, Modifier.fillMaxWidth(), enabled = path.trim().startsWith("/")) {
            val p = path.trim().trimEnd('/')
            act(vm, "Sharing...", "Shared as smb://$host/${p.substringAfterLast("/")}", { path = ""; reload() }) { ZimaMore.addShare(it, p) }
        }
        Hint("A folder on ZimaOS, e.g. /DATA/Media. Shared without a login on your home network.")
    }
    Part("NETWORK DRIVES ON ZIMAOS", vm.cur, { vm.zTry { ZimaMore.conns(it) } }) { list, reload ->
        if (list.isEmpty()) Hint("None. Add a share from another computer and it shows in ZimaOS's Files.")
        for (c in list) {
            var armed by remember(c.id) { mutableStateOf(false) }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(c.host + if (c.port != "445") ":${c.port}" else "", 14.sp, FontWeight.Bold, maxLines = 1)
                        T(listOf(c.user, c.mount).filter { it.isNotEmpty() }.joinToString(" · "), 11.sp, alpha = .5f, maxLines = 1)
                    }
                    Chip(if (armed) "Tap again" else "Remove") {
                        if (!armed) { armed = true; return@Chip }
                        act(vm, "Removing...", "Network drive removed", reload) { ZimaMore.delConn(it, c.id) }
                    }
                }
            }
        }
        var open by rememberSaveable { mutableStateOf(false) }
        if (!open) Btn("Add a network drive", modifier = Modifier.fillMaxWidth()) { open = true }
        else {
            var h by rememberSaveable { mutableStateOf("") }
            var port by rememberSaveable { mutableStateOf("445") }
            var u by rememberSaveable { mutableStateOf("") }
            var pw by remember { mutableStateOf("") }
            Field(h, { h = it }, "Computer, e.g. 192.168.1.20", maxLength = 120)
            Field(port, { port = it.filter { ch -> ch.isDigit() } }, "Port", keyboard = KeyboardType.Number, maxLength = 5)
            Field(u, { u = it }, "User name", maxLength = 80)
            Field(pw, { pw = it }, "Password", password = true, maxLength = 120)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Cancel", modifier = Modifier.weight(1f)) { open = false }
                Btn("Add", BtnKind.Ok, Modifier.weight(1f), enabled = h.isNotBlank() && u.isNotBlank()) {
                    val host2 = h.trim().removePrefix("smb://").removePrefix("\\\\")
                    act(vm, "Connecting...", "Network drive added", { open = false; reload() }) { ZimaMore.addConn(it, host2, port, u.trim(), pw) }
                }
            }
            Hint("ZimaOS mounts every share of that computer it can see with this login.")
        }
    }
}

// ---------- Apps ----------
@Composable
private fun AppsTab(vm: BoardVM, onClose: () -> Unit) {
    val nUp = vm.zUpdates.size
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Caps("APP UPDATES", 11.sp, .6f, Modifier.padding(start = 2.dp, top = 4.dp))
        if (nUp == 0) Hint("All apps are up to date.")
        else Btn("Update all $nUp", BtnKind.GreenText, Modifier.fillMaxWidth()) { onClose(); vm.zUpdateAll() }
    }
    val base = Zima.base(vm.set)
    Part("ZIMAOS MODULES", vm.cur, { vm.zTry { ZimaMore.modules(it) } }) { mods, _ ->
        val withPage = mods.filter { it.entry.isNotEmpty() }
        val urls = vm.layout.all.map { it.url.trimEnd('/') }.toSet()
        val picked = remember { mutableStateMapOf<String, Boolean>() }
        if (withPage.isEmpty()) Hint("No modules with a page.")
        for (m in withPage) {
            val has = ZimaMore.moduleUrl(m, base).trimEnd('/') in urls
            Row(Modifier.fillMaxWidth().alpha(if (has) .4f else 1f), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(ZimaMore.iconUrl(m.icon, base), listOf(m.title, m.name))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T(m.title, 15.sp, FontWeight.Bold, maxLines = 1)
                    T(if (has) "Already a button" else m.entry, 11.sp, alpha = .5f, maxLines = 1)
                }
                if (!has) Switch(picked[m.name] == true) { picked[m.name] = it }
            }
        }
        val sel = withPage.filter { picked[it.name] == true }
        if (sel.isNotEmpty()) Btn("Add ${sel.size} as button${if (sel.size == 1) "" else "s"}", BtnKind.Ok, Modifier.fillMaxWidth()) {
            picked.clear()
            vm.viewModelScope.launch {
                try { vm.addZModules(sel); vm.showToast("${sel.size} added", 3000) } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    vm.showToast("Couldn't add them" + (e.message?.let { ": $it" } ?: ""), 4000)
                }
            }
        }
    }
    Part("APP SOURCES", vm.cur, { vm.zTry { ZimaMore.sources(it) } }) { list, reload ->
        for (src in list) {
            var armed by remember(src.id) { mutableStateOf(false) }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(src.url.removePrefix("https://").removePrefix("http://"), 12.sp, modifier = Modifier.weight(1f), maxLines = 2)
                    if (list.size > 1) Chip(if (armed) "Tap again" else "Remove") {
                        if (!armed) { armed = true; return@Chip }
                        act(vm, "Removing...", "App source removed", { vm.zStore = null; reload() }) { ZimaMore.delSource(it, src.id) }
                    }
                }
            }
        }
        var url by rememberSaveable { mutableStateOf("") }
        Field(url, { url = it }, "https://.../appstore.zip", keyboard = KeyboardType.Uri, maxLength = 300)
        Btn("Add app source", BtnKind.GreenText, Modifier.fillMaxWidth(), enabled = Regex("^https?://\\S+$").matches(url.trim())) {
            val u = url.trim()
            act(vm, "Adding the source (ZimaOS downloads it)...", "App source added. Its apps are in the App Store.", { url = ""; vm.zStore = null; reload() }) { ZimaMore.addSource(it, u) }
        }
        Hint("Extra app stores for ZimaOS: the address of the store's .zip file.")
    }
    Part("APP SETTINGS", vm.cur, { vm.zTry { ZimaMore.globals(it) } }) { list, reload ->
        if (list.isEmpty()) Hint("None set.")
        for (g in list) {
            var v by remember(g) { mutableStateOf(g.value) }
            Card {
                T(g.key, 13.sp, FontWeight.Bold, maxLines = 1)
                if (g.desc.isNotEmpty()) T(g.desc, 11.sp, alpha = .5f)
                val secret = Regex("KEY|TOKEN|SECRET|PASS", RegexOption.IGNORE_CASE).containsMatchIn(g.key)
                Field(v, { v = it }, "Value", password = secret, maxLength = 500)
                if (v != g.value) Chip("Save") { act(vm, "Saving...", "${g.key} saved", reload) { ZimaMore.setGlobal(it, g.key, v) } }
            }
        }
        Hint("Values ZimaOS gives to the apps that ask for them (e.g. an API key).")
    }
}

// ---------- Alerts ----------
@Composable
private fun AlertsTab(vm: BoardVM) {
    var seq by remember { mutableIntStateOf(0) }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(seq) { err = vm.loadZEvents() }
    Caps("NOTIFICATIONS", 11.sp, .6f, Modifier.padding(start = 2.dp, top = 4.dp))
    val list = vm.zEvents
    if (err != null && err != ZimaMore.NOT_OFFERED) T(err!!, 12.sp, color = RED)
    when {
        err == ZimaMore.NOT_OFFERED -> Hint(ZimaMore.NOT_OFFERED)
        list.isEmpty() -> Hint("No notifications.")
        else -> {
            for (e in list.take(60)) Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(e.title.ifEmpty { e.name }, 14.sp, FontWeight.Bold, maxLines = 2)
                        if (e.message.isNotEmpty()) T(e.message, 12.sp, alpha = .7f, lineHeight = 16.sp)
                        e.progress?.let { pc -> UseBar(if (pc > 1) pc / 100 else pc) }
                        T(listOf(if (e.ysk) "" else e.source, agoText(e.time)).filter { it.isNotEmpty() }.joinToString(" · "), 11.sp, alpha = .45f, maxLines = 1)
                    }
                    if (e.uuid.isNotEmpty()) Chip("Dismiss") {
                        vm.zEvents = vm.zEvents.filter { it.uuid != e.uuid }
                        vm.viewModelScope.launch { vm.zDo("") { ZimaMore.delEvent(it, e) }.let { if (it.isNotEmpty()) vm.showToast(it, 4000) } }
                    }
                }
            }
            if (list.size > 1) Btn("Dismiss all", modifier = Modifier.fillMaxWidth()) {
                val evs = list.filter { it.uuid.isNotEmpty() }
                vm.zEvents = emptyList()
                vm.viewModelScope.launch {
                    val r = vm.zDo("Notifications cleared") { s -> evs.forEach { ZimaMore.delEvent(s, it) } }
                    vm.showToast(r, 3000); seq++
                }
            }
        }
    }
    Chip("Refresh") { seq++ }
}

// ---------- One app: details (hold menu > Details) ----------
@Composable
fun ZAppDetailDialog(vm: BoardVM, app: ZApp, onClose: () -> Unit, onEdit: () -> Unit) {
    var d by remember { mutableStateOf<ZAppDetail?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var showEnv by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(app.id) { val (r, e) = vm.zTry { ZimaMore.detail(it, app.id) }; d = r; err = e }
    Modal(onClose, wide = true) {
        ModalTitle(app.title.uppercase())
        val x = d
        when {
            x != null -> {
                Card {
                    KV("Status", x.status.ifEmpty { app.status }, if (app.running) GREEN else ORANGE)
                    if (x.update || vm.zUpdatable(app)) KV("Update", "available", GREEN)
                    KV("Address", Zima.appUrl(app, serverHostOf(vm.set)))
                    for (i in x.images) KV("Image", i)
                }
                if (x.containers.isNotEmpty()) Card {
                    Caps("CONTAINERS", 10.sp, .55f)
                    for (c in x.containers) KV(c.name.ifEmpty { "container" }, listOf(c.state, c.health).filter { it.isNotEmpty() }.joinToString(" · "),
                        if (c.state.equals("running", true)) Color.White else ORANGE)
                }
                if (x.ports.isNotEmpty()) Card {
                    Caps("PORTS (SERVER → APP)", 10.sp, .55f)
                    for (p in x.ports) T(p, 13.sp)
                }
                if (x.folders.isNotEmpty()) Card {
                    Caps("FOLDERS (SERVER → APP)", 10.sp, .55f)
                    for (f in x.folders) T(f, 12.sp, lineHeight = 16.sp)
                }
                if (x.env.isNotEmpty()) Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Caps("SETTINGS (${x.env.size})", 10.sp, .55f, Modifier.weight(1f))
                        Chip(if (showEnv) "Hide" else "Show") { showEnv = !showEnv }
                    }
                    if (showEnv) for ((k, v) in x.env) {
                        val secret = Regex("KEY|TOKEN|SECRET|PASS", RegexOption.IGNORE_CASE).containsMatchIn(k)
                        KV(k, if (secret && v.isNotEmpty()) "••••••" else v)
                    }
                }
            }
            err != null -> ErrText(err!!)
            else -> Note("Loading...")
        }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (app.controllable) Btn("Edit settings", modifier = Modifier.fillMaxWidth()) { onEdit() }
            Btn("Close", modifier = Modifier.fillMaxWidth()) { onClose() }
        }
    }
}

// ---------- One app: its compose file, to change ports, folders, settings ... ----------
@Composable
fun ZComposeDialog(vm: BoardVM, app: ZApp, onClose: () -> Unit) {
    val look = LocalLook.current
    val view = LocalView.current
    var file by remember { mutableStateOf<app.board.ZCompose?>(null) }
    var orig by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var armed by remember { mutableStateOf(false) }
    var quitArmed by remember { mutableStateOf(false) }
    LaunchedEffect(app.id) {
        val (r, e) = vm.zTry { ZimaMore.compose(it, app.id) }
        if (r != null) { file = r; orig = r.text; text = r.text } else err = e
    }
    val changed = orig != null && text != orig
    fun quit() { if (changed && !quitArmed) quitArmed = true else onClose() }
    Modal(onClose, wide = true, onBack = { quit() }) {
        ModalTitle("${app.title.uppercase()} SETTINGS")
        when {
            orig != null -> {
                Note("The app's compose file in ZimaOS: ports, folders, settings. Saving recreates the app; its data stays.")
                Box(Modifier.fillMaxWidth().height(420.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = .3f)).padding(10.dp)) {
                    BasicTextField(
                        text, { text = it; armed = false; quitArmed = false },
                        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()),
                        textStyle = TextStyle(color = Color.White.copy(alpha = .9f), fontSize = 12.sp, lineHeight = 16.sp, fontFamily = FontFamily.Monospace),
                        cursorBrush = SolidColor(look.acc),
                    )
                }
                if (quitArmed) Note("Leave without saving your changes?")
            }
            err != null -> ErrText(err!!)
            else -> Note("Loading...")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn(if (quitArmed) "Leave" else "Cancel", if (quitArmed) BtnKind.RedText else BtnKind.Plain, Modifier.weight(1f)) { quit() }
            if (orig != null) Btn(if (armed) "Tap again" else "Save", BtnKind.Ok, Modifier.weight(1f), enabled = changed && text.isNotBlank()) {
                if (!armed) { armed = true; return@Btn }
                Haptic.confirm(view)
                val c = file!!.copy(text = text)
                onClose()
                vm.showToast("Saving ${app.title}...", 300000)
                vm.viewModelScope.launch { vm.showToast(vm.zSaveCompose(app, c), 6000) }
            }
        }
        if (armed) Hint("Tap Save again: ZimaOS stops ${app.title}, recreates it with this file and starts it.")
    }
}
