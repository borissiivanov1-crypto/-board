package app.board

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File

// ---------- Auto logo: the dashboard-icons logo for a name ----------
// Used by "Auto" in the add / edit form and by every "Pick from ..." in the + popup, so both find the same logo.
// dashboard-icons logos have no background, so they're preferred to the icon the server gives (TrueNAS and ZimaOS
// store icons often have a square background, and some are SVG files Android can't show); that one is only used
// when dashboard-icons has nothing.
// The collection's file list (tree.json, plus the aliases in metadata.json) is downloaded once a week, so names match
// loosely ("AdGuardHome" finds adguard-home.png) without a request per guess. Without the list, the likeliest names
// are checked one by one.
object AutoLogo {
    private const val REPO = "https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/"
    private const val WEEK = 7 * 24 * 3600 * 1000L
    private const val RETRY = 10 * 60 * 1000L

    private var file: File? = null
    @Volatile private var index: Map<String, String>? = null // norm(name or alias) -> file name without .png
    @Volatile private var triedAt = 0L
    private val lock = Mutex()
    private val gate = Semaphore(4) // at most 4 logo lookups at once (Pick from adds many buttons together)

    fun init(ctx: Context) { if (file == null) file = File(ctx.filesDir, "board-logo-index.json") }

    fun url(base: String) = "$LOGO_CDN$base.png"
    fun slug(x: String) = x.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
    fun norm(x: String) = x.lowercase().filter { it.isLetterOrDigit() }

    // endings that are rarely part of a logo's name ("portainer-ce", "code-server", "plex-media-server" ...)
    private val SUFFIX = Regex("-(server|media-server|ce|ee|oss|app|docker|web|webui|ui|official|community|stable|latest|nightly|beta|lts|aio|ls\\d*)$")

    // The names to try, best first: each name as is, without a common ending, then its first word
    fun candidates(names: List<String>): List<String> {
        val out = LinkedHashSet<String>()
        val firsts = ArrayList<String>()
        for (n in names) {
            val s = slug(n)
            if (s.length < 2) continue
            out.add(s)
            var t = s
            while (true) { val u = t.replace(SUFFIX, ""); if (u == t || u.length < 2) break; t = u; out.add(t) }
            s.substringBefore('-').takeIf { it.length >= 4 && it != s }?.let { firsts.add(it) }
        }
        out.addAll(firsts)
        return out.toList()
    }

    // ---------- the collection's file list ----------
    // Every *.png name in tree.json; light / dark variants only when there's no plain one
    fun buildIndex(tree: Any?, meta: Any?): Map<String, String> {
        val pngs = LinkedHashSet<String>()
        fun walk(x: Any?) {
            when (x) {
                is JSONObject -> x.keys().forEach { walk(x.opt(it)) }
                is JSONArray -> for (i in 0 until x.length()) walk(x.opt(i))
                is String -> if (x.endsWith(".png", true)) pngs.add(x.substringAfterLast('/').dropLast(4))
            }
        }
        walk(tree)
        val m = HashMap<String, String>()
        val variant = Regex("-(light|dark)$")
        for (b in pngs.sortedBy { if (variant.containsMatchIn(it)) 1 else 0 }) m.putIfAbsent(norm(b), b)
        for (b in pngs) if (variant.containsMatchIn(b)) m.putIfAbsent(norm(b.replace(variant, "")), b)
        // metadata.json: { "sonarr": { "aliases": ["..."] }, ... }
        (meta as? JSONObject)?.let { o ->
            o.keys().forEach { k ->
                if (k !in pngs) return@forEach
                o.optJSONObject(k)?.optJSONArray("aliases")?.let { a -> for (i in 0 until a.length()) a.optString(i).takeIf { it.isNotBlank() }?.let { m.putIfAbsent(norm(it), k) } }
            }
        }
        return m
    }

    private suspend fun loadIndex(): Map<String, String>? = lock.withLock {
        index?.let { return it }
        val f = file
        // saved copy, under a week old
        if (f != null && f.exists() && System.currentTimeMillis() - f.lastModified() < WEEK) {
            try { return parse(f.readText()).also { index = it } } catch (_: Exception) {}
        }
        if (System.currentTimeMillis() - triedAt < RETRY) return staleOrNull(f)
        triedAt = System.currentTimeMillis()
        try {
            val tree = Net.request(REPO + "tree.json", timeout = 15.0)
            if (tree.code >= 300) return staleOrNull(f)
            val meta = try { Net.request(REPO + "metadata.json", timeout = 15.0).takeIf { it.code < 300 }?.body } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; null }
            val saved = JSONObject().put("tree", JSONTokener(tree.body).nextValue()).put("meta", meta?.let { JSONTokener(it).nextValue() } ?: JSONObject.NULL)
            val m = buildIndex(saved.opt("tree"), saved.opt("meta"))
            if (m.size < 50) return staleOrNull(f) // not the list we expect
            try { f?.writeText(saved.toString()) } catch (_: Exception) {}
            index = m
            m
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            staleOrNull(f)
        }
    }

    private fun parse(t: String): Map<String, String> { val o = JSONObject(t); return buildIndex(o.opt("tree"), o.opt("meta")).also { if (it.size < 50) throw IllegalStateException() } }
    private fun staleOrNull(f: File?) = try { if (f != null && f.exists()) parse(f.readText()).also { index = it } else null } catch (_: Exception) { null }

    // From the list: the first candidate it has
    fun pick(names: List<String>, idx: Map<String, String>): String? {
        for (c in candidates(names)) idx[norm(c)]?.let { return it }
        return null
    }

    // The logo URL for these names ("" = none). serverIcon: what the server gives, used only if nothing else is found
    suspend fun find(names: List<String>, serverIcon: String = ""): String = gate.withPermit {
        val idx = loadIndex()
        if (idx != null) pick(names, idx)?.let { return@withPermit url(it) }
        else for (c in candidates(names).take(6)) { val u = url(c); if (Logos.exists(u)) return@withPermit u }
        if (serverIcon.startsWith("http", true) && Logos.exists(serverIcon)) serverIcon else ""
    }
}
