package app.board

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Safe saving of board-data.json (and anything else that must never be left half-written).
 * A save never overwrites the file in place:
 *   1. the new text is written to <name>.tmp and flushed to the disk,
 *   2. the current file is copied to <name>.bak (through <name>.bak.tmp, so the backup is never half-written either),
 *   3. <name>.tmp is renamed over <name> in one step.
 * If the app dies at any point, <name> is either the old or the new complete file, and <name>.bak is a good copy.
 */
object DataFile {
    // true if the text is saved data that can be read back (a JSON object or list)
    fun valid(raw: String?): Boolean {
        if (raw.isNullOrBlank()) return false
        return try {
            val v = JSONTokener(raw).nextValue()
            v is JSONObject || v is JSONArray
        } catch (e: Exception) { false }
    }

    fun write(file: File, raw: String) {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        FileOutputStream(tmp).use { out ->
            out.write(raw.toByteArray(Charsets.UTF_8))
            out.flush()
            out.fd.sync()
        }
        if (file.exists()) {
            val bakTmp = File(file.path + ".bak.tmp")
            file.copyTo(bakTmp, overwrite = true)
            move(bakTmp, File(file.path + ".bak"))
        }
        move(tmp, file)
    }

    private fun move(from: File, to: File) {
        try {
            Files.move(from.toPath(), to.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (e: Exception) {
            // a file system without atomic rename: a plain replace (the backup still covers a crash here)
            Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}
