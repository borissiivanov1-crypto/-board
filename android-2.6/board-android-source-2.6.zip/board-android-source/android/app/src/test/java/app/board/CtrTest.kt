package app.board

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CtrTest {
    private fun sv(name: String, url: String, ctr: String = "") =
        Service("c:1", name, splitUrl(url).port, "🔗", "", url, true, "http", "", "", true, ctr = ctr)

    private val docker = listOf(
        Ctr("jellyfin", "jellyfin", "running", listOf("8096")),
        Ctr("navidrome", "navidrome", "exited", listOf("4533")),
        Ctr("plex-media-server", "plex-media-server", "running", listOf("32400")),
    )

    @Test fun byPort() = assertEquals("jellyfin", Ctrs.match(sv("Movies", "http://192.168.1.10:8096"), docker, "192.168.1.10")?.id)

    @Test fun portOnAnotherHostDoesntCount() = assertNull(Ctrs.match(sv("Movies", "http://192.168.1.99:8096"), docker, "192.168.1.10"))

    @Test fun byName() {
        assertEquals("navidrome", Ctrs.match(sv("Navidrome", "https://music.example.com"), docker, "192.168.1.10")?.id)
        assertEquals("plex-media-server", Ctrs.match(sv("Plex", "https://plex.example.com"), docker, "192.168.1.10")?.id)
    }

    @Test fun pickedByHand() = assertEquals("navidrome", Ctrs.match(sv("Movies", "http://192.168.1.10:8096", ctr = "navidrome"), docker, "192.168.1.10")?.id)

    @Test fun proxmoxGuestByAddress() {
        val guests = listOf(Ctr("pve/lxc/101", "pihole", "running", ips = listOf("192.168.1.20"), kind = "lxc"), Ctr("pve/qemu/200", "haos", "running", ips = listOf("192.168.1.30"), kind = "qemu"))
        assertEquals("pve/qemu/200", Ctrs.match(sv("Home Assistant", "http://192.168.1.30:8123"), guests, "192.168.1.5")?.id)
        assertEquals("pve/lxc/101", Ctrs.match(sv("Pi-hole", "http://dns.lan/admin"), guests, "192.168.1.5")?.id)
    }

    @Test fun running() {
        assertEquals(true, Ctr("a", "a", "Up 2 hours").running)
        assertEquals(false, Ctr("a", "a", "exited").running)
        assertEquals(false, Ctr("a", "a", "").known)
    }

    @Test fun pickFromServer() {
        assertEquals("8096", Ctrs.webPort(Ctr("j", "jellyfin", "running", listOf("1900", "7359", "8096", "8920"))))
        assertEquals("80", Ctrs.webPort(Ctr("p", "pihole", "running", listOf("53", "80"))))
        assertEquals("8080", Ctrs.webPort(Ctr("q", "qbittorrent", "running", listOf("6881", "8080"))))
        assertEquals("", Ctrs.webPort(Ctr("d", "db", "running", listOf("5432"))))
        assertEquals("https", Ctrs.webScheme("9443"))
        assertEquals("http", Ctrs.webScheme(""))
        assertEquals("Plex Media Server", Ctrs.title(Ctr("x", "plex-media-server", "")))
        assertEquals("HomeAssistant", Ctrs.title(Ctr("x", "HomeAssistant", "")))
        assertEquals(listOf("sonarr", "tv"), Ctrs.logoSlugs(Ctr("tv", "tv", "", image = "lscr.io/linuxserver/sonarr:latest")))
        assertEquals("192.168.1.20", Ctrs.ownAddr(Ctr("pve/lxc/1", "a", "running", ips = listOf("fe80::1", "192.168.1.20"), kind = "lxc")))
    }

    // buttons added together, or with a name already on the dashboard, get " 2", " 3" ...
    @Test fun repeatedNamesGetNumbers() {
        val used = mutableSetOf("sonarr")
        val a = Store.uniqueName("Sonarr", used); used.add(a.lowercase())
        val b = Store.uniqueName("Sonarr", used); used.add(b.lowercase())
        assertEquals("Sonarr 2", a)
        assertEquals("Sonarr 3", b)
        assertEquals("Radarr", Store.uniqueName("Radarr", used))
        assertEquals("A very long container 2", Store.uniqueName("A very long container name", setOf("a very long container na")))
    }
}
