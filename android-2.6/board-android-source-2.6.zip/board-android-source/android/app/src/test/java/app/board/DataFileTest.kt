package app.board

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class DataFileTest {
    private fun dir(): File = Files.createTempDirectory("board").toFile()

    private fun twoServers() = JSONObject().put("v", 2).put("current", "s1").put("settings", JSONObject())
        .put("servers", JSONArray()
            .put(JSONObject().put("id", "s1").put("title", "NAS").put("settings", JSONObject().put("serverHost", "192.168.1.10")))
            .put(JSONObject().put("id", "s2").put("title", "PVE").put("settings", JSONObject().put("serverHost", "192.168.1.20"))))

    @Test fun writesThroughTmpAndKeepsBackup() {
        val d = dir(); val f = File(d, "board-data.json")
        DataFile.write(f, "{\"a\":1}")
        assertFalse(File(d, "board-data.json.bak").exists())
        DataFile.write(f, "{\"a\":2}")
        assertEquals("{\"a\":2}", f.readText())
        assertEquals("{\"a\":1}", File(d, "board-data.json.bak").readText())
        assertFalse(File(d, "board-data.json.tmp").exists())
    }

    @Test fun validity() {
        assertFalse(DataFile.valid(""))
        assertFalse(DataFile.valid("{\"servers\":[{\"id\":\"s1\""))
        assertTrue(DataFile.valid("{}"))
        assertTrue(DataFile.valid("[]"))
    }

    @Test fun damagedFileRestoresBackupAndIsKept() {
        val d = dir(); val f = File(d, "board-data.json")
        Store.initFile(f)
        Store.writeStore(twoServers())
        Store.writeStore(twoServers().put("current", "s2"))
        // the app died mid-write (as 1.2 could): the file is cut off
        f.writeText(f.readText().take(40))
        Store.initFile(f)
        val st = Store.readStore()
        assertEquals(2, st.getJSONArray("servers").length())
        assertNotNull(Store.loadNote)
        assertTrue(d.listFiles()!!.any { it.name.startsWith("board-data.damaged-") })
        assertTrue(DataFile.valid(f.readText()))
    }

    @Test fun damagedWithoutBackupIsNeverOverwritten() {
        val d = dir(); val f = File(d, "board-data.json")
        f.writeText("{\"servers\":[{\"id\":\"s1\",\"title\":\"NA")
        Store.initFile(f)
        Store.readStore()
        Store.writeStore(Store.readStore())
        val kept = d.listFiles()!!.single { it.name.startsWith("board-data.damaged-") }
        assertEquals("{\"servers\":[{\"id\":\"s1\",\"title\":\"NA", kept.readText())
    }

    @Test fun missingFileUsesCompleteTmp() {
        val d = dir(); val f = File(d, "board-data.json")
        File(d, "board-data.json.tmp").writeText(twoServers().toString())
        Store.initFile(f)
        assertEquals(2, Store.readStore().getJSONArray("servers").length())
        assertTrue(f.exists())
    }

    @Test fun freshInstallHasNoNote() {
        val d = dir()
        Store.initFile(File(d, "board-data.json"))
        assertEquals(1, Store.readStore().getJSONArray("servers").length())
        assertNull(Store.loadNote)
    }

    @Test fun formKeepsBadValuesBackButSavesTheRest() {
        val stored = JSONObject().put("serverHost", "192.168.1.10").put("liveSeconds", 3).put("theme", "aurora")
        val form = JSONObject(stored.toString()).put("serverHost", "").put("liveSeconds", "x").put("theme", "midnight")
        val (good, probs) = validateForm(form, stored)
        assertEquals("192.168.1.10", good.getString("serverHost"))
        assertEquals(3, good.getInt("liveSeconds"))
        assertEquals("midnight", good.getString("theme"))
        assertTrue(probs.any { it.page == PAGE_SERVER && it.msg.contains("IP or name") })
    }

    @Test fun durations() {
        assertEquals("45 s", formatDuration(45_000))
        assertEquals("1 m 12 s", formatDuration(72_000))
    }
}
