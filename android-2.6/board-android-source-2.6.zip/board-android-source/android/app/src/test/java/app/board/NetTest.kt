package app.board

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class NetTest {
    // Glances and the other main requests never share a queue with the up / down and LIVE checks
    @Test fun checksHaveTheirOwnQueue() {
        val main = Net.client(5.0).dispatcher
        val checks = Net.client(3.0, check = true).dispatcher
        assertNotSame(main, checks)
        assertSame(main, Net.client(8.0).dispatcher)
        assertSame(checks, Net.client(4.0, check = true).dispatcher)
    }

    // well above OkHttp's default of 5 requests at a time to one server
    @Test fun higherLimitsPerServer() {
        assertTrue(Net.client(5.0).dispatcher.maxRequestsPerHost >= 20)
        assertTrue(Net.client(3.0, check = true).dispatcher.maxRequestsPerHost >= 20)
    }

    // ZimaOS's app install answers 415 unless the type is exactly application/yaml
    @Test fun exactContentType() {
        assertEquals("application/yaml", Net.body("a: 1", "application/yaml", exactType = true).contentType().toString())
        assertTrue(Net.body("{}", "application/json").contentType().toString().contains("charset"))
    }
}
