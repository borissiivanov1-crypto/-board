package app.board

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class CertTest {
    @Before fun clean() = CertStore.forgetAll()

    // the first certificate a server shows is remembered, per address and port
    @Test fun firstOneIsSaved() {
        CertStore.check("192.168.1.10", 8006, "AA:BB")
        assertEquals("AA:BB", CertStore.saved("192.168.1.10", 8006))
        assertNull(CertStore.saved("192.168.1.10", 443))
    }

    @Test fun sameOneIsAccepted() {
        CertStore.check("nas.local", 443, "AA:BB")
        CertStore.check("NAS.local", 443, "AA:BB")
        assertNull(CertStore.asked)
    }

    // a different certificate stops the connection and asks once
    @Test fun changedOneIsRefusedAndAsked() {
        CertStore.check("nas.local", 443, "AA:BB")
        try { CertStore.check("nas.local", 443, "CC:DD"); fail("should refuse") } catch (e: CertChanged) { assertEquals("CC:DD", e.fp) }
        val q = CertStore.asked!!
        assertEquals("nas.local", q.host)
        CertStore.trust(q)
        assertNull(CertStore.asked)
        CertStore.check("nas.local", 443, "CC:DD")
    }

    // Cancel: still refused, but not asked again until the app restarts
    @Test fun declinedIsNotAskedAgain() {
        CertStore.check("nas.local", 443, "AA:BB")
        try { CertStore.check("nas.local", 443, "CC:DD") } catch (e: CertChanged) {}
        CertStore.decline(CertStore.asked!!)
        var refused = false
        try { CertStore.check("nas.local", 443, "CC:DD") } catch (e: CertChanged) { refused = true }
        assertTrue(refused)
        assertNull(CertStore.asked)
    }

    @Test fun forgetAll() {
        CertStore.check("nas.local", 443, "AA:BB")
        CertStore.forgetAll()
        assertEquals(0, CertStore.count())
        CertStore.check("nas.local", 443, "CC:DD")
    }
}
