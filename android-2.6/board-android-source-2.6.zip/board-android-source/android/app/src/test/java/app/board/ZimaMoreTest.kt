package app.board

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// Answers shaped as the CasaOS / ZimaOS services send them (from their source code)
class ZimaMoreTest {
    @Test fun utilization() {
        val d = JSONObject("""{"cpu":{"percent":12.5,"num":4,"temperature":48,"model":"intel"},
            "mem":{"total":8000000000,"used":2000000000,"usedPercent":25.0},
            "net":[{"name":"eth0","bytesSent":100,"bytesRecv":2048,"state":"up"}]}""")
        val i = ZimaMore.parseUtil(d, ZInfo())
        assertEquals(12.5, i.cpuPct!!, 0.01)
        assertEquals(4, i.cores)
        assertEquals(25.0, i.memPct!!, 0.01)
        assertEquals("eth0", i.nets[0].name)
        assertEquals(2048.0, i.nets[0].recv, 0.01)
    }

    @Test fun versionAndDevice() {
        assertEquals("1.8.0", ZimaMore.parseVersion(JSONObject("""{"current_version":"1.8.0","need_update":false,"version":{"version":"1.8.1"}}""")))
        assertEquals("1.5.4", ZimaMore.parseVersion("1.5.4"))
        val i = ZimaMore.parseDevice(JSONObject("""{"device_name":"ZimaCube","hash":"abc","device_model":"ZimaCube Pro","lan_ipv4":"192.168.1.5","list":[1]}"""), ZInfo())
        assertEquals("ZimaCube", i.deviceName)
        assertEquals("ZimaCube Pro", i.model)
        assertTrue(i.extra.any { it.first == "Lan ipv4" && it.second == "192.168.1.5" })
        assertTrue(i.extra.none { it.first.contains("Hash", true) })
    }

    @Test fun volumes() {
        val d = JSONArray("""[{"disk_name":"Samsung SSD","path":"/dev/sda","size":500000000000,"type":"sata","children":[
            {"label":"System","mount_point":"/","size":"100","used":"40","avail":"60","type":"ext4","path":"/dev/sda2"},
            {"label":"","mount_point":"/boot/efi","size":"1","used":"1","avail":"0","type":"vfat","path":"/dev/sda1"},
            {"label":"Data","mount_point":"/DATA","size":"1000","used":"250","avail":"750","type":"btrfs","path":"/dev/sda3"}]}]""")
        val v = ZimaMore.parseVolumes(d)
        assertEquals(listOf("/", "/DATA"), v.map { it.mount })
        assertEquals(250.0, v[1].used, 0.01)
        assertEquals("Samsung SSD", v[1].disk)
    }

    @Test fun usbSharesConns() {
        val u = ZimaMore.parseUsb(JSONArray("""[{"name":"STICK","model":"Cruzer","size":32000,"children":[{"name":"STICK","mount_point":"/media/STICK","size":32000,"avail":1000},{"name":"x","mount_point":""}]}]"""))
        assertEquals(1, u[0].parts.size)
        assertEquals("/media/STICK", u[0].parts[0].mount)
        val sh = ZimaMore.parseShares(JSONArray("""[{"id":3,"anonymous":true,"path":"/DATA/Media"}]"""))
        assertEquals("3", sh[0].id)
        val c = ZimaMore.parseConns(JSONArray("""[{"id":1,"username":"bob","host":"192.168.1.20","port":"","mount_point":"/mnt/192.168.1.20"}]"""))
        assertEquals("445", c[0].port)
    }

    @Test fun eventsAllShapes() {
        val d = JSONArray("""[
          {"uuid":"a","source_id":"local-storage","name":"local-storage:disk:added","timestamp":1700000000000,
           "properties":"{\"casaos-ui:title\":\"New disk found\",\"casaos-ui:message-1\":\"A new disk, SanDisk Cruzer, is added.\"}"},
          {"uuid":"b","source_id":"app-management","name":"app:install-end","timestamp":1700000100,
           "properties":[{"name":"app:name","value":"Jellyfin"}]}]""")
        val e = ZimaMore.parseEvents(d)
        assertEquals("b", e[0].uuid)                 // newest first (seconds turned into ms)
        assertEquals(1700000100000L, e[0].time)
        assertEquals("Jellyfin", e[0].message)
        assertEquals("New disk found", e[1].title)
        assertEquals("A new disk, SanDisk Cruzer, is added.", e[1].message)
    }

    @Test fun ztHealthSourcesGlobals() {
        val z = ZimaMore.parseZt(JSONObject("""{"id":"8056c2e21c000001","name":"ZimaOS","status":"online"}"""))!!
        assertTrue(z.online)
        assertNull(ZimaMore.parseZt(JSONObject("{}")))
        val h = ZimaMore.parseHealth(JSONObject("""{"running":["casaos-gateway.service"],"not_running":["casaos.service"]}"""))
        assertEquals(listOf("casaos"), h.stopped)
        assertEquals("1", ZimaMore.parseSources(JSONArray("""[{"id":1,"url":"https://x/main.zip","store_root":"x"}]"""))[0].id)
        assertEquals("OPENAI_API_KEY", ZimaMore.parseGlobals(JSONArray("""[{"key":"OPENAI_API_KEY","value":"sk","description":"OpenAI"}]"""))[0].key)
    }

    @Test fun modules() {
        val m = ZimaMore.parseModules(JSONArray("""[{"name":"zimaos-files","ui":{"title":{"en_us":"Files"},"icon":"/modules/files/icon.svg","entry":"/modules/files/"}},{"name":"x"}]"""))
        assertEquals("Files", m[0].title)
        assertEquals("http://nas:80/modules/files/", ZimaMore.moduleUrl(m[0], "http://nas:80"))
        assertEquals("http://nas/modules/files/icon.svg", ZimaMore.iconUrl(m[0].icon, "http://nas/"))
        assertEquals("", ZimaMore.moduleUrl(m[1], "http://nas"))
    }

    @Test fun appDetail() {
        val d = JSONObject("""{"status":"running","update_available":true,"compose":{"services":[
            {"name":"jellyfin","image":"jellyfin/jellyfin:10.9","ports":[{"target":8096,"published":"8097","protocol":"tcp"}],
             "volumes":[{"type":"bind","source":"/DATA/AppData/jellyfin/config","target":"/config"}],"environment":{"TZ":"UTC","PGID":"1000"}}]}}""")
        val c = JSONObject("""{"main":"jellyfin","containers":{"09e7":{"Name":"jellyfin","Image":"jellyfin/jellyfin:10.9","State":"running","Health":""}}}""")
        val x = ZimaMore.parseDetail(d, c)
        assertTrue(x.update)
        assertEquals(listOf("8097 → 8096"), x.ports)
        assertEquals(listOf("/DATA/AppData/jellyfin/config → /config"), x.folders)
        assertEquals(2, x.env.size)
        assertEquals("running", x.containers[0].state)
        // compose services as a map, ports as strings
        val y = ZimaMore.parseDetail(JSONObject("""{"compose":{"services":{"web":{"image":"nginx","ports":["8080:80"],"environment":["A=1"]}}}}"""), null)
        assertEquals(listOf("8080:80"), y.ports)
        assertEquals("A" to "1", y.env[0])
    }

    // ---------- ZimaOS 1.8 ----------
    @Test fun modelText() {
        assertEquals("", ZimaMore.cleanModel("cat: /proc/device-tree/model: No such file or directory"))
        assertEquals("ZimaBoard 2", ZimaMore.cleanModel("ZimaBoard 2\u0000"))
        val i = ZimaMore.parseDevice(JSONObject("""{"device_name":"ZimaOS","device_model":"08NPPY","os_version":"v1.8.0","arch":"amd64","is_licensed":true,"can_control_power":false,"device_code":"204b90be"}"""),
            ZInfo(model = ""))
        assertEquals("08NPPY", i.model)
        assertEquals(listOf("Is licensed" to "Yes"), i.extra)
    }

    @Test fun yskCards() {
        val e = ZimaMore.parseYsk(JSONArray("""[{"id":"c1","cardType":"long-notice","renderType":"list-notice","content":{"titleIcon":"x","titleText":"Disk warning",
            "bodyList":[{"icon":"","description":"sdb","rightText":"48°C"}]}},
            {"id":"c2","cardType":"task","renderType":"task","content":{"titleText":"Installing Jellyfin","bodyProgress":{"label":"Pulling","progress":40}}}]"""))
        assertEquals("Disk warning", e[0].title)
        assertEquals("sdb: 48°C", e[0].message)
        assertTrue(e[0].ysk)
        assertEquals(40.0, e[1].progress!!, 0.01)
    }

    @Test fun storages18() {
        val st = JSONArray("""[{"name":"ZimaOS-HD","path":"/media/ZimaOS-HD","type":"System","extensions":{"health":true,"size":"500000","used":"100000"}},
            {"name":"Pool","path":"/media/Pool","type":"RAID","extensions":{"health":true,"size":4000,"used":1000}},
            {"name":"Stick","path":"/media/Stick","type":"USB","extensions":{"size":64,"used":1}}]""")
        val raid = JSONObject("""{"data":[{"name":"Pool","raid_level":5,"raid_status":"rebuilding","percentage":"42.5","devices":[
            {"name":"sdb","path":"/dev/sdb","health":true},{"name":"sdc","path":"/dev/sdc","health":false},{"name":"sdd","missing":true}]}]}""").opt("data")
        val disk = JSONObject("""{"data":[{"name":"nvme0n1","path":"/dev/nvme0n1","model":"System","health":true,"temperature":41,"power_on_hours":480,"children":[{"mount_point":"/DATA"}]},
            {"name":"sdb","path":"/dev/sdb","model":"WD Red","size":2000,"health":true,"temperature":35}]}""").opt("data")
        val l = ZimaMore.buildStorages(st, raid, disk)
        assertEquals(3, l.size)
        assertEquals("ok", l[0].health)
        assertEquals("nvme0n1", l[0].drives[0].name)
        assertEquals(41.0, l[0].drives[0].temp!!, 0.01)
        val p = l[1]
        assertEquals("raid", p.kind); assertEquals(5, p.level); assertEquals(42.5, p.progress!!, 0.01)
        assertEquals("bad", p.health)   // a failing drive beats rebuilding
        assertEquals("WD Red", p.drives[0].model)
        assertTrue(p.drives[2].missing)
        assertEquals("usb", l[2].kind)
    }

    @Test fun otaAndCompose() {
        assertTrue(ZOta("v1.8.0", "v1.8.1", "", false, "idle", null, "").available)
        assertTrue(!ZOta("v1.8.0", "1.8.0", "", false, "idle", null, "").available)
        assertTrue(ZOta("v1.8.0", "", "", false, "idle", null, "normal-update").available)
        assertTrue(!ZOta("v1.8.0", "v1.8.1", "", false, "idle", null, "no-update").available)
        assertEquals("name: x\n", ZimaMore.composeText("name: x\r\n"))
        assertEquals("services: {}", ZimaMore.composeText("""{"data":"services: {}"}"""))
        assertTrue(ZimaMore.composeText("""{"name":"gitsave","services":{"a":{"image":"x/y"}}}""").contains("\"image\": \"x/y\""))
        assertEquals("Media", ZimaMore.parseShares(JSONObject("""{"data":[{"id":2,"name":"Media","path":"/DATA/Media","anonymous":true}]}""").opt("data"))[0].name)
    }
}
