package app.board

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AutoLogoTest {
    private val tree = JSONObject().put("png", JSONArray(listOf("sonarr.png", "plex.png", "adguard-home.png", "portainer.png", "home-assistant.png",
        "jellyfin.png", "github-light.png", "github-dark.png", "code-server.png", "vaultwarden.png", "nextcloud.png", "nextcloud-light.png")))
        .put("svg", JSONArray(listOf("sonarr.svg", "only-svg.svg")))
    private val meta = JSONObject().put("vaultwarden", JSONObject().put("aliases", JSONArray(listOf("bitwarden-rs"))))
    private val idx = AutoLogo.buildIndex(tree, meta)

    private fun pick(vararg n: String) = AutoLogo.pick(n.toList(), idx)

    @Test fun exactName() = assertEquals("sonarr", pick("Sonarr"))
    @Test fun spacingAndCaseDontMatter() = assertEquals("adguard-home", pick("AdGuardHome"))
    @Test fun withoutCommonEnding() {
        assertEquals("plex", pick("Plex Media Server"))
        assertEquals("portainer", pick("portainer-ce"))
        assertEquals("code-server", pick("code-server")) // a real logo name keeps its ending
    }
    @Test fun buttonNameBeforeImage() = assertEquals("jellyfin", pick("Jellyfin", "my-media", "lscr.io/linuxserver/jellyfin".substringAfterLast("/")))
    @Test fun imageWhenTheNameHasNone() = assertEquals("sonarr", pick("TV Shows", "tv", "sonarr"))
    @Test fun alias() = assertEquals("vaultwarden", pick("bitwarden_rs"))
    @Test fun plainBeforeLightDark() {
        assertEquals("nextcloud", pick("Nextcloud"))
        assertEquals("github-light", pick("GitHub"))
    }
    @Test fun onlyPngs() = assertNull(pick("only svg"))
    @Test fun firstWordLast() = assertEquals("home-assistant", pick("Home Assistant"))
    @Test fun nothing() = assertNull(pick("zz"))
}
