package app.board

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ---------- Buttons and stacks ----------
interface Entry {
    val id: String
    val name: String
    val logo: String
    val icon: String
    val onWidget: Boolean
}

data class Service(
    override val id: String,
    override val name: String,
    val port: String,
    override val icon: String,
    override val logo: String,
    val url: String,
    val custom: Boolean,
    val scheme: String,
    val addr: String,
    val label: String,
    override val onWidget: Boolean,
    val group: String? = null,
    // the ZimaOS app this button was added from ("Pick from ZimaOS apps"); others are linked by port
    val zima: String = "",
    // the container picked by hand in the hold menu ("" = found by port or name)
    val ctr: String = "",
    // the main address (url is the one in use right now: this one, or the failover address)
    val mainUrl: String = url,
    // the address was left empty: it follows the server's address
    val auto: Boolean = false,
    // the failover address typed in the form ("" = the failover server address, when the main one is the server's)
    val url2: String = "",
    // the address used when the server is reached over its failover address (null = none)
    val failoverUrl: String? = null,
) : Entry

data class Stack(
    override val id: String,
    override val name: String,
    override val logo: String,
    val expand: Boolean,
    val members: List<Service>,
    override val onWidget: Boolean,
    override val icon: String = STACK_ICON,
) : Entry

data class Group(var id: String, var name: String, var logo: String, var expand: Boolean, var members: MutableList<String>) {
    fun toJson() = JSONObject().put("id", id).put("name", name).put("logo", logo).put("expand", expand).put("members", JSONArray(members))
}

class BoardData(
    var title: String,
    var settings: JSONObject,
    var custom: MutableList<JSONObject>,
    var edits: JSONObject,
    var hidden: MutableList<String>,
    var order: MutableList<String>,
    var widgetOrder: MutableList<String>,
    var widgetHidden: MutableList<String>,
    var groups: MutableList<Group>,
)

data class Layout(val all: List<Service>, val groups: List<Stack>, val dash: List<Entry>, val widget: List<Entry>, val hidden: List<Entry>)

data class ServerRef(val id: String, val title: String)

fun isObj(x: Any?) = x is JSONObject
fun JSONArray?.strings(): MutableList<String> = if (this == null) mutableListOf() else (0 until length()).mapNotNull { opt(it) as? String }.toMutableList()

/**
 * The data file holds every server, in the same shape as the Scriptable version (so exports move between the two):
 *   { v: 2, current, settings (shared by all servers), servers: [ { id, title, settings (own), custom, edits, ... } ] }
 * Functions work on one server at a time: CUR unless an id is given (the widget passes its own).
 */
object Store {
    private lateinit var file: File
    private var dataRaw: String? = null
    @Volatile var CUR: String = "s1"

    // What happened when the data file was read at start-up (shown once on the dashboard), or null if all was fine
    @Volatile var loadNote: String? = null
    // true when the data file couldn't be read at all (e.g. a storage error): nothing is saved over it this time
    @Volatile var readOnly: Boolean = false

    // Built-in buttons. Empty on purpose: add your own with the + button in the dashboard.
    private val BUILTIN = emptyList<JSONObject>()

    fun init(ctx: Context) {
        if (::file.isInitialized) return
        initFile(File(ctx.filesDir, "board-data.json"))
        CUR = readStore().optString("current", "s1")
        Secrets.init(ctx)
        Logos.init(ctx)
    }

    // the data file and its helpers (separate so the unit tests can use a temporary folder)
    @Synchronized fun initFile(f: File) {
        file = f
        dataRaw = null
        loadNote = null
        readOnly = false
    }

    private fun bakFile() = File(file.path + ".bak")
    private fun tmpFile() = File(file.path + ".tmp")

    // A file's text if it holds valid saved data, else null
    private fun readValid(f: File): String? {
        if (!f.exists()) return null
        val raw = f.readText()
        return if (DataFile.valid(raw)) raw else null
    }

    /**
     * Reads the data file once. A file that can't be read is never treated as a fresh install, and never saved over:
     *  - damaged (e.g. the app died while an older version was saving): the last good copy (board-data.json.bak)
     *    is used, and the damaged file is kept as board-data.damaged-<time>.json;
     *  - missing, with a good copy left from a save that was cut short: that copy is used;
     *  - a storage error while reading: -board starts empty for now but saves nothing, so the file stays as it is.
     */
    @Synchronized private fun readDataFile(): String {
        dataRaw?.let { return it }
        var raw = ""
        var restore: String? = null
        try {
            if (!file.exists()) {
                restore = readValid(tmpFile()) ?: readValid(bakFile())
                if (restore != null) loadNote = "Your settings were restored from the backup copy."
            } else {
                val main = readValid(file)
                if (main != null) raw = main
                else {
                    val bak = try { readValid(bakFile()) } catch (e: Exception) { null }
                    val keep = File(file.parentFile, "board-data.damaged-${System.currentTimeMillis()}.json")
                    if (!file.renameTo(keep)) {
                        // it can't be moved aside: leave it alone and save nothing over it
                        readOnly = true
                        raw = bak ?: ""
                        loadNote = "The settings file is damaged and couldn't be moved aside, so changes won't be saved this time." +
                            if (bak != null) " The last good copy is shown." else ""
                    } else if (bak != null) {
                        restore = bak
                        loadNote = "The settings file was damaged, so the last good copy was restored. The damaged file was kept as ${keep.name}."
                    } else {
                        loadNote = "The settings file was damaged and there was no backup copy. It was kept as ${keep.name}, and -board starts empty."
                    }
                }
            }
        } catch (e: Exception) {
            readOnly = true
            loadNote = "Your settings couldn't be read (${e.message ?: "storage error"}). Changes won't be saved until -board is restarted, so nothing is lost."
        }
        if (restore != null) {
            raw = restore
            try { DataFile.write(file, restore) } catch (e: Exception) { readOnly = true }
        }
        try { tmpFile().delete() } catch (_: Exception) {}
        dataRaw = raw
        return raw
    }

    @Synchronized fun readStore(): JSONObject {
        var d: Any = try {
            val raw = readDataFile()
            if (raw.isNotEmpty()) org.json.JSONTokener(raw).nextValue() else JSONObject()
        } catch (e: Exception) { JSONObject() }
        if (d is JSONArray) d = JSONObject().put("custom", d)
        if (d !is JSONObject) d = JSONObject()
        if (d.optJSONArray("servers") == null) {
            val st = d.optJSONObject("settings") ?: JSONObject()
            val own = JSONObject()
            val shared = JSONObject()
            for (k in st.keys()) (if (k in SERVER_SETTING_KEYS) own else shared).put(k, st.get(k))
            val s1 = JSONObject().put("id", "s1").put("title", d.opt("title") as? String ?: "").put("settings", own)
            for (k in SERVER_PARTS) if (d.has(k)) s1.put(k, d.get(k))
            d = JSONObject().put("v", 2).put("current", "s1").put("settings", shared).put("servers", JSONArray().put(s1))
        }
        if (d.optJSONObject("settings") == null) d.put("settings", JSONObject())
        val list = d.getJSONArray("servers")
        val keep = JSONArray()
        for (i in 0 until list.length()) {
            val x = list.opt(i)
            if (x is JSONObject && x.opt("id") is String) {
                if (x.optJSONObject("settings") == null) x.put("settings", JSONObject())
                keep.put(x)
            }
        }
        if (keep.length() == 0) keep.put(JSONObject().put("id", "s1").put("title", "").put("settings", JSONObject()))
        d.put("servers", keep)
        val cur = d.opt("current")
        if ((0 until keep.length()).none { keep.getJSONObject(it).getString("id") == cur }) d.put("current", keep.getJSONObject(0).getString("id"))
        return d
    }

    /**
     * Saves safely: the new data goes to board-data.json.tmp (flushed to the disk), the file it replaces is kept
     * as board-data.json.bak, and only then is the new file renamed into place. If the app dies halfway, either
     * the old or the new file is complete, and the backup is still there.
     */
    @Synchronized fun writeStore(st: JSONObject) {
        val raw = st.toString()
        if (readOnly) { dataRaw = raw; return }
        DataFile.write(file, raw)
        dataRaw = raw
    }

    @Synchronized fun importRaw(raw: String) {
        dataRaw = raw
        val st = readStore()
        writeStore(st)
        CUR = st.getString("current")
    }

    private fun servers(st: JSONObject): List<JSONObject> {
        val a = st.getJSONArray("servers")
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    private fun curServer(st: JSONObject, id: String = CUR): JSONObject {
        val l = servers(st)
        return l.find { it.getString("id") == id } ?: l.find { it.getString("id") == st.optString("current") } ?: l[0]
    }

    private fun titleAt(x: JSONObject, i: Int) = (x.opt("title") as? String)?.takeIf { it.isNotEmpty() } ?: if (i == 0) CONFIG.title else "SERVER ${i + 1}"

    fun listServers(): List<ServerRef> = servers(readStore()).mapIndexed { i, x -> ServerRef(x.getString("id"), titleAt(x, i)) }

    fun hasServer(id: String) = servers(readStore()).any { it.getString("id") == id }

    // A widget's server: its id, its name, or its number (1, 2 ...); else the first server
    fun resolveServer(want: String?): String {
        val l = servers(readStore())
        val w = want?.trim().orEmpty()
        if (w.isNotEmpty()) {
            val n = w.toIntOrNull()
            val hit = l.find { it.getString("id") == w }
                ?: (if (n != null && n >= 1 && n <= l.size) l[n - 1] else null)
                ?: l.withIndex().find { (i, x) -> ((x.opt("title") as? String)?.ifEmpty { null } ?: if (i == 0) CONFIG.title else "").equals(w, true) }?.value
            if (hit != null) return hit.getString("id")
        }
        return l[0].getString("id")
    }

    // Show another server (remembered for the next time the dashboard opens)
    @Synchronized fun setCurrentServer(id: String): Boolean {
        val st = readStore()
        if (servers(st).none { it.getString("id") == id }) return false
        CUR = id
        st.put("current", id)
        writeStore(st)
        return true
    }

    @Synchronized fun addServer(name: String, own: JSONObject): String {
        val st = readStore()
        val id = "s" + java.lang.Long.toString(System.currentTimeMillis(), 36)
        val n = st.getJSONArray("servers").length() + 1
        val settings = JSONObject().put("platform", "none")
        for (k in own.keys()) settings.put(k, own.get(k))
        st.getJSONArray("servers").put(JSONObject().put("id", id).put("title", name.trim().take(20).ifEmpty { "SERVER $n" }).put("settings", settings))
        writeStore(st)
        setCurrentServer(id)
        return id
    }

    // Removes a server, its buttons and layout, and the logins saved for it
    @Synchronized fun removeServer(id: String): Boolean {
        val st = readStore()
        val l = servers(st)
        if (l.size < 2) return false
        val i = l.indexOfFirst { it.getString("id") == id }
        if (i < 0) return false
        Secrets.forgetServerKeys(id)
        Route.forget(id)
        st.getJSONArray("servers").remove(i)
        val rest = servers(st)
        val next = rest[minOf(i, rest.size - 1)].getString("id")
        st.put("current", next)
        writeStore(st)
        CUR = next
        return true
    }

    @Synchronized fun loadData(id: String = CUR): BoardData {
        val st = readStore()
        val sv = curServer(st, id)
        val merged = JSONObject(st.getJSONObject("settings").toString())
        val own = sv.getJSONObject("settings")
        for (k in own.keys()) merged.put(k, own.get(k))
        val customArr = sv.optJSONArray("custom") ?: JSONArray()
        val custom = (0 until customArr.length()).mapNotNull { i ->
            val c = customArr.optJSONObject(i) ?: return@mapNotNull null
            if (c.optString("id").isEmpty()) c.put("id", "c:legacy$i")
            c
        }.toMutableList()
        val groupsArr = sv.optJSONArray("groups") ?: JSONArray()
        val groups = (0 until groupsArr.length()).mapNotNull { i ->
            val g = groupsArr.optJSONObject(i) ?: return@mapNotNull null
            if (g.opt("id") !is String) return@mapNotNull null
            Group(g.getString("id"), g.optString("name", "Stack").ifEmpty { "Stack" }.take(24), g.optString("logo", ""), g.optBoolean("expand", false), g.optJSONArray("members").strings())
        }.toMutableList()
        return BoardData(
            title = sv.opt("title") as? String ?: "",
            settings = merged,
            custom = custom,
            edits = sv.optJSONObject("edits") ?: JSONObject(),
            hidden = sv.optJSONArray("hidden").strings(),
            order = sv.optJSONArray("order").strings(),
            widgetOrder = sv.optJSONArray("widgetOrder").strings(),
            widgetHidden = sv.optJSONArray("widgetHidden").strings(),
            groups = groups,
        )
    }

    // Saves the current server's part (and the shared settings) back into the file
    @Synchronized fun saveData(d: BoardData, id: String = CUR) {
        val st = readStore()
        val sv = curServer(st, id)
        sv.put("title", d.title)
        sv.put("custom", JSONArray(d.custom))
        sv.put("edits", d.edits)
        sv.put("hidden", JSONArray(d.hidden))
        sv.put("order", JSONArray(d.order))
        sv.put("widgetOrder", JSONArray(d.widgetOrder))
        sv.put("widgetHidden", JSONArray(d.widgetHidden))
        sv.put("groups", JSONArray(d.groups.map { it.toJson() }))
        val own = JSONObject()
        val shared = st.getJSONObject("settings")
        for (k in d.settings.keys()) {
            if (k in SERVER_SETTING_KEYS) own.put(k, d.settings.get(k)) else shared.put(k, d.settings.get(k))
        }
        sv.put("settings", own)
        writeStore(st)
    }

    fun settings(id: String = CUR) = cleanSettings(loadData(id).settings)

    fun getTitle(id: String = CUR): String {
        val st = readStore()
        val l = servers(st)
        val sv = curServer(st, id)
        return titleAt(sv, l.indexOf(sv))
    }

    // All buttons: built-in (minus deleted, with edits applied), then custom.
    // via: which address to use (true = failover, false = main, null = the one the server is reached over now)
    fun getServices(forDashboard: Boolean, id: String = CUR, via: Boolean? = null): List<Service> {
        val d = loadData(id)
        val st = cleanSettings(d.settings)
        val host = serverHostOf(st).ifEmpty { "localhost" }
        val fo = failoverReady(st)
        val useFo = fo && (via ?: Route.onFailover(id))
        val base = BUILTIN.map { s ->
            val sid = "b:" + s.optString("name")
            val o = JSONObject(s.toString()).put("id", sid)
                .put("url", "${if (s.optBoolean("https")) "https" else "http"}://$host:${s.optString("port")}${s.optString("path")}")
            d.edits.optJSONObject(sid)?.let { e -> for (k in e.keys()) o.put(k, e.get(k)) }
            o
        }.filter { it.getString("id") !in d.hidden }
        val list = (base + d.custom).map { s ->
            val auto = s.optBoolean("auto")
            // an empty address follows the server's (main) address
            val main = if (auto) swapHost(s.optString("url"), splitUrl(s.optString("url")).host, host) else s.optString("url")
            val url2 = s.optString("url2", "")
            val foUrl = if (!fo) null else url2.ifEmpty { if (hostOf(main).equals(host, true)) swapHost(main, host, st.failoverHost) else "" }.ifEmpty { null }
            val url = if (useFo && foUrl != null) foUrl else main
            val u = splitUrl(url)
            val port = s.opt("port")?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
            Service(
                id = s.getString("id"), name = s.optString("name"), port = port, icon = s.optString("icon", "🔗").ifEmpty { "🔗" },
                logo = s.optString("logo", ""), url = url, custom = s.optBoolean("custom"),
                scheme = u.scheme, addr = u.host + u.path, label = if (port.isNotEmpty()) ":$port" else u.host,
                onWidget = s.getString("id") !in d.widgetHidden,
                zima = s.optString("zima", "").ifEmpty { s.optString("app", "") },
                ctr = s.optString("ctr", ""),
                mainUrl = main, auto = auto, url2 = url2, failoverUrl = foUrl,
            )
        }
        return if (forDashboard) sortByOrder(list, d.order) else list
    }

    fun <T : Entry> sortByOrder(list: List<T>, order: List<String>): List<T> {
        if (order.isEmpty()) return list
        fun idx(s: Entry) = order.indexOf(s.id).let { if (it < 0) Int.MAX_VALUE else it }
        return list.withIndex().sortedWith(compareBy({ idx(it.value) }, { it.index })).map { it.value }
    }

    // Top level = buttons not in a stack, plus stacks (each stack carries its member buttons).
    fun getLayout(id: String = CUR): Layout {
        val d = loadData(id)
        val all = getServices(false, id)
        val byId = all.associateBy { it.id }
        val inStack = HashSet<String>()
        val memberOf = HashMap<String, String>()
        val groups = d.groups.map { g ->
            val members = g.members.mapNotNull { byId[it] }.filter { it.id !in inStack }.distinctBy { it.id }
            for (s in members) { inStack.add(s.id); memberOf[s.id] = g.id }
            Stack(g.id, g.name, g.logo, g.expand, members.map { it.copy(group = g.id) }, g.id !in d.widgetHidden)
        }
        val allTagged = all.map { s -> memberOf[s.id]?.let { s.copy(group = it) } ?: s }
        val top: List<Entry> = allTagged.filter { it.id !in inStack } + groups
        return Layout(
            all = allTagged,
            groups = groups,
            dash = sortByOrder(top, d.order),
            widget = sortByOrder(top.filter { it.onWidget }, d.widgetOrder),
            hidden = top.filter { !it.onWidget },
        )
    }

    // What the large widget actually draws: stacks become one pill, or their members if "show members" is on
    fun widgetCells(layout: Layout, rows: Int): List<Entry> {
        val cells = ArrayList<Entry>()
        for (x in layout.widget) {
            if (x !is Stack) cells.add(x)
            else if (x.expand) cells.addAll(x.members)
            else if (x.members.isNotEmpty()) cells.add(x)
        }
        return cells.take(rows * 4)
    }

    // Create / edit / ungroup stacks and move buttons in or out of them
    data class StackAct(val act: String, val gid: String? = null, val member: String? = null, val name: String = "", val logo: String = "", val expand: Boolean = false, val id: String? = null, val to: String? = null)

    @Synchronized fun stackAction(a: StackAct) {
        val L = getLayout()
        val data = loadData()
        data.order = L.dash.map { it.id }.toMutableList()
        data.widgetOrder = L.widget.map { it.id }.toMutableList()
        fun strip(id: String) = data.groups.forEach { g -> g.members.removeAll { it == id } }
        fun holder(id: String) = data.groups.find { id in it.members }
        fun insertAt(list: List<String>, anchor: String?, ids: List<String>, after: Boolean): MutableList<String> {
            val out = list.filter { it !in ids }.toMutableList()
            var i = if (anchor != null) out.indexOf(anchor) else -1
            if (i < 0) return (out + ids).toMutableList()
            if (after) i++
            out.addAll(i, ids)
            return out
        }
        fun replaceIn(list: List<String>, oldId: String, ids: List<String>) = insertAt(list, oldId, ids, false).filter { it != oldId }.toMutableList()

        when (a.act) {
            "save" -> {
                val name = a.name.trim().take(24).ifEmpty { "Stack" }
                val logo = a.logo.trim()
                var g = data.groups.find { it.id == a.gid }
                if (g != null) {
                    g.name = name; g.logo = logo; g.expand = a.expand
                } else {
                    g = Group("g:" + System.currentTimeMillis(), name, logo, a.expand, mutableListOf())
                    if (a.member != null) {
                        val old = holder(a.member)
                        strip(a.member)
                        if (old != null) {
                            data.order = insertAt(data.order, old.id, listOf(g.id), true)
                            data.widgetOrder = insertAt(data.widgetOrder, old.id, listOf(g.id), true)
                        } else {
                            data.order = replaceIn(data.order, a.member, listOf(g.id))
                            data.widgetOrder = replaceIn(data.widgetOrder, a.member, listOf(g.id))
                        }
                        g.members.add(a.member)
                    } else {
                        data.order.add(g.id)
                        data.widgetOrder.add(g.id)
                    }
                    data.groups.add(g)
                }
                Logos.clearFail(logo)
            }
            "move" -> {
                val id = a.id ?: return
                val old = holder(id)
                strip(id)
                val to = a.to?.let { t -> data.groups.find { it.id == t } }
                if (to != null) {
                    to.members.add(id)
                    data.order.removeAll { it == id }
                    data.widgetOrder.removeAll { it == id }
                } else {
                    data.order = insertAt(data.order, old?.id, listOf(id), true)
                    data.widgetOrder = insertAt(data.widgetOrder, old?.id, listOf(id), true)
                }
            }
            "del" -> {
                val g = data.groups.find { it.id == a.gid }
                if (g != null) {
                    data.order = replaceIn(data.order, g.id, g.members)
                    data.widgetOrder = replaceIn(data.widgetOrder, g.id, g.members)
                    if (g.id in data.widgetHidden) {
                        data.widgetHidden = (data.widgetHidden.filter { it != g.id } + g.members).toMutableList()
                    }
                    data.groups.removeAll { it.id == g.id }
                }
            }
        }
        saveData(data)
    }

    // A button from the add / edit form. An empty address means the server's address (host).
    fun makeCustom(name: String, schemeSel: String, addr0: String, port0: String, logo: String, host: String = "localhost"): JSONObject {
        val auto = addr0.trim().isEmpty()
        val url = buildUrl(schemeSel, if (auto) host else addr0, port0)
        val port = port0.replace(Regex("[^0-9]"), "")
        return JSONObject().put("name", name.trim().take(24)).put("port", port).put("icon", "🔗").put("logo", logo.trim())
            .put("custom", true).put("url", url).put("auto", auto)
    }

    // scheme (unless typed in the address) + address (+ its path) + port
    fun buildUrl(schemeSel: String, addr0: String, port0: String): String {
        var addr = addr0.trim()
        val m = Regex("^(https?)://", RegexOption.IGNORE_CASE).find(addr)
        val scheme = m?.groupValues?.get(1)?.lowercase() ?: if (schemeSel == "https") "https" else "http"
        addr = addr.replace(Regex("^https?://", RegexOption.IGNORE_CASE), "")
        var path = ""
        val slash = addr.indexOf('/')
        if (slash >= 0) { path = addr.substring(slash); addr = addr.substring(0, slash) }
        val port = port0.replace(Regex("[^0-9]"), "")
        return "$scheme://$addr${if (port.isNotEmpty()) ":$port" else ""}$path"
    }

    // addr2: the failover address ("" = the server's failover address)
    fun saveService(editId: String?, name: String, scheme: String, addr: String, port: String, logo: String, onWidget: Boolean, addr2: String = "") {
        val data = loadData()
        val st = cleanSettings(data.settings)
        val item = makeCustom(name, scheme, addr, port, logo, serverHostOf(st).ifEmpty { "localhost" })
        item.put("url2", if (failoverReady(st) && addr2.trim().isNotEmpty()) buildUrl(scheme, addr2, port) else "")
        val keys = listOf("name", "port", "url", "logo", "auto", "url2")
        var id = editId
        if (editId != null && editId.startsWith("b:")) {
            val old = data.edits.optJSONObject(editId)
            data.edits.put(editId, JSONObject().also { e -> for (k in keys) e.put(k, item.get(k)); old?.optString("ctr")?.takeIf { it.isNotEmpty() }?.let { e.put("ctr", it) } })
        } else if (editId != null) {
            val c = data.custom.find { it.optString("id") == editId }
            if (c != null) for (k in keys) c.put(k, item.get(k))
        } else {
            id = "c:" + System.currentTimeMillis()
            item.put("id", id)
            data.custom.add(item)
        }
        data.widgetHidden.removeAll { it == id }
        if (!onWidget && id != null) data.widgetHidden.add(id)
        saveData(data)
        Logos.clearFail(logo.trim())
    }

    // Hold menu > Container: the container a button controls ("" = found by port or name again)
    fun linkCtr(id: String, ctr: String) {
        val data = loadData()
        if (id.startsWith("b:")) {
            val e = data.edits.optJSONObject(id) ?: JSONObject().also { data.edits.put(id, it) }
            if (ctr.isEmpty()) e.remove("ctr") else e.put("ctr", ctr)
            if (e.length() == 0) data.edits.remove(id)
        } else {
            val c = data.custom.find { it.optString("id") == id } ?: return
            if (ctr.isEmpty()) c.remove("ctr") else c.put("ctr", ctr)
        }
        saveData(data)
    }

    // ZimaOS: add installed apps as buttons, with their real address and icon
    fun addZimaApps(apps: List<ZApp>, host: String) {
        if (apps.isEmpty()) return
        val data = loadData()
        var n = 0
        val t = System.currentTimeMillis()
        for (a in apps) {
            data.custom.add(JSONObject().put("id", "c:$t-${n++}").put("name", a.title.take(24)).put("port", a.port).put("icon", "📦")
                .put("logo", a.icon).put("custom", true).put("zima", a.id).put("app", a.id).put("url", Zima.appUrl(a, host)))
            Logos.clearFail(a.icon)
        }
        saveData(data)
    }

    fun deleteService(id: String) {
        val data = loadData()
        if (id.startsWith("b:")) {
            data.edits.remove(id)
            if (id !in data.hidden) data.hidden.add(id)
        } else data.custom.removeAll { it.optString("id") == id }
        data.groups.forEach { g -> g.members.removeAll { it == id } }
        saveData(data)
    }
}
