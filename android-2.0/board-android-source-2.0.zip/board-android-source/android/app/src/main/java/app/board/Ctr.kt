package app.board

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- Containers on servers that aren't ZimaOS (hold a button: Start / Stop / Restart / Logs) ----------
// Proxmox VE: LXC containers and VMs (Proxmox API, saved login)
// TrueNAS: apps (JSON-RPC over a WebSocket on 25.04+, the REST API on 24.10; saved login)
// Synology DSM: Container Manager / Docker (DSM Web API, saved login)
// Unraid: Docker; the list comes from Glances, the commands are what Unraid's Docker page sends (saved login)
// OpenMediaVault and Linux: Docker or Podman through the -board helper on the server (Settings > Copy setup command)

data class Ctr(
    val id: String,                          // what the server's API takes (container name, "node/lxc/101", app name)
    val name: String,                        // shown, and matched against button names
    val status: String,                      // "running", "exited", "stopped" ... ("" = not known)
    val ports: List<String> = emptyList(),   // ports published on the server
    val ips: List<String> = emptyList(),     // the guest's own addresses (Proxmox)
    val kind: String = "container",          // "container", "app" (TrueNAS), "lxc" / "qemu" (Proxmox)
    val sub: List<String> = emptyList(),     // TrueNAS: the app's container ids (for its logs)
    val image: String = "",                  // the Docker image ("lscr.io/linuxserver/sonarr:latest"), for guessing a logo
    val icon: String = "",                   // a logo the server gives (TrueNAS apps)
) {
    val running get() = Regex("running|healthy|^up", RegexOption.IGNORE_CASE).containsMatchIn(status)
    val known get() = status.isNotEmpty()
    val label get() = when (kind) { "lxc" -> "LXC container"; "qemu" -> "Virtual machine"; "app" -> "App"; else -> "Container" }
}

// fix: what Settings > This server can do about it ("login", "loginAgain", "helper", "helperAgain", "helperOld",
// "monitoring"; null = nothing to set up, e.g. the server didn't answer)
class CtrErr(msg: String, val fix: String? = null) : IOException(msg)

object Ctrs {
    private val RI = RegexOption.IGNORE_CASE
    private fun isCancel(e: Exception) = e is kotlinx.coroutines.CancellationException
    private fun enc(x: String) = URLEncoder.encode(x, "UTF-8").replace("+", "%20")
    private val ANSI = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]|\u001B[()][A-Za-z0-9]|\u001B[=>]")
    private fun clean(t: String) = t.replace(ANSI, "").replace("\r", "")

    fun supported(P: String) = P in setOf("proxmox", "truenas", "unraid", "synology", "omv", "linux")
    fun usesHelper(P: String) = P == "omv" || P == "linux"

    private fun needLogin(P: String): Nothing = throw CtrErr("Enter your ${PLATFORMS[P]?.login ?: P} login first: Settings > This server > Enter login.", "login")
    private fun login(P: String): Pair<String, String> { if (!Secrets.hasLogin(P)) needLogin(P); return Secrets.savedLogin(P) }

    suspend fun list(s: Settings): List<Ctr> = when (s.platform) {
        "proxmox" -> pveList(s)
        "truenas" -> tnList(s)
        "synology" -> synoList(s)
        "unraid" -> unraidList(s)
        "omv", "linux" -> helperList(s)
        else -> throw CtrErr("Pick your server type first: Settings > This server > Server type.")
    }

    // action: "start", "stop" or "restart"
    suspend fun action(s: Settings, c: Ctr, action: String) = when (s.platform) {
        "proxmox" -> pveAction(s, c, action)
        "truenas" -> tnAction(s, c, action)
        "synology" -> synoAction(s, c, action)
        "unraid" -> unraidAction(s, c, action)
        else -> helperAction(s, c, action)
    }

    suspend fun logs(s: Settings, c: Ctr, lines: Int = 300): String {
        val t = when (s.platform) {
            "proxmox" -> pveLogs(s, c)
            "truenas" -> tnLogs(s, c, lines)
            "synology" -> synoLogs(s, c, lines)
            "unraid" -> unraidLogs(s, c, lines)
            else -> helperLogs(s, c, lines)
        }
        return clean(t).trimEnd().lines().takeLast(lines).joinToString("\n")
    }

    // ---------- "Pick from ..." in the + popup: what a new button for a container gets ----------
    // Ports that aren't web pages (DNS, discovery, torrents, databases, VPN ...)
    private val NOT_WEB = setOf(21, 22, 23, 25, 53, 67, 68, 69, 110, 123, 137, 138, 139, 143, 161, 389, 445, 514, 636, 993, 995,
        1194, 1883, 1900, 3306, 3478, 3479, 5353, 5432, 6379, 6881, 6882, 7359, 8883, 10001, 27017, 51413, 51820)
    private val HTTPS_PORTS = setOf(443, 5001, 8443, 9443)

    // The port its web page is most likely on ("" = none published)
    fun webPort(c: Ctr): String = c.ports.mapNotNull { it.toIntOrNull() }.filter { it !in NOT_WEB }.minOrNull()?.toString() ?: ""
    fun webScheme(port: String) = if (port.toIntOrNull() in HTTPS_PORTS) "https" else "http"

    // The guest's own address (Proxmox): its first IPv4 address
    fun ownAddr(c: Ctr) = c.ips.firstOrNull { Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$").matches(it) } ?: ""

    // "plex-media-server" -> "Plex Media Server"; names with capitals stay as they are
    fun title(c: Ctr): String {
        val n = c.name.trim()
        val t = if (n.any { it.isUpperCase() }) n else n.split(Regex("[-_. ]+")).filter { it.isNotEmpty() }.joinToString(" ") { it.replaceFirstChar { ch -> ch.uppercase() } }
        return t.ifEmpty { n }.take(24)
    }

    // dashboard-icons names to try for its logo: from the image ("lscr.io/linuxserver/sonarr:latest" -> sonarr), then the name
    fun logoSlugs(c: Ctr): List<String> {
        fun slug(x: String) = x.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        val img = c.image.substringAfterLast("/").substringBefore(":").substringBefore("@")
        return listOf(slug(img), slug(c.name)).filter { it.length >= 2 }.distinct()
    }

    // ---------- Which container a button is ----------
    fun norm(x: String) = x.lowercase().filter { it.isLetterOrDigit() }

    // The one picked by hand; else the guest at the button's address (Proxmox); else the only one published on the
    // button's port of the server; else the only one with the button's name (or a name that contains it)
    fun match(sv: Service, list: List<Ctr>, serverHost: String): Ctr? {
        if (sv.ctr.isNotEmpty()) return list.find { it.id == sv.ctr } ?: list.find { it.name.equals(sv.ctr, true) }
        val u = splitUrl(sv.url)
        list.filter { c -> c.ips.any { it.equals(u.host, true) } }.let { if (it.size == 1) return it[0] }
        if (u.host.equals(serverHost, true)) {
            val port = u.port.ifEmpty { if (u.scheme == "https") "443" else "80" }
            list.filter { port in it.ports }.let { if (it.size == 1) return it[0] }
        }
        val n = norm(sv.name)
        if (n.length < 2) return null
        list.filter { norm(it.name) == n }.let { if (it.size == 1) return it[0] }
        if (n.length >= 3) list.filter { val m = norm(it.name); m.length >= 3 && (m.contains(n) || n.contains(m)) }.let { if (it.size == 1) return it[0] }
        return null
    }

    // ---------- the -board helper (Linux, OpenMediaVault) ----------
    private suspend fun helper(s: Settings, path: String, method: String = "GET", timeout: Double = 20.0): JSONObject {
        if (!Secrets.hasLogin("linux")) throw CtrErr(
            "Set up the -board helper on the server first: Settings > This server > " + (if (s.platform == "omv") "Containers helper" else "Copy setup command") + ".", "helper"
        )
        val base = Power.helperBase(s)
        val r = try {
            Net.request(base + path, method, mapOf("Authorization" to "Bearer ${Secrets.get(Secrets.helperKey()) ?: ""}"), if (method == "POST") "" else null, timeout = timeout)
        } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach the -board helper at $base. Is it set up on the server?", "helperAgain") }
        if (r.code == 401) throw CtrErr("The helper refused the key. Copy the setup command from Settings and run it on the server again.", "helperAgain")
        if (r.code == 404) throw CtrErr("The helper on the server is from an older -board and can't control containers. Copy the setup command from Settings (This server) and run it on the server again.", "helperOld")
        val j = try { JSONObject(r.body) } catch (e: Exception) { throw CtrErr("The helper answered HTTP ${r.code}") }
        if (r.code >= 300 || !j.optBoolean("ok", true)) throw CtrErr(j.optString("error").ifEmpty { "The helper answered HTTP ${r.code}" })
        return j
    }

    private suspend fun helperList(s: Settings) = helper(s, "/containers").optJSONArray("containers").objs().map { o ->
        val st = o.optString("state").ifEmpty { o.optString("status") }
        Ctr(o.optString("id").ifEmpty { o.optString("name") }, o.optString("name"), st,
            o.optJSONArray("ports")?.let { a -> (0 until a.length()).map { a.opt(it).toString() } } ?: emptyList(), image = o.optString("image"))
    }.filter { it.name.isNotEmpty() }

    private suspend fun helperAction(s: Settings, c: Ctr, action: String) { helper(s, "/containers/${enc(c.id)}/$action", "POST", 120.0) }
    private suspend fun helperLogs(s: Settings, c: Ctr, lines: Int) = helper(s, "/containers/${enc(c.id)}/logs?lines=$lines").optString("text")

    // ---------- Proxmox VE ----------
    private val pveTickets = HashMap<String, Pair<Map<String, String>, Long>>()

    private suspend fun pveAuth(s: Settings, base: String): Map<String, String> {
        val (user, pass) = login("proxmox")
        val key = Store.CUR + "|" + base + "|" + user
        synchronized(pveTickets) { pveTickets[key] }?.let { (h, at) -> if (System.currentTimeMillis() - at < 60 * 60 * 1000L) return h }
        val r = try {
            Net.request("$base/api2/json/access/ticket", "POST", mapOf("Content-Type" to "application/x-www-form-urlencoded"), formBody("username" to Power.pveUser(user), "password" to pass))
        } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Proxmox at $base") }
        val d = try { JSONObject(r.body).optJSONObject("data") } catch (e: Exception) { null }
        val ticket = d?.optString("ticket").orEmpty()
        if (ticket.isEmpty()) throw CtrErr("Proxmox refused the saved login. Enter it again in Settings > This server.", "loginAgain")
        val h = mapOf("Cookie" to "PVEAuthCookie=$ticket", "CSRFPreventionToken" to d!!.optString("CSRFPreventionToken"))
        synchronized(pveTickets) { pveTickets[key] = h to System.currentTimeMillis() }
        return h
    }

    private suspend fun pve(s: Settings, path: String, method: String = "GET", body: String? = null, timeout: Double = 10.0, what: String = "do that"): Any? {
        val base = platformBase("proxmox", s)
        repeat(2) { attempt ->
            val h = pveAuth(s, base)
            val r = try {
                Net.request("$base/api2/json$path", method, h + (if (method == "POST") mapOf("Content-Type" to "application/x-www-form-urlencoded") else emptyMap()), body ?: if (method == "POST") "" else null, timeout = timeout)
            } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Proxmox at $base") }
            if (r.code == 401) { synchronized(pveTickets) { pveTickets.clear() }; if (attempt == 0) return@repeat; throw CtrErr("Proxmox refused the saved login. Enter it again in Settings > This server.", "loginAgain") }
            if (r.code == 403) throw CtrErr("This Proxmox user isn't allowed to $what.")
            if (r.code >= 300) throw CtrErr("Proxmox answered HTTP ${r.code}")
            return try { JSONObject(r.body).opt("data") } catch (e: Exception) { null }
        }
        return null
    }

    private suspend fun pveList(s: Settings): List<Ctr> {
        val arr = pve(s, "/cluster/resources?type=vm", what = "list the guests (needs VM.Audit)") as? JSONArray ?: JSONArray()
        val guests = arr.objs().filter { it.optInt("template", 0) != 1 && it.optString("type") in listOf("lxc", "qemu") }
        return coroutineScope {
            guests.map { o ->
                async {
                    val type = o.optString("type"); val node = o.optString("node"); val vmid = o.optString("vmid")
                    val status = o.optString("status")
                    // the guest's own addresses, to find it from a button's address
                    val ips = if (status != "running") emptyList() else try {
                        if (type == "lxc") (pve(s, "/nodes/${enc(node)}/lxc/$vmid/interfaces", timeout = 4.0) as? JSONArray).objs()
                            .flatMap { listOf(it.optString("inet"), it.optString("inet6")) }.map { it.substringBefore("/") }.filter { it.isNotEmpty() && it != "127.0.0.1" && it != "::1" }
                        else ((pve(s, "/nodes/${enc(node)}/qemu/$vmid/agent/network-get-interfaces", timeout = 4.0) as? JSONObject)?.optJSONArray("result")).objs()
                            .flatMap { it.optJSONArray("ip-addresses").objs().map { a -> a.optString("ip-address") } }.filter { it.isNotEmpty() && it != "127.0.0.1" && it != "::1" }
                    } catch (e: Exception) { if (isCancel(e)) throw e; emptyList() }
                    Ctr("$node/$type/$vmid", o.optString("name").ifEmpty { "$type $vmid" }, status, emptyList(), ips, type)
                }
            }.awaitAll()
        }.sortedBy { it.name.lowercase() }
    }

    private fun pveParts(c: Ctr): Triple<String, String, String> { val p = c.id.split("/"); return Triple(p[0], p[1], p[2]) }

    private suspend fun pveAction(s: Settings, c: Ctr, action: String) {
        val (node, type, vmid) = pveParts(c)
        // Stop shuts the guest down cleanly (like its Shutdown button), it doesn't pull the plug
        val cmd = when (action) { "start" -> "start"; "stop" -> "shutdown"; else -> "reboot" }
        pve(s, "/nodes/${enc(node)}/$type/$vmid/status/$cmd", "POST", timeout = 30.0, what = "start or stop guests (needs VM.PowerMgmt)")
    }

    // Proxmox keeps no console log of a guest: shows its recent Proxmox tasks and the log of the last one
    private suspend fun pveLogs(s: Settings, c: Ctr): String {
        val (node, _, vmid) = pveParts(c)
        val tasks = (pve(s, "/nodes/${enc(node)}/tasks?vmid=$vmid&limit=20&source=all", what = "read tasks (needs Sys.Audit)") as? JSONArray).objs()
        if (tasks.isEmpty()) return "No Proxmox tasks for this guest yet.\n(Proxmox keeps no console log of the guest itself.)"
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val sb = StringBuilder("Recent Proxmox tasks for ${c.name}:\n")
        for (t in tasks.reversed()) sb.append(f.format(Date(t.optLong("starttime") * 1000))).append("  ").append(t.optString("type").padEnd(10))
            .append("  ").append(t.optString("status").ifEmpty { "running" }).append("  ").append(t.optString("user")).append('\n')
        val last = tasks.first()
        val log = (pve(s, "/nodes/${enc(node)}/tasks/${enc(last.optString("upid"))}/log?limit=500") as? JSONArray).objs().joinToString("\n") { it.optString("t") }
        sb.append("\nLog of the last task (${last.optString("type")}):\n").append(log.ifEmpty { "(empty)" })
        sb.append("\n\n(Proxmox keeps no console log of the guest itself.)")
        return sb.toString()
    }

    // ---------- TrueNAS (apps, 24.10 and newer) ----------
    private data class Rpc(val ok: Boolean, val error: String? = null, val auth: Boolean = false, val connected: Boolean = false, val results: List<Any?> = emptyList(), val events: List<String> = emptyList())

    // Logs in, makes the calls one after another; with collectMs, then gathers the log lines the last call
    // (core.subscribe) sends for up to that long (stopping after a short quiet spell)
    private suspend fun tnRpc(base: String, user: String, pass: String, calls: List<Pair<String, JSONArray>>, collectMs: Long = 0): Rpc {
        val url = base.replaceFirst(Regex("^http", RI), "ws") + "/api/current"
        val done = CompletableDeferred<Rpc>()
        var connected = false
        var id = 0
        val pending = HashMap<Int, (JSONObject) -> Unit>()
        val results = ArrayList<Any?>()
        val events = ArrayList<String>()
        var lastEvent = 0L
        var collecting = false
        lateinit var ws: WebSocket
        fun finish(r: Rpc) { if (done.complete(r.copy(connected = connected, results = results, events = synchronized(events) { events.toList() }))) try { ws.close(1000, null) } catch (_: Exception) {} }
        fun call(method: String, params: JSONArray, cb: (JSONObject) -> Unit) {
            val i = ++id
            pending[i] = cb
            ws.send(JSONObject().put("jsonrpc", "2.0").put("id", i).put("method", method).put("params", params).toString())
        }
        fun err(m: JSONObject): String? {
            if (!m.has("error") || m.isNull("error")) return null
            val e = m.optJSONObject("error")
            return e?.optJSONObject("data")?.optString("reason")?.ifEmpty { null } ?: e?.optString("message")?.ifEmpty { null } ?: "error"
        }
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true
                call("auth.login", JSONArray().put(user).put(pass)) { m ->
                    if (err(m) != null || m.opt("result") != true) { finish(Rpc(false, auth = true)); return@call }
                    var k = 0
                    fun next() {
                        if (k >= calls.size) { if (collectMs > 0) { collecting = true; lastEvent = System.currentTimeMillis() } else finish(Rpc(true)); return }
                        val c = calls[k]
                        call(c.first, c.second) { r ->
                            err(r)?.let { finish(Rpc(false, it)); return@call }
                            results.add(r.opt("result")); k++; next()
                        }
                    }
                    next()
                }
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                val m = try { JSONObject(text) } catch (e: Exception) { return }
                if (m.has("id")) { pending.remove(m.optInt("id", -1))?.invoke(m); return }
                if (m.optString("method") == "collection_update") {
                    val f = m.optJSONObject("params")?.optJSONObject("fields") ?: return
                    synchronized(events) { events.add(f.optString("data")) }
                    lastEvent = System.currentTimeMillis()
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { finish(Rpc(collecting, if (collecting) null else "connection")) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { finish(Rpc(collecting, if (collecting) null else "closed")) }
        }
        ws = try { Net.client(15.0).newWebSocket(Request.Builder().url(url).build(), listener) } catch (e: Exception) { return Rpc(false, e.toString()) }
        if (collectMs > 0) {
            // wait for the calls, then for the lines (a 1.2 s quiet spell after the last line ends it early)
            withTimeoutOrNull(15000) { while (!collecting && !done.isCompleted) delay(50) }
            if (collecting) {
                val until = System.currentTimeMillis() + collectMs
                while (!done.isCompleted && System.currentTimeMillis() < until && System.currentTimeMillis() - lastEvent < 1200) delay(100)
                finish(Rpc(true))
            }
        }
        return withTimeoutOrNull(20000) { done.await() } ?: run { finish(Rpc(false, "timeout")); done.await() }
    }

    private fun tnApp(o: JSONObject): Ctr {
        val w = o.optJSONObject("active_workloads")
        val ports = w?.optJSONArray("used_ports").objs().flatMap { p -> p.optJSONArray("host_ports").objs().map { it.opt("host_port").toString() } }.distinct()
        val ids = w?.optJSONArray("container_details").objs().map { it.optString("id") }.filter { it.isNotEmpty() }
        val name = o.optString("name")
        val meta = o.optJSONObject("metadata")
        return Ctr(name, name, o.optString("state").lowercase(), ports, emptyList(), "app", ids,
            image = meta?.optString("name").orEmpty(), icon = meta?.optString("icon").orEmpty().takeIf { it.startsWith("http", true) }.orEmpty())
    }

    private fun tnErr(r: Rpc, what: String): Nothing = throw CtrErr(
        if (r.auth) "TrueNAS refused the saved login. Enter it again in Settings > This server." else "TrueNAS couldn't $what: ${r.error ?: "no answer"}"
    )

    private fun tnRestAuth(user: String, pass: String) = mapOf("Authorization" to "Basic " + android.util.Base64.encodeToString("$user:$pass".toByteArray(), android.util.Base64.NO_WRAP))

    private suspend fun tnList(s: Settings): List<Ctr> {
        val (u, p) = login("truenas")
        val base = platformBase("truenas", s)
        val r = tnRpc(base, u, p, listOf("app.query" to JSONArray()))
        if (r.ok) return (r.results.firstOrNull() as? JSONArray).objs().map { tnApp(it) }
        if (r.connected) tnErr(r, "list its apps")
        // older TrueNAS (24.10): the REST API
        val rr = try { Net.request("$base/api/v2.0/app", headers = tnRestAuth(u, p)) } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach TrueNAS at $base") }
        if (rr.code == 401) throw CtrErr("TrueNAS refused the saved login. Enter it again in Settings > This server.", "loginAgain")
        if (rr.code == 404) throw CtrErr("This TrueNAS has no apps API. App controls need TrueNAS SCALE 24.10 or newer.")
        if (rr.code >= 300) throw CtrErr("TrueNAS answered HTTP ${rr.code}")
        return (try { JSONArray(rr.body) } catch (e: Exception) { JSONArray() }).objs().map { tnApp(it) }
    }

    private suspend fun tnAction(s: Settings, c: Ctr, action: String) {
        val (u, p) = login("truenas")
        val base = platformBase("truenas", s)
        // Restart redeploys the app, as TrueNAS's own Restart button does
        val m = when (action) { "start" -> "app.start"; "stop" -> "app.stop"; else -> "app.redeploy" }
        val r = tnRpc(base, u, p, listOf(m to JSONArray().put(c.id)))
        if (r.ok) return
        if (r.connected) tnErr(r, "$action ${c.name}")
        val rr = try { Net.request("$base/api/v2.0/app/${m.removePrefix("app.")}", "POST", tnRestAuth(u, p) + ("Content-Type" to "application/json"), JSONObject.quote(c.id)) }
        catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach TrueNAS at $base") }
        if (rr.code == 401) throw CtrErr("TrueNAS refused the saved login. Enter it again in Settings > This server.", "loginAgain")
        if (rr.code >= 300) throw CtrErr("TrueNAS didn't accept the command (HTTP ${rr.code}).")
    }

    private suspend fun tnLogs(s: Settings, c: Ctr, lines: Int): String {
        val (u, p) = login("truenas")
        val base = platformBase("truenas", s)
        if (c.sub.isEmpty()) return if (c.running) "TrueNAS didn't list a container for ${c.name}." else "${c.name} isn't running, so it has no containers to show logs for."
        val sb = StringBuilder()
        for (cid in c.sub.take(4)) {
            val ev = "app.container_log_follow:" + JSONObject().put("app_name", c.id).put("container_id", cid).put("tail_lines", lines)
            val r = tnRpc(base, u, p, listOf("core.subscribe" to JSONArray().put(ev)), collectMs = 6000)
            if (!r.ok) {
                if (!r.connected) throw CtrErr("Logs need TrueNAS 25.04 or newer (its WebSocket API).")
                tnErr(r, "show the logs")
            }
            if (c.sub.size > 1) sb.append("── container ${cid.take(12)} ──\n")
            sb.append(r.events.joinToString("") { if (it.endsWith("\n")) it else it + "\n" })
        }
        return sb.toString()
    }

    // ---------- Synology DSM (Container Manager / Docker package) ----------
    private suspend fun synoSid(base: String): String {
        val (user, pass) = login("synology")
        val login = arrayOf<Pair<String, Any>>("api" to "SYNO.API.Auth", "method" to "login", "account" to user, "passwd" to pass, "session" to "board", "format" to "sid")
        val j = try {
            var j = JSONObject(syno(base, "entry.cgi", *login, "version" to 6).body)
            if (!j.optBoolean("success") && j.optJSONObject("error")?.optInt("code") in listOf(102, 103, 104)) j = JSONObject(syno(base, "auth.cgi", *login, "version" to 3).body)
            j
        } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Synology DSM at $base") }
        return j.optJSONObject("data")?.optString("sid")?.ifEmpty { null } ?: throw CtrErr("Synology refused the saved login. Enter it again in Settings > This server.", "loginAgain")
    }

    private suspend fun syno(base: String, cgi: String, vararg params: Pair<String, Any>) =
        Net.request("$base/webapi/$cgi", "POST", mapOf("Content-Type" to "application/x-www-form-urlencoded"), formBody(*params), timeout = 30.0)

    private suspend fun synoCall(s: Settings, api: String, method: String, vararg params: Pair<String, Any>): JSONObject {
        val base = platformBase("synology", s)
        val sid = synoSid(base)
        val j = try { JSONObject(syno(base, "entry.cgi", "api" to api, "version" to 1, "method" to method, *params, "_sid" to sid).body.ifEmpty { "{}" }) }
        catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Synology didn't answer") }
        if (!j.optBoolean("success", false)) {
            val code = j.optJSONObject("error")?.optInt("code")
            throw CtrErr(when (code) {
                102 -> "Container Manager (or the Docker package) isn't installed on this Synology."
                105 -> throw CtrErr("This Synology account isn't an administrator.", "loginAgain")
                else -> "Synology didn't accept the command (error $code)."
            })
        }
        return j.optJSONObject("data") ?: JSONObject()
    }

    private suspend fun synoList(s: Settings): List<Ctr> {
        val d = synoCall(s, "SYNO.Docker.Container", "list", "limit" to -1, "offset" to 0, "type" to "\"all\"")
        return d.optJSONArray("containers").objs().map { o ->
            val st = o.optString("status").ifEmpty { if (o.optJSONObject("State")?.optBoolean("Running") == true) "running" else "stopped" }
            val ports = (o.optJSONArray("port_bindings") ?: o.optJSONArray("Ports")).objs()
                .mapNotNull { p -> (p.opt("host_port") ?: p.opt("PublicPort"))?.toString()?.takeIf { it.isNotEmpty() && it != "0" } }.distinct()
            Ctr(o.optString("name").removePrefix("/"), o.optString("name").removePrefix("/"), st.lowercase(), ports, image = o.optString("image"))
        }.filter { it.name.isNotEmpty() }
    }

    private suspend fun synoAction(s: Settings, c: Ctr, action: String) {
        val name = "name" to JSONObject.quote(c.id)
        if (action != "restart") { synoCall(s, "SYNO.Docker.Container", action, name); return }
        try { synoCall(s, "SYNO.Docker.Container", "restart", name) }
        catch (e: CtrErr) { synoCall(s, "SYNO.Docker.Container", "stop", name); synoCall(s, "SYNO.Docker.Container", "start", name) }
    }

    private suspend fun synoLogs(s: Settings, c: Ctr, lines: Int): String {
        val d = synoCall(s, "SYNO.Docker.Container.Log", "get", "name" to JSONObject.quote(c.id), "from" to "\"\"", "to" to "\"\"",
            "level" to "\"\"", "keyword" to "\"\"", "sort_dir" to "\"DESC\"", "offset" to 0, "limit" to lines)
        return d.optJSONArray("logs").objs().reversed().joinToString("\n") { it.optString("text").trimEnd() }
    }

    // ---------- Unraid (Docker) ----------
    private suspend fun unraidSession(base: String): Pair<String, String> {
        val (user, pass) = login("unraid")
        val lg = try { Net.request("$base/login", "POST", mapOf("Content-Type" to "application/x-www-form-urlencoded"), formBody("username" to user.ifEmpty { "root" }, "password" to pass), follow = false) }
        catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Unraid at $base") }
        if (lg.code !in 300..399) throw CtrErr("Unraid refused the saved login. Enter it again in Settings > This server.", "loginAgain")
        val cookie = lg.cookies()
        val html = try { Net.request("$base/Docker", headers = mapOf("Cookie" to cookie)).body } catch (e: Exception) { if (isCancel(e)) throw e; "" }
        val m = Regex("csrf_token[\"'\\s]*[:=]\\s*[\"']([0-9A-Za-z]{8,})[\"']").find(html) ?: throw CtrErr("Logged in to Unraid, but couldn't read its security token.")
        return cookie to m.groupValues[1]
    }

    // the list comes from Glances (its Containers plugin), which runs with access to Docker on most Unraid setups
    private suspend fun unraidList(s: Settings): List<Ctr> {
        if (!s.monitoring) throw CtrErr("On Unraid the container list comes from Glances: turn on Monitoring in Settings > This server.", "monitoring")
        val g = Glances(s)
        val raw = try { g.request("containers") } catch (e: Exception) {
            if (isCancel(e)) throw e
            try { g.request("docker") } catch (e2: Exception) { if (isCancel(e2)) throw e2; throw CtrErr("Glances didn't list the containers. Glances needs access to Docker (map /var/run/docker.sock into the Glances container).") }
        }
        val arr = raw as? JSONArray ?: (raw as? JSONObject)?.optJSONArray("containers") ?: JSONArray()
        val list = arr.objs().map { o ->
            val name = o.optString("name").ifEmpty { o.optString("Names") }.removePrefix("/")
            val img = o.opt("image").let { if (it is JSONArray) it.optString(0) else it?.toString().orEmpty() }
            Ctr(name, name, o.optString("status").ifEmpty { o.optString("Status") }.lowercase(), image = img)
        }.filter { it.name.isNotEmpty() }
        if (list.isEmpty()) throw CtrErr("Glances lists no containers. Glances needs access to Docker (map /var/run/docker.sock into the Glances container).")
        return list
    }

    // what Unraid's Docker page sends for Start / Stop / Restart
    private suspend fun unraidAction(s: Settings, c: Ctr, action: String) {
        val base = platformBase("unraid", s)
        val (cookie, csrf) = unraidSession(base)
        val r = try {
            Net.request("$base/plugins/dynamix.docker.manager/include/Events.php", "POST", mapOf("Cookie" to cookie, "Content-Type" to "application/x-www-form-urlencoded"),
                formBody("action" to action, "container" to c.id, "csrf_token" to csrf), timeout = 120.0)
        } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Unraid at $base") }
        if (r.code >= 300) throw CtrErr("Unraid didn't accept the command (HTTP ${r.code}).")
        val b = r.body.trim()
        if (b.isNotEmpty() && !b.contains("success", true) && b.contains(Regex("error|no such|not found", RI))) throw CtrErr("Unraid: " + b.take(200))
    }

    // what Unraid's Docker page shows for Logs: a log window (ttyd) running "docker logs"
    private suspend fun unraidLogs(s: Settings, c: Ctr, lines: Int): String {
        val base = platformBase("unraid", s)
        val (cookie, csrf) = unraidSession(base)
        try {
            Net.request("$base/webGui/include/OpenTerminal.php?tag=docker&name=${enc(c.id)}&more=.log&csrf_token=$csrf", headers = mapOf("Cookie" to cookie))
        } catch (e: Exception) { if (isCancel(e)) throw e; throw CtrErr("Can't reach Unraid at $base") }
        delay(700)
        val url = base.replaceFirst(Regex("^http", RI), "ws") + "/logterminal/${enc(c.id)}.log/ws"
        val out = StringBuilder()
        val done = CompletableDeferred<String?>()
        var last = System.currentTimeMillis()
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(JSONObject().put("AuthToken", "").put("columns", 160).put("rows", 60).toString())
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { take(bytes.utf8()) }
            override fun onMessage(webSocket: WebSocket, text: String) { take(text) }
            fun take(m: String) { if (m.startsWith("0")) synchronized(out) { out.append(m.substring(1)) }; last = System.currentTimeMillis() }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { done.complete(if (response != null) "HTTP ${response.code}" else "connection") }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { done.complete(null) }
        }
        val ws = Net.client(15.0).newWebSocket(Request.Builder().url(url).header("Cookie", cookie).header("Sec-WebSocket-Protocol", "tty").build(), listener)
        val until = System.currentTimeMillis() + 7000
        while (!done.isCompleted && System.currentTimeMillis() < until && (out.isEmpty() || System.currentTimeMillis() - last < 1200)) delay(100)
        try { ws.close(1000, null) } catch (_: Exception) {}
        val err = if (done.isCompleted) done.await() else null
        val text = synchronized(out) { out.toString() }
        if (text.isEmpty() && err != null) throw CtrErr("Unraid didn't open the log ($err).")
        return text.lines().takeLast(lines).joinToString("\n")
    }
}
