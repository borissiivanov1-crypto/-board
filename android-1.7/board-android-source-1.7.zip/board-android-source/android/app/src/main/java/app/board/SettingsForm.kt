package app.board

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

// A one-tap fix offered under a failed Test connection line
data class Fix(val code: String, val label: String)
data class TestLine(val ok: Boolean, val text: String, val fixes: List<Fix> = emptyList())

// A problem that keeps one setting from being saved, and the Settings page it's on
// lost: closing now throws away something typed (false = the setting simply isn't filled in yet)
data class FormProblem(val page: String, val msg: String, val lost: Boolean = true)

// Settings pages
const val PAGE_SERVER = "server"
const val PAGE_WIDGET = "widget"
const val PAGE_BUTTONS = "buttons"
const val PAGE_LOOK = "look"
const val PAGE_BACKUP = "backup"
const val PAGE_ABOUT = "about"
val PAGE_TITLES = linkedMapOf(
    PAGE_SERVER to "This server",
    PAGE_WIDGET to "Widget",
    PAGE_BUTTONS to "Buttons",
    PAGE_LOOK to "Appearance",
    PAGE_BACKUP to "Backup",
    PAGE_ABOUT to "About",
)

/**
 * The open Settings sheet. It lives in the ViewModel, so rotating the phone, switching dark mode or changing the
 * font size keeps it open with everything typed. Every change is saved as soon as it's made; only a value that
 * can't be saved yet (e.g. an empty server address) is held back, and Save then asks "Discard changes?".
 * Cancel puts back the settings, the name and the Glances password as they were when Settings opened.
 */
class SettingsForm(val serverId: String, val f: JSONObject, title: String, page: String?, val origGpass: String? = null) {
    // what was saved when Settings opened: Cancel puts it back
    val orig = f.toString()
    val origTitle = title
    var ver by mutableIntStateOf(0)
    var page by mutableStateOf(page)
    var title by mutableStateOf(title)
    var gpass by mutableStateOf("")
    var info by mutableStateOf<SettingsInfo?>(null)
    var problems by mutableStateOf<List<FormProblem>>(emptyList())
    var testLines by mutableStateOf<List<TestLine>?>(null)
    var testing by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var loginOpen by mutableStateOf<String?>(null)
    var lu by mutableStateOf("")
    var lp by mutableStateOf("")
    var lerr by mutableStateOf("")
    var askDiscard by mutableStateOf(false)
    // bumped to scroll the page back to the top (a fix that points at the address or login)
    var scrollSeq by mutableIntStateOf(0)
    var savedAny = false

    // what would be lost by closing now ("" = nothing)
    fun unsaved(): String {
        val l = ArrayList<String>()
        problems.filter { it.lost }.forEach { l.add(it.msg) }
        if (loginOpen != null && (lu.isNotEmpty() || lp.isNotEmpty())) l.add("The login you typed hasn't been checked and saved yet.")
        return l.joinToString("\n")
    }
}

/**
 * Checks the form. Returns the settings to save (any value that isn't valid is replaced by the one saved before,
 * so everything else still saves) and the problems found.
 */
fun validateForm(f: JSONObject, stored: JSONObject): Pair<JSONObject, List<FormProblem>> {
    val out = JSONObject(f.toString())
    val probs = ArrayList<FormProblem>()
    fun revert(vararg keys: String) { for (k in keys) if (stored.has(k)) out.put(k, stored.get(k)) else out.remove(k) }
    fun str(k: String) = f.opt(k)?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
    val digits = Regex("^\\d+$")
    val nums = listOf(
        Triple("maxDisks", PAGE_SERVER, "MAX DRIVES"), Triple("liveSeconds", PAGE_SERVER, "DASHBOARD UPDATES EVERY"),
        Triple("refreshMinutes", PAGE_WIDGET, "REFRESH EVERY"), Triple("statusSeconds", PAGE_BUTTONS, "CHECK UP/DOWN EVERY"),
        Triple("pingTimeout", PAGE_BUTTONS, "COUNT AS DOWN AFTER"),
    )
    for ((k, page, label) in nums) if (!digits.matches(str(k))) { revert(k); probs.add(FormProblem(page, "$label: use a whole number")) }
    val tl = f.optJSONObject("tempLimits") ?: JSONObject()
    for (k in TEMP_DEFAULTS.keys) {
        val t = tl.optJSONObject(k) ?: JSONObject()
        val w = t.opt("warm")?.toString() ?: ""; val h = t.opt("hot")?.toString() ?: ""
        val msg = if (!digits.matches(w) || !digits.matches(h)) "Temperature colours: use whole numbers"
        else if (h.toInt() <= w.toInt()) "Temperature colours: red has to start above orange (${k.uppercase()})" else null
        if (msg != null) { revert("tempLimits"); probs.add(FormProblem(PAGE_SERVER, msg)); break }
    }
    if (str("serverHost").trim().isEmpty()) { revert("serverHost", "serverPort", "serverScheme"); probs.add(FormProblem(PAGE_SERVER, "Enter your server's IP or name (This server > Server address)", lost = (stored.opt("serverHost") as? String).orEmpty().isNotEmpty())) }
    if (f.optBoolean("failover")) {
        if (str("failoverHost").trim().isEmpty()) { revert("failover", "failoverHost"); probs.add(FormProblem(PAGE_SERVER, "Enter the failover server address, or switch Failover off")) }
        else if (str("failoverHost").trim().equals(str("serverHost").trim(), true)) { revert("failover", "failoverHost"); probs.add(FormProblem(PAGE_SERVER, "The failover server address has to be different from the main server address")) }
    }
    if (str("baseUrl").isNotEmpty() && !Regex("^https?://[^/:]+", RegexOption.IGNORE_CASE).containsMatchIn(str("baseUrl"))) { revert("baseUrl"); probs.add(FormProblem(PAGE_SERVER, "The Glances address must start with http:// or https://")) }
    return out to probs
}
