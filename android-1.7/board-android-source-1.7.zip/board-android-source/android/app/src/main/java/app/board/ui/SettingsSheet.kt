package app.board.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.board.ACCENTS
import app.board.BoardVM
import app.board.PLATFORMS
import app.board.SettingsInfo
import app.board.SettingsForm
import app.board.Store
import app.board.PAGE_SERVER
import app.board.PAGE_WIDGET
import app.board.PAGE_BUTTONS
import app.board.PAGE_LOOK
import app.board.PAGE_BACKUP
import app.board.PAGE_ABOUT
import app.board.PAGE_TITLES
import app.board.THEMES
import app.board.TEMP_DEFAULTS
import app.board.cleanSettings
import app.board.formatBytes
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsSheet(vm: BoardVM, F: SettingsForm, onDelete: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val f = F.f
    val logins = F.info?.logins.orEmpty()

    // picks and switches: saved now and the page redrawn; typing: saved after a short pause
    fun touch() = vm.formChanged(redraw = true)
    fun typed() = vm.formChanged()
    fun str(k: String) = f.opt(k)?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
    fun bool(k: String) = f.optBoolean(k)
    fun msg(t: String) { vm.showToast(t, 3000) }
    fun run(block: suspend () -> Unit) { if (F.busy) return; F.busy = true; scope.launch { try { block() } finally { F.busy = false } } }
    fun setLogin(P: String, v: Boolean) { F.info = F.info?.let { it.copy(logins = it.logins + (P to v)) } }
    fun test() {
        if (F.testing) return
        F.testing = true
        F.testLines = null
        scope.launch {
            try { F.testLines = vm.settingsTest(f, F.gpass) } finally { F.testing = false }
        }
    }
    // a one-tap fix under a failed Test connection line
    fun fix(code: String) {
        when {
            code == "addr" || code == "type" || code == "glances" -> { F.page = PAGE_SERVER; F.scrollSeq++ }
            code == "login" -> { F.page = PAGE_SERVER; F.loginOpen = str("platform"); F.lu = ""; F.lp = ""; F.lerr = ""; F.scrollSeq++ }
            code == "failoverOff" -> { f.put("failover", false); touch(); msg("Failover switched off"); test() }
            code == "monOff" -> { f.put("monitoring", false); touch(); msg("Monitoring switched off"); test() }
            code.startsWith("api") -> { f.put("apiVersion", code.removePrefix("api").toInt()); touch(); msg("Glances API version ${code.removePrefix("api")} picked"); test() }
            code == "helper" -> { msg(vm.settingsHelper(f)); setLogin("linux", true) }
        }
    }

    val page = F.page
    Modal({ vm.closeSettings() }, wide = true, top = true, onBack = { if (F.page != null) F.page = null else vm.closeSettings() }, scrollKey = page to F.scrollSeq) {
        // header: Cancel (puts back what was there when Settings opened), title with the server's name, Save
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallBtn("Cancel") { vm.cancelSettings() }
            Column(Modifier.weight(1f).padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T((PAGE_TITLES[page] ?: "Settings").uppercase(), 17.sp, FontWeight.ExtraBold, spacing = 1.sp, maxLines = 1)
                Caps(if (page == null || page == PAGE_SERVER) vm.title else "Shared by all servers", 10.sp, .55f)
            }
            SmallBtn("Save", true) { vm.closeSettings() }
        }
        // on a page: back to the list of pages
        if (page != null) Row { SmallBtn("‹ All settings") { F.page = null } }
        val I = F.info
        if (I == null) {
            T("Loading...", 13.sp, alpha = .6f, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp))
            return@Modal
        }
        // settings that couldn't be saved yet (everything else is saved as you change it)
        val probs = F.problems.filter { page == null || it.page == page }
        if (probs.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for (pr in probs) Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { ResLine(false, "Not saved: ${pr.msg}") }
                if (page == null) { Spacer(Modifier.width(8.dp)); Chip("Fix") { F.page = pr.page } }
            }
        }
        androidx.compose.runtime.key(F.ver, page) {
            val first = F.ver == 0
            when (page) {
                null -> IndexPage(F, I, first)
                PAGE_SERVER -> ServerPage(vm, F, I, first, logins, ::touch, ::typed, ::run, ::msg, ::setLogin, onDelete, ::test, ::fix)
                PAGE_WIDGET -> Sec("WIDGET", 0, first) {
                    Hint("Each widget shows one server: when you add it (or long-press it and pick Reconfigure) you choose the server. The first server is the default.")
                    NumSetting(f, "refreshMinutes", "REFRESH EVERY (MINUTES)", "5", ::typed)
                    Hint("Android refreshes widgets at most every 15 minutes in the background, so smaller values count as 15. When you leave the dashboard, widgets showing that server take its latest figures straight away, with no extra requests to the server.")
                    TextSetting(f, "linkUrl", "CORNER BUTTON LINK", "https://... (empty = no button)", KeyboardType.Uri, ::typed)
                    Hint("A small button in the widget corner, e.g. your ZimaOS or Proxmox page.")
                    ToggleSetting(f, "widgetStatusDots", "STATUS DOTS ON THE WIDGET", ::touch)
                    Hint("Each widget refresh checks every button, which takes a couple of seconds.")
                    TextSetting(f, "widgetTitle", "WIDGET TITLE", "Same as the dashboard name", onTyped = ::typed)
                    Labeled("BUTTON ROWS") { Select((1..6).map { "$it" to "$it row${if (it > 1) "s" else ""} (${it * 4} buttons)" }, str("widgetRows")) { f.put("widgetRows", it.toInt()); touch() } }
                }
                PAGE_BUTTONS -> {
                    Sec("BUTTONS", 0, first) {
                        ToggleSetting(f, "useLogos", "SHOW LOGOS", ::touch)
                        Hint("Off shows the emoji instead.")
                        Labeled("DASHBOARD COLUMNS") { Select(listOf("2" to "2 columns", "3" to "3 columns"), str("columns")) { f.put("columns", it.toInt()); touch() } }
                        NumSetting(f, "statusSeconds", "CHECK UP/DOWN EVERY (SECONDS)", "30", ::typed)
                        NumSetting(f, "pingTimeout", "COUNT AS DOWN AFTER (SECONDS)", "3", ::typed)
                        Hint("How long a service may take to answer. The widget waits at most 3 seconds.")
                        if (I.hidden.isNotEmpty()) Labeled("DELETED BUTTONS") {
                            for (h in I.hidden) SRow(h.removePrefix("b:")) { Chip("Restore") { msg(vm.settingsRestore(h)); F.info = I.copy(hidden = I.hidden - h) } }
                        }
                    }
                    Sec("LOGOS & LAYOUT", 1, first) {
                        Btn("Clear logo cache", modifier = Modifier.fillMaxWidth()) { msg(vm.settingsClearLogos()) }
                        var armR by remember { mutableStateOf(false) }
                        val view = androidx.compose.ui.platform.LocalView.current
                        Btn(if (armR) "Tap again to reset the layout" else "Reset layout", BtnKind.RedText, Modifier.fillMaxWidth()) {
                            if (!armR) { armR = true; return@Btn }
                            armR = false
                            Haptic.confirm(view)
                            msg(vm.settingsReset())
                        }
                        Hint("Reset layout clears this server's button order and stacks but keeps your own buttons.")
                    }
                }
                PAGE_LOOK -> LookPage(f, first, ::touch)
                PAGE_BACKUP -> Sec("BACKUP", 0, first) {
                    Btn("Export settings", modifier = Modifier.fillMaxWidth()) { msg(vm.settingsExport()) }
                    var armI by remember { mutableStateOf(false) }
                    Btn(if (armI) "Tap again to replace everything" else "Import settings", modifier = Modifier.fillMaxWidth()) {
                        if (!armI) { armI = true; return@Btn }
                        armI = false
                        val (ok, m) = vm.settingsImport()
                        if (!ok) msg(m) else { msg(m); vm.closeSettings(force = true) }
                    }
                    Hint("Export copies every server's settings, buttons, stacks and layout to the clipboard (passwords stay on the phone). Import reads them back from the clipboard, including an export from the iPhone (Scriptable) version, and replaces what's here.")
                    Hint("Automatic backup: every save writes a complete new copy before the old one is replaced, and the previous version is kept on the phone. If the settings file is ever damaged (say the phone switched off mid-save), -board restores the last good copy and tells you, instead of starting empty.")
                }
                PAGE_ABOUT -> AboutPage(vm, first)
            }
        }
    }
}

// The list of pages
@Composable
private fun IndexPage(F: SettingsForm, I: SettingsInfo, first: Boolean) {
    val f = F.f
    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        if (I.firstRun) Note("Welcome to -board. Open This server, enter your server's IP or name and pick its server type, then tap Test connection at the bottom of that page. After that, add your services with the + button.")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = if (first) Modifier.enter(1) else Modifier) {
            Divider("THIS SERVER")
            val P = f.optString("platform")
            val host = f.optString("serverHost")
            PageRow("This server", listOf(if (host.isNotEmpty()) host else "No address yet", PLATFORMS[P]?.shortName ?: "type not picked", if (f.optBoolean("monitoring")) "Monitoring on" else "Monitoring off").joinToString(" · ")) { F.page = PAGE_SERVER }
            Divider("SHARED BY ALL SERVERS")
            PageRow("Widget", "Refresh, corner button, status dots, rows") { F.page = PAGE_WIDGET }
            PageRow("Buttons", "Logos, columns, up / down checks, layout") { F.page = PAGE_BUTTONS }
            PageRow("Appearance", "Style, theme, accent, glow, font") { F.page = PAGE_LOOK }
            PageRow("Backup", "Export and import, automatic backup") { F.page = PAGE_BACKUP }
            PageRow("About", "Version and how -board keeps your data") { F.page = PAGE_ABOUT }
        }
        Hint("Changes are saved as you make them.")
    }
}

@Composable
private fun PageRow(title: String, sub: String, onClick: () -> Unit) {
    val look = LocalLook.current
    val src = rememberSource()
    val sh = RoundedCornerShape(if (look.sharp) 10.dp else 16.dp)
    Row(
        Modifier.fillMaxWidth().pressScale(look, src, .98f).clip(sh)
            .then(if (look.liquid) Modifier.glass(look, sh, .8f) else Modifier.background(Color.White.copy(alpha = .05f), sh).border(1.dp, Color.White.copy(alpha = .08f), sh))
            .clickable(src, null) { onClick() }.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            T(title, 15.sp, FontWeight.Bold, maxLines = 1)
            T(sub, 11.sp, alpha = .5f, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
        T("›", 22.sp, FontWeight.Light, alpha = .5f)
    }
}

// ---------- This server: server, login, monitoring, delete ----------
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ServerPage(
    vm: BoardVM, F: SettingsForm, I: SettingsInfo, first: Boolean, logins: Map<String, Boolean>,
    touch: () -> Unit, typed: () -> Unit, run: (suspend () -> Unit) -> Unit, msg: (String) -> Unit, setLogin: (String, Boolean) -> Unit, onDelete: (String) -> Unit,
    test: () -> Unit, fix: (String) -> Unit,
) {
    val f = F.f
    fun str(k: String) = f.opt(k)?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
    fun bool(k: String) = f.optBoolean(k)
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        val P = str("platform")
        Sec("SERVER", 0, first) {
            Labeled("SERVER NAME") { Field(F.title, { F.title = it; typed() }, "e.g. NAS", maxLength = 20) }
            Labeled("SERVER TYPE") { Seg(typeOpts(), P, wrap = true) { f.put("platform", it); touch() } }
            Hint(TYPE_HINT[P] ?: TYPE_HINT["none"]!!)
            val fo = bool("failover")
            androidx.compose.runtime.key(P) {
                ServerAddrField(if (fo) "MAIN SERVER ADDRESS" else "SERVER ADDRESS", P, str("serverHost"), str("serverScheme"), str("serverPort")) { h, pt, sc ->
                    f.put("serverHost", h); f.put("serverPort", pt); f.put("serverScheme", sc); typed()
                }
            }
            Hint(addrHint(P))
            ToggleSetting(f, "failover", "FAILOVER ADDRESS (OPTIONAL)", touch)
            if (fo) {
                FailoverAddrField(str("failoverHost")) { f.put("failoverHost", it); typed() }
                Hint(FAILOVER_HINT)
            } else Hint("On: a second address for this server, used when the main server address doesn't answer.")
            val pl = PLATFORMS[P]
            // an older separate address for the server system on another host (still used until it's cleared)
            if (pl != null && str(pl.url).isNotEmpty()) {
                SRow("Reboot / Shut down use ${str(pl.url)}", "A separate address from an older version of -board") {
                    Chip("Use the server address") { f.put(pl.url, ""); touch() }
                }
            }
            if (P == "proxmox") {
                TextSetting(f, "proxmoxNode", "NODE NAME", "Automatic (e.g. pve)", onTyped = typed)
                Hint("Only needed in a cluster: the node to reboot, as shown in the Proxmox web UI.")
            } else if (P == "linux") {
                Chip(if (logins["linux"] == true) "Copy setup command" else "Create key & copy setup command") {
                    msg(vm.settingsHelper(f)); setLogin("linux", true)
                }
                Hint("Then SSH into the server (ssh you@${str("serverHost").ifEmpty { I.host.ifEmpty { "192.168.1.10" } }}), paste and press Enter. It asks for your sudo password once, installs the helper as a system service and opens its port in ufw / firewalld if they're on. Run it again after changing the address or port.")
            }
            if (pl != null && P != "linux") {
                val LN = pl.login!!
                val openLogin = { F.loginOpen = P; F.lu = ""; F.lp = ""; F.lerr = "" }
                if (logins[P] == true) {
                    SRow("$LN login saved", "Stored encrypted on this phone") {
                        Chip("Change") { openLogin() }
                        Spacer(Modifier.width(6.dp))
                        Chip("Forget") { msg(vm.settingsForget(P)); setLogin(P, false) }
                    }
                } else {
                    SRow("No $LN login saved", "Enter it now, or you'll be asked the first time you use Reboot / Shut down") {
                        Chip("Enter login") { openLogin() }
                    }
                }
                if (F.loginOpen == P) {
                    val sh = RoundedCornerShape(14.dp)
                    Column(Modifier.fillMaxWidth().clip(sh).background(Color.White.copy(alpha = .04f)).border(1.dp, Color.White.copy(alpha = .1f), sh).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Labeled("${LN.uppercase()} USERNAME") { Field(F.lu, { F.lu = it }, pl.userPh) }
                        Labeled("${LN.uppercase()} PASSWORD") { Field(F.lp, { F.lp = it }, password = true) }
                        if (F.lerr.isNotEmpty()) ResLine(false, F.lerr)
                        Row {
                            Chip("Cancel") { F.loginOpen = null; F.lu = ""; F.lp = "" }
                            Spacer(Modifier.width(8.dp))
                            Chip(if (F.busy) "Checking..." else "Check & save login") {
                                if (F.lu.trim().isEmpty() || F.lp.isEmpty()) { F.lerr = "Enter a username and a password."; return@Chip }
                                F.lerr = ""
                                run {
                                    val (ok, m) = vm.settingsLogin(P, F.lu, F.lp, f)
                                    if (!ok) F.lerr = m else { setLogin(P, true); F.loginOpen = null; F.lu = ""; F.lp = ""; vm.showToast(m, 3500) }
                                }
                            }
                        }
                        Hint("Checked against the server at the address above, then stored encrypted on this phone." + if (P == "proxmox") " Typing root means root@pam." else "")
                    }
                }
            } else if (P == "linux" && logins["linux"] == true) {
                SRow("Helper key saved", "Stored encrypted on this phone") {
                    Chip("Forget") { msg(vm.settingsForget("linux")); setLogin("linux", false) }
                }
            }
            ToggleSetting(f, "showPower", "SHOW REBOOT / SHUT DOWN", touch)
            Hint("Off hides the arrow and menu next to the server name. After Reboot, the LIVE pill shows Rebooting… until the server answers again.")
        }

        // ---------- MONITORING ----------
        Sec("MONITORING", 1, first) {
            ToggleSetting(f, "monitoring", "MONITORING (GLANCES)", touch)
            val mon = bool("monitoring")
            Hint(if (mon) "CPU, RAM, storage and network from Glances, in a fold-away panel on the dashboard (folded, it shows the figures in one line) and as gauges on the widget."
            else "Off: no Monitoring panel, no gauges on the widget (it shows your service buttons instead), and -board sends no requests to Glances. The LIVE / OFFLINE status still works.")
            if (mon) {
                val gh = str("serverHost").ifEmpty { I.host }
                GlancesUrlField(f, gh, typed)
                Hint("Leave empty for ${if (gh.isNotEmpty()) "http://$gh:61208" else "the server address on port 61208"}. Otherwise pick http or https and type the IP or name; port 61208 is added for IP addresses and local names unless you type another. A public domain (behind a reverse proxy) gets no port added.")
                Labeled("GLANCES API VERSION") { Select(listOf("4" to "4 (Glances 4.x)", "3" to "3 (Glances 3.x)"), str("apiVersion")) { f.put("apiVersion", it.toInt()); touch() } }
                TextSetting(f, "username", "GLANCES USERNAME", "Only if Glances has a password", onTyped = typed)
                Labeled("GLANCES PASSWORD") { Field(F.gpass, { F.gpass = it; typed() }, if (I.hasGpass) "Saved. Leave empty to keep it" else "Optional", password = true) }
                if (I.hasGpass) Chip("Remove saved Glances password") { msg(vm.removeGlancesPassword()) }
                Labeled("DRIVES IN THE STORAGE CARD") {
                    val chosen = (f.optJSONArray("diskMounts") ?: JSONArray()).let { a -> (0 until a.length()).map { a.optString(it) } }
                    if (!I.mounts.isNullOrEmpty()) {
                        val shown = I.mounts.map { Triple(it.mnt, it, false) } + chosen.filter { m -> I.mounts.none { it.mnt == m } }.map { Triple(it, null, true) }
                        for ((mnt, m, missing) in shown) {
                            val sub = if (missing) "Not found in Glances right now" else formatBytes(m!!.size) + (if (m.dev.isNotEmpty()) " · ${m.dev}" else "") + (if (m.size > 0) " · ${Math.round(m.used / m.size * 100)}% used" else "")
                            SRow(mnt, sub) {
                                Switch(mnt in chosen) { on ->
                                    val l = chosen.filter { it != mnt }.toMutableList()
                                    if (on) l.add(mnt)
                                    f.put("diskMounts", JSONArray(l)); touch()
                                }
                            }
                        }
                    } else {
                        var txt by remember { mutableStateOf(chosen.joinToString(", ")) }
                        Field(txt, { txt = it; f.put("diskMounts", JSONArray(it.split(",").map { x -> x.trim() }.filter { x -> x.isNotEmpty() })); typed() }, "/, /mnt/data")
                    }
                }
                Hint(if (!I.mounts.isNullOrEmpty()) "None picked = pick automatically. Paths are as the Glances container sees them." else "Couldn't reach Glances to list the drives, so type the paths, separated by commas. Empty = pick automatically.")
                NumSetting(f, "maxDisks", "MAX DRIVES WHEN PICKED AUTOMATICALLY", "3", typed)
                val ifo = mutableListOf("" to "Automatic (the busiest)")
                I.ifaces?.forEach { ifo.add(it to it) }
                if (str("networkInterface").isNotEmpty() && ifo.none { it.first == str("networkInterface") }) ifo.add(str("networkInterface") to str("networkInterface"))
                Labeled("NETWORK INTERFACE") { Select(ifo, str("networkInterface")) { f.put("networkInterface", it); touch() } }
                if (I.ifaces == null) Hint("Couldn't reach Glances to list the interfaces.")
                ToggleSetting(f, "monitoringOpen", "OPEN MONITORING ON START", touch)
                ToggleSetting(f, "monitoringFixed", "KEEP MONITORING ALWAYS OPEN", touch)
                Hint("Removes the Monitoring button, so the cards and network speed always show.")
                NumSetting(f, "liveSeconds", "DASHBOARD UPDATES EVERY (SECONDS)", "3", typed)
                Hint("Lower = smoother graphs, more battery while the dashboard is open.")
                Labeled("TEMPERATURE COLOURS (°C)") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Spacer(Modifier.width(60.dp))
                        Caps("ORANGE FROM", 10.sp, .5f, Modifier.weight(1f), .12f)
                        Caps("RED FROM", 10.sp, .5f, Modifier.weight(1f), .12f)
                    }
                    val tl = f.optJSONObject("tempLimits") ?: JSONObject().also { f.put("tempLimits", it) }
                    for ((k, label) in listOf("cpu" to "CPU", "nvme" to "NVMe", "hdd" to "HDD")) {
                        val row = tl.optJSONObject(k) ?: JSONObject().also { tl.put(k, it) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            T(label, 13.sp, FontWeight.Bold, alpha = .8f, modifier = Modifier.width(60.dp).padding(start = 4.dp))
                            for (w in listOf("warm", "hot")) {
                                var v by remember { mutableStateOf(row.opt(w)?.toString() ?: "") }
                                Field(v, { v = it.trim(); row.put(w, v); typed() }, keyboard = KeyboardType.Number, height = 40.dp, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // ---------- TEST CONNECTION: where you end up after typing the server and Monitoring details ----------
        Sec("TEST CONNECTION", 2, first) {
            Btn(if (F.testing) "Testing..." else "Test connection", BtnKind.Ok, Modifier.fillMaxWidth()) { test() }
            F.testLines?.let { lines ->
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (l in lines) {
                        ResLine(l.ok, l.text)
                        if (l.fixes.isNotEmpty()) FlowRow(Modifier.padding(start = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (x in l.fixes) Chip(x.label) { fix(x.code) }
                        }
                    }
                }
            }
            Hint(if (F.testLines == null) "Checks the server address, Glances and Reboot / Shut down with the values above. Anything that fails comes with a button that fixes it."
            else "Tap a button under a red line to fix it.")
        }

        // ---------- DELETE SERVER ----------
        Sec("DELETE SERVER", 3, first) {
            val only = vm.servers.size < 2
            Btn("Delete ${vm.title}", BtnKind.RedText, Modifier.fillMaxWidth(), enabled = !only) { onDelete(vm.title) }
            Hint(if (only) "This is your only server, so it can't be deleted. Add another server first (swipe the server name left)."
            else "Deletes this server's settings, logins, buttons, stacks and layout from the phone. Your other servers stay. Asks to confirm.")
        }
    }
}

// ---------- Appearance ----------
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LookPage(f: JSONObject, first: Boolean, touch: () -> Unit) {
    fun str(k: String) = f.opt(k)?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
    Sec("THEME & LOOK", 0, first) {
        Labeled("STYLE") { Seg(listOf("classic" to "Classic", "glass" to "Liquid Glass"), str("style")) { f.put("style", it); touch() } }
        Hint(if (str("style") == "glass") "Liquid Glass: iOS 26 style glass cards with a bright rim, a third background glow, springy animation on every press, menu and sheet, and glass rings on the widget."
        else "Classic: the plain -board look. Switch to Liquid Glass for glass cards and animations.")
        ToggleSetting(f, "splash", "STARTUP ANIMATION", touch)
        Hint("A short animated -board logo when the dashboard opens (tap it to skip). Works with either style.")
        Swatches("THEME", THEMES.map { (k, t) ->
            Swatch(k, t.name, if (t.noGlow) Brush.linearGradient(listOf(Color.Black, Color.Black)) else Brush.radialGradient(listOf(rgb(t.g1), rgb(t.g1, 0f)), Offset(30f, 28f), 70f), hex(t.bg), Brush.radialGradient(listOf(rgb(t.g2), rgb(t.g2, 0f)), Offset(90f, 100f), 80f))
        }, str("theme")) { f.put("theme", it); touch() }
        val ta = hex((THEMES[str("theme")] ?: THEMES["aurora"]!!).acc)
        Swatches("ACCENT COLOUR", ACCENTS.map { (k, a) ->
            val c = if (a.c != null) hex(a.c) else ta
            Swatch(k, if (a.c != null) a.name else "Same as theme", Brush.linearGradient(listOf(c, c)), c, null, dashed = a.c == null)
        }, str("accent")) { f.put("accent", it); touch() }
        Hint("Used for switches, buttons and the selected tab. Status colours (green / orange / red) stay the same.")
        Labeled("BACKGROUND GLOW") { Select(listOf("off" to "Off", "soft" to "Soft", "normal" to "Normal", "strong" to "Strong"), str("glow")) { f.put("glow", it); touch() } }
        ToggleSetting(f, "movingBg", "MOVING BACKGROUND", touch)
        Hint("Off keeps the glow still (saves a little battery).")
        Labeled("CARD STYLE") { Select(listOf("subtle" to "Subtle glass", "normal" to "Normal glass", "strong" to "Strong glass"), str("cardStyle")) { f.put("cardStyle", it); touch() } }
        Labeled("CORNERS") { Select(listOf("round" to "Rounded", "sharp" to "Sharper"), str("corners")) { f.put("corners", it); touch() } }
        Labeled("FONT") { Select(listOf("system" to "System", "rounded" to "Rounded", "serif" to "Serif"), str("font")) { f.put("font", it); touch() } }
        Labeled("BUTTON SIZE") { Select(listOf("normal" to "Normal", "compact" to "Compact"), str("buttonSize")) { f.put("buttonSize", it); touch() } }
        Hint("Each pick applies straight away, on the dashboard behind this sheet and on the widget. The widget background follows the theme and glow.")
    }
}

// ---------- About ----------
@Composable
private fun AboutPage(vm: BoardVM, first: Boolean) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val ver = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Sec("-BOARD", 0, first) {
            SRow("Version", "-board for Android") { T(ver, 14.sp, FontWeight.Bold) }
            SRow("Servers", vm.servers.joinToString(", ") { it.title }) { T("${vm.servers.size}", 14.sp, FontWeight.Bold) }
            Hint("A live dashboard and home screen widget for your home server: LIVE / OFFLINE, Glances monitoring, service buttons, and Reboot / Shut down for ZimaOS, Proxmox, TrueNAS, Unraid, Synology, OpenMediaVault and Linux.")
        }
        Sec("YOUR DATA", 1, first) {
            Hint("Settings, buttons and layout are stored only on this phone and saved as you change them. Logins are stored encrypted (Android Keystore) and never leave the phone, not even in an export.")
            Hint("Every save writes a complete new copy first and keeps the previous one as a backup, so a phone that switches off mid-save can't wipe your servers and buttons.")
            Store.loadNote?.let { ResLine(false, it) }
        }
        Sec("THANKS", 2, first) {
            Hint("Monitoring figures come from Glances (nicolargo/glances). Logos come from the dashboard-icons collection.")
        }
    }
}

@Composable
private fun SmallBtn(text: String, ok: Boolean = false, onClick: () -> Unit) {
    val look = LocalLook.current
    val src = rememberSource()
    val sh = RoundedCornerShape(12.dp)
    Box(
        Modifier.height(36.dp).pressScale(look, src).clip(sh)
            .then(if (ok) Modifier.background(look.acc) else if (look.liquid) Modifier.glass(look, sh, 1.6f) else Modifier.background(Color.White.copy(alpha = .12f)))
            .clickable(src, null) { onClick() }.padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { T(text, 15.sp, FontWeight.Bold, if (ok) look.ink else Color.White) }
}

@Composable
private fun Divider(t: String) = T(t, 11.sp, FontWeight.ExtraBold, alpha = .5f, spacing = 1.8.sp, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))

@Composable
private fun Sec(title: String, index: Int, animate: Boolean, content: @Composable ColumnScope.() -> Unit) {
    val look = LocalLook.current
    Column(if (animate) Modifier.enter(index) else Modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Caps(title, 12.sp, .6f, Modifier.padding(horizontal = 4.dp))
        val sh = RoundedCornerShape(if (look.sharp) 10.dp else 18.dp)
        Column(
            Modifier.fillMaxWidth().then(if (look.liquid) Modifier.glass(look, sh, .8f) else Modifier.background(Color.White.copy(alpha = .05f), sh).border(1.dp, Color.White.copy(alpha = .08f), sh)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content,
        )
    }
}

@Composable
private fun SRow(title: String, sub: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 14.sp, FontWeight.Bold, maxLines = 1)
            if (sub != null) T(sub, 11.sp, alpha = .5f, modifier = Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
private fun ResLine(ok: Boolean, t: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 4.dp).size(8.dp).clip(CircleShape).background(if (ok) GREEN else RED))
        Spacer(Modifier.width(8.dp))
        T(t, 12.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun TextSetting(f: JSONObject, key: String, label: String, ph: String, kb: KeyboardType = KeyboardType.Text, onTyped: () -> Unit) {
    var v by remember { mutableStateOf(f.optString(key)) }
    Labeled(label) { Field(v, { v = it; f.put(key, it.trim()); onTyped() }, ph, keyboard = kb) }
}

@Composable
private fun NumSetting(f: JSONObject, key: String, label: String, ph: String, onTyped: () -> Unit) {
    var v by remember { mutableStateOf(f.opt(key)?.toString() ?: "") }
    Labeled(label) { Field(v, { v = it.trim(); f.put(key, v); onTyped() }, ph, keyboard = KeyboardType.Number) }
}

@Composable
private fun ToggleSetting(f: JSONObject, key: String, label: String, onTouch: () -> Unit) {
    ToggleRow(label, f.optBoolean(key)) { f.put(key, it); onTouch() }
}

data class Swatch(val v: String, val name: String, val top: Brush, val base: Color, val second: Brush?, val dashed: Boolean = false)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Swatches(label: String, items: List<Swatch>, value: String, onPick: (String) -> Unit) {
    val look = LocalLook.current
    Labeled(label) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (it in items) {
                val on = it.v == value
                val src = rememberSource()
                Box(
                    Modifier.size(44.dp).pressScale(look, src, .85f).clip(CircleShape).background(it.base).background(it.top).then(if (it.second != null) Modifier.background(it.second) else Modifier)
                        .border(if (on) 3.dp else 2.dp, if (on) Color.White else Color.White.copy(alpha = if (it.dashed) .5f else .15f), CircleShape)
                        .clickable(src, null) { onPick(it.v) },
                )
            }
        }
        T(items.find { it.v == value }?.name ?: "", 12.sp, alpha = .6f, modifier = Modifier.padding(start = 4.dp, top = 2.dp))
    }
}

// Glances address: http / https list plus IP or name; port 61208 is added for IP addresses and local names
@Composable
private fun GlancesUrlField(f: JSONObject, host: String, onTyped: () -> Unit) {
    val portOf = 61208
    val cur0 = f.optString("baseUrl")
    val m0 = Regex("^(https?)://(.*)$", RegexOption.IGNORE_CASE).find(cur0)
    var sel by remember { mutableStateOf(m0?.groupValues?.get(1)?.lowercase() ?: "http") }
    var text by remember { mutableStateOf((m0?.groupValues?.get(2) ?: "").replace(Regex("^([^/:]+):$portOf(?=/|$)"), "$1")) }
    fun local(h: String) = Regex("^[0-9.]+$").matches(h) || h.startsWith("[") || !h.contains(".") || Regex("[.](local|lan|home|internal|localdomain|home[.]arpa|ts[.]net)$", RegexOption.IGNORE_CASE).containsMatchIn(h)
    fun compose() {
        var v = text.trim()
        val mm = Regex("^(https?)://(.*)$", RegexOption.IGNORE_CASE).find(v)
        if (mm != null) { sel = mm.groupValues[1].lowercase(); v = mm.groupValues[2].replace(Regex("/+$"), ""); text = v }
        v = v.replace(Regex("/+$"), "")
        var h = v
        if (h.isEmpty()) {
            if (sel == "http" || host.isEmpty()) { f.put("baseUrl", ""); onTyped(); return }
            h = host
        }
        val hp = Regex("^([^/:]+)(:[0-9]+)?(.*)$").find(h)
        val port = if (hp != null && hp.groupValues[2].isEmpty() && local(hp.groupValues[1])) ":$portOf" else ""
        f.put("baseUrl", "$sel://" + if (hp != null) hp.groupValues[1] + hp.groupValues[2] + port + hp.groupValues[3] else h)
        onTyped()
    }
    Labeled("GLANCES ADDRESS") {
        Field(text, { text = it; compose() }, if (host.isNotEmpty()) "$host (the server)" else "IP or name", keyboard = KeyboardType.Uri, leading = { SchemePick(sel) { sel = it; compose() } })
    }
}
