package app.board

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

// ---------- More of ZimaOS (2.5): the ZimaOS panel ----------
// System, storage, USB, shares, network drives, remote access (ZeroTier), notifications, app sources, app settings,
// ZimaOS modules and an app's details / compose file. These are the CasaOS services ZimaOS is built on
// (casaos, local-storage, user-service, app-management), read from their open-source code. Each part is asked on its
// own: one that this ZimaOS doesn't have (HTTP 404) just shows "not offered" and the rest still work.

data class ZNet(val name: String, val state: String, val sent: Double, val recv: Double)
data class ZInfo(
    val version: String = "", val deviceName: String = "", val model: String = "", val arch: String = "",
    val cpuPct: Double? = null, val cores: Int = 0, val cpuKind: String = "",
    val memTotal: Double = 0.0, val memUsed: Double = 0.0, val memPct: Double? = null,
    val nets: List<ZNet> = emptyList(), val extra: List<Pair<String, String>> = emptyList(),
)
data class ZVolume(val label: String, val mount: String, val path: String, val fs: String, val size: Double, val used: Double, val avail: Double, val disk: String)
data class ZPool(val mount: String, val fs: String, val count: Int)
data class ZUsbPart(val name: String, val mount: String, val size: Double, val avail: Double)
data class ZUsb(val name: String, val model: String, val size: Double, val parts: List<ZUsbPart>)
data class ZShare(val id: String, val path: String, val anonymous: Boolean)
data class ZConn(val id: String, val host: String, val port: String, val user: String, val mount: String)
data class ZEvent(val uuid: String, val source: String, val name: String, val title: String, val message: String, val time: Long)
data class ZZt(val id: String, val name: String, val status: String) { val online get() = status.equals("online", true) || status.equals("ok", true) }
data class ZHealth(val running: List<String>, val stopped: List<String>)
data class ZSource(val id: String, val url: String)
data class ZGlobal(val key: String, val value: String, val desc: String)
data class ZModule(val name: String, val title: String, val icon: String, val entry: String)
data class ZCtrInfo(val name: String, val image: String, val state: String, val health: String)
data class ZAppDetail(
    val status: String, val update: Boolean, val main: String, val containers: List<ZCtrInfo>,
    val ports: List<String>, val folders: List<String>, val env: List<Pair<String, String>>, val images: List<String>,
)

object ZimaMore {
    const val NOT_OFFERED = "This ZimaOS doesn't offer this."

    private fun enc(x: String) = URLEncoder.encode(x, "UTF-8").replace("+", "%20")
    private fun num(x: Any?) = Zima.numOf(x)

    // one call; HTTP 404 / 405 become NOT_OFFERED
    private suspend fun get(s: Settings, path: String, method: String = "GET", body: String? = null, timeout: Double = 12.0,
                            headers: Map<String, String> = emptyMap(), exactType: Boolean = false, dropOk: Boolean = false): Any? {
        val r = Zima.call(s, path, method, body, timeout = timeout, headers = headers, exactType = exactType, dropOk = dropOk)
        if (r != null && (r.code == 404 || r.code == 405)) throw ZimaErr(NOT_OFFERED)
        return Zima.data(r)
    }
    private suspend fun opt(s: Settings, path: String): Any? = try { get(s, path, timeout = 8.0) } catch (e: Exception) {
        if (e is kotlinx.coroutines.CancellationException) throw e
        if (e is ZimaErr && e.auth) throw e
        null
    }

    private fun arrOf(d: Any?, vararg keys: String): JSONArray = when (d) {
        is JSONArray -> d
        is JSONObject -> keys.firstNotNullOfOrNull { d.optJSONArray(it) } ?: JSONArray()
        is String -> try { JSONArray(d) } catch (e: Exception) { JSONArray() }
        else -> JSONArray()
    }
    private fun str(o: JSONObject, vararg k: String) = k.firstNotNullOfOrNull { key -> o.opt(key)?.takeIf { it != JSONObject.NULL }?.toString()?.trim()?.takeIf { it.isNotEmpty() } } ?: ""

    // ---------- System ----------
    fun parseUtil(d: Any?, into: ZInfo): ZInfo {
        val o = d as? JSONObject ?: return into
        val cpu = o.optJSONObject("cpu")
        val mem = o.optJSONObject("mem")
        val nets = arrOf(o.opt("net")).objs().map { n ->
            ZNet(n.optString("name"), n.optString("state"), num(n.opt("bytesSent")) ?: 0.0, num(n.opt("bytesRecv")) ?: 0.0)
        }.filter { it.name.isNotEmpty() }
        return into.copy(
            cpuPct = num(cpu?.opt("percent")), cores = (num(cpu?.opt("num")) ?: 0.0).toInt(), cpuKind = cpu?.optString("model").orEmpty(),
            memTotal = num(mem?.opt("total")) ?: 0.0, memUsed = num(mem?.opt("used")) ?: 0.0, memPct = num(mem?.opt("usedPercent")),
            nets = nets,
        )
    }

    // /v1/sys/version: { current_version, need_update, version: {...} } or a plain string
    fun parseVersion(d: Any?): String = when (d) {
        is String -> d.trim()
        is JSONObject -> str(d, "current_version", "version_name").ifEmpty { d.optJSONObject("version")?.let { str(it, "version") } ?: str(d, "version") }
        else -> ""
    }

    // ZimaOS's own device info: name, model and whatever else it sends that is short and readable
    fun parseDevice(d: Any?, into: ZInfo): ZInfo {
        val o = d as? JSONObject ?: return into
        val skip = setOf("device_name", "hash", "device_image_path", "image", "icon", "token", "password")
        val extra = o.keys().asSequence().filter { it !in skip }.mapNotNull { k ->
            val v = o.opt(k)
            if (v is JSONObject || v is JSONArray || v == null || v == JSONObject.NULL) return@mapNotNull null
            val t = v.toString().trim()
            if (t.isEmpty() || t.length > 60) null else k.replace('_', ' ').replaceFirstChar { it.uppercase() } to t
        }.take(12).toList()
        return into.copy(
            deviceName = str(o, "device_name", "name"), model = into.model.ifEmpty { str(o, "device_model", "model") },
            version = into.version.ifEmpty { str(o, "os_version", "version") }, extra = extra,
        )
    }

    suspend fun info(s: Settings): ZInfo {
        var i = ZInfo()
        get(s, "/v1/sys/utilization", timeout = 8.0).let { i = parseUtil(it, i) }
        i = i.copy(version = parseVersion(opt(s, "/v1/sys/version")))
        (opt(s, "/v1/sys/hardware") as? JSONObject)?.let { h -> i = i.copy(model = str(h, "drive_model", "model"), arch = str(h, "arch")) }
        i = parseDevice(opt(s, "/v2/zimaos/device/info"), i)
        return i
    }

    fun parseHealth(d: Any?): ZHealth {
        val o = d as? JSONObject ?: return ZHealth(emptyList(), emptyList())
        fun l(k: String) = arrOf(o.opt(k)).let { a -> (0 until a.length()).map { a.optString(it).removeSuffix(".service") }.filter { it.isNotEmpty() } }
        return ZHealth(l("running"), l("not_running"))
    }
    suspend fun health(s: Settings) = parseHealth(get(s, "/v2/casaos/health/services"))

    suspend fun errorLog(s: Settings, lines: Int = 200): String {
        val d = get(s, "/v1/sys/logs?line=$lines", timeout = 15.0)
        val t = when (d) {
            is JSONArray -> (0 until d.length()).joinToString("\n") { d.opt(it).toString() }
            null -> ""
            else -> d.toString()
        }
        return t.replace(Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]"), "").replace("\r", "").trimEnd()
    }

    // ---------- Storage ----------
    // /v1/storage: [ { disk_name, path, size, type, children: [ { label, mount_point, size, used, avail (strings, bytes), type, path } ] } ]
    fun parseVolumes(d: Any?): List<ZVolume> = arrOf(d, "list").objs().flatMap { disk ->
        val dn = str(disk, "disk_name", "model").ifEmpty { disk.optString("path").substringAfterLast("/") }
        arrOf(disk.opt("children")).objs().map { c ->
            ZVolume(
                str(c, "label").ifEmpty { c.optString("mount_point").substringAfterLast("/").ifEmpty { "Volume" } },
                c.optString("mount_point"), c.optString("path"), c.optString("type"),
                num(c.opt("size")) ?: 0.0, num(c.opt("used")) ?: 0.0, num(c.opt("avail")) ?: 0.0, dn,
            )
        }
    }.filter { it.mount.isNotEmpty() && it.fs != "swap" && it.mount != "/boot/efi" }.distinctBy { it.mount }

    suspend fun volumes(s: Settings) = parseVolumes(get(s, "/v1/storage?system=show", timeout = 15.0))

    // /v2/local_storage/merge: the storage pool (several drives seen as one /DATA)
    fun parsePools(d: Any?): List<ZPool> = arrOf(d, "list").objs().map { m ->
        ZPool(m.optString("mount_point"), m.optString("fstype"), arrOf(m.opt("source_volume_uuids")).length())
    }.filter { it.mount.isNotEmpty() }
    suspend fun pools(s: Settings): List<ZPool> = try { parsePools(get(s, "/v2/local_storage/merge")) } catch (e: Exception) {
        if (e is kotlinx.coroutines.CancellationException) throw e
        if (e is ZimaErr && e.auth) throw e
        emptyList()   // 503 when the pool isn't set up
    }

    fun parseUsb(d: Any?): List<ZUsb> = arrOf(d, "list").objs().map { u ->
        ZUsb(
            u.optString("name"), u.optString("model").trim(), num(u.opt("size")) ?: 0.0,
            arrOf(u.opt("children")).objs().map { c -> ZUsbPart(c.optString("name"), c.optString("mount_point"), num(c.opt("size")) ?: 0.0, num(c.opt("avail")) ?: 0.0) }
                .filter { it.mount.isNotEmpty() },
        )
    }
    suspend fun usb(s: Settings) = parseUsb(get(s, "/v1/disks/usb"))
    // Safe removal: ZimaOS unmounts it, then it can be pulled out
    suspend fun eject(s: Settings, mount: String) { get(s, "/v1/disks/usb", "DELETE", JSONObject().put("mount_point", mount).toString(), timeout = 30.0) }

    suspend fun usbAuto(s: Settings): Boolean = get(s, "/v1/usb/usb-auto-mount").toString().equals("true", true)
    suspend fun setUsbAuto(s: Settings, on: Boolean) { get(s, "/v1/usb/usb-auto-mount", "PUT", JSONObject().put("state", if (on) "on" else "off").toString()) }

    // ---------- Shares (Samba) ----------
    fun parseShares(d: Any?) = arrOf(d, "list").objs().map { ZShare(str(it, "id"), it.optString("path"), it.optBoolean("anonymous", true)) }.filter { it.path.isNotEmpty() }
    suspend fun shares(s: Settings) = parseShares(get(s, "/v1/samba/shares"))
    suspend fun addShare(s: Settings, path: String) { get(s, "/v1/samba/shares", "POST", JSONArray().put(JSONObject().put("path", path).put("anonymous", true)).toString(), timeout = 20.0) }
    suspend fun delShare(s: Settings, id: String) { get(s, "/v1/samba/shares/${enc(id)}", "DELETE", timeout = 20.0) }

    fun parseConns(d: Any?) = arrOf(d, "list").objs().map {
        ZConn(str(it, "id"), it.optString("host"), str(it, "port").ifEmpty { "445" }, it.optString("username"), it.optString("mount_point"))
    }.filter { it.host.isNotEmpty() }
    suspend fun conns(s: Settings) = parseConns(get(s, "/v1/samba/connections"))
    // Mounts a share of another computer on ZimaOS (it shows in ZimaOS's Files)
    suspend fun addConn(s: Settings, host: String, port: String, user: String, pass: String) {
        get(s, "/v1/samba/connections", "POST", JSONObject().put("host", host).put("port", port.ifEmpty { "445" }).put("username", user).put("password", pass).toString(), timeout = 30.0)
    }
    suspend fun delConn(s: Settings, id: String) { get(s, "/v1/samba/connections/${enc(id)}", "DELETE", timeout = 20.0) }

    // ---------- Remote access (ZeroTier) ----------
    fun parseZt(d: Any?): ZZt? {
        val o = (d as? JSONObject) ?: (d as? JSONArray)?.optJSONObject(0) ?: return null
        val id = str(o, "id", "network_id", "nwid")
        return if (id.isEmpty()) null else ZZt(id, str(o, "name"), str(o, "status"))
    }
    suspend fun zt(s: Settings) = parseZt(get(s, "/v2/casaos/zt/info"))
    suspend fun setZt(s: Settings, id: String, online: Boolean) {
        get(s, "/v2/casaos/zt/${enc(id)}/status", "PUT", JSONObject().put("status", if (online) "online" else "offline").toString(), timeout = 20.0)
    }

    // ---------- Notifications ----------
    // /v2/users/events: [ { uuid, source_id, name, properties (a map, a JSON string of one, or [{name, value}]), timestamp (ms) } ]
    fun parseEvents(d: Any?): List<ZEvent> = arrOf(d, "list", "events").objs().map { e ->
        val props = HashMap<String, String>()
        var p: Any? = e.opt("properties")
        if (p is String) p = try { org.json.JSONTokener(p).nextValue() } catch (x: Exception) { null }
        when (p) {
            is JSONObject -> p.keys().forEach { k -> props[k] = p.optString(k) }
            is JSONArray -> p.objs().forEach { props[it.optString("name")] = it.optString("value") }
        }
        val name = str(e, "name")
        val title = props["casaos-ui:title"].orEmpty().ifEmpty { props["title"].orEmpty() }.ifEmpty {
            name.substringAfter(":").replace(':', ' ').replace('-', ' ').replace('_', ' ').trim().replaceFirstChar { it.uppercase() }
        }
        val msg = props["casaos-ui:message-1"].orEmpty().ifEmpty { props["message"].orEmpty() }.ifEmpty {
            props.filterKeys { !it.startsWith("casaos-ui:") }.entries.take(3).joinToString(" · ") { it.value }
        }
        var t = (num(e.opt("timestamp")) ?: 0.0).toLong()
        if (t in 1..99_999_999_999L) t *= 1000   // seconds
        ZEvent(str(e, "uuid", "event_uuid"), str(e, "source_id", "sourceID"), name, title, msg, t)
    }.filter { it.uuid.isNotEmpty() || it.title.isNotEmpty() }.sortedByDescending { it.time }

    suspend fun events(s: Settings) = parseEvents(get(s, "/v2/users/events"))
    suspend fun delEvent(s: Settings, uuid: String) { get(s, "/v2/users/event/${enc(uuid)}", "DELETE") }

    // ---------- App sources and app settings ----------
    fun parseSources(d: Any?) = arrOf(d, "list").objs().map { ZSource(str(it, "id"), str(it, "url")) }.filter { it.url.isNotEmpty() }
    suspend fun sources(s: Settings) = parseSources(get(s, "/v2/app_management/appstore"))
    suspend fun addSource(s: Settings, url: String) { get(s, "/v2/app_management/appstore?url=${enc(url)}", "POST", "", timeout = 120.0) }
    suspend fun delSource(s: Settings, id: String) { get(s, "/v2/app_management/appstore/${enc(id)}", "DELETE", timeout = 30.0) }

    fun parseGlobals(d: Any?) = arrOf(d, "list").objs().map { ZGlobal(str(it, "key"), it.optString("value"), str(it, "description")) }.filter { it.key.isNotEmpty() }
    suspend fun globals(s: Settings) = parseGlobals(get(s, "/v2/app_management/global"))
    suspend fun setGlobal(s: Settings, key: String, value: String) {
        get(s, "/v2/app_management/global/${enc(key)}", "PUT", JSONObject().put("key", key).put("value", value).toString())
    }
    suspend fun delGlobal(s: Settings, key: String) { get(s, "/v2/app_management/global/${enc(key)}", "DELETE") }

    // ---------- ZimaOS modules (Files, Backup, Photos ...) ----------
    fun parseModules(d: Any?) = arrOf(d, "list").objs().mapNotNull { m ->
        val ui = m.optJSONObject("ui")
        val name = str(m, "name")
        if (name.isEmpty()) return@mapNotNull null
        ZModule(name, Zima.locText(ui?.opt("title")).ifEmpty { Zima.locText(m.opt("title")) }.ifEmpty { name.replaceFirstChar { it.uppercase() } },
            ui?.optString("icon").orEmpty(), ui?.optString("entry").orEmpty())
    }
    suspend fun modules(s: Settings) = parseModules(get(s, "/v2/mod_management/modules"))

    // a module's page: entry is a path on the server ("/modules/files/") or a full address
    fun moduleUrl(m: ZModule, base: String) = when {
        m.entry.isEmpty() -> ""
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(m.entry) -> m.entry
        else -> base.trimEnd('/') + (if (m.entry.startsWith("/")) "" else "/") + m.entry
    }
    fun iconUrl(icon: String, base: String) = when {
        icon.isEmpty() -> ""
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(icon) -> icon
        else -> base.trimEnd('/') + (if (icon.startsWith("/")) "" else "/") + icon
    }

    // ---------- One app: details and its compose file ----------
    fun parseDetail(d: Any?, ctrs: Any?): ZAppDetail {
        val o = d as? JSONObject ?: JSONObject()
        val comp = o.optJSONObject("compose") ?: JSONObject()
        val svcs: List<JSONObject> = when (val sv = comp.opt("services")) {
            is JSONArray -> sv.objs()
            is JSONObject -> sv.keys().asSequence().mapNotNull { k -> sv.optJSONObject(k)?.also { if (!it.has("name")) it.put("name", k) } }.toList()
            else -> emptyList()
        }
        val ports = svcs.flatMap { sv ->
            arrOf(sv.opt("ports")).let { a -> (0 until a.length()).map { a.opt(it) } }.mapNotNull { p ->
                when (p) {
                    is JSONObject -> {
                        val pub = str(p, "published"); val tgt = str(p, "target"); val pr = str(p, "protocol").ifEmpty { "tcp" }
                        if (tgt.isEmpty()) null else (if (pub.isNotEmpty()) "$pub → $tgt" else tgt) + if (pr != "tcp") "/$pr" else ""
                    }
                    is String -> p.takeIf { it.isNotBlank() }
                    else -> null
                }
            }
        }.distinct()
        val folders = svcs.flatMap { sv ->
            arrOf(sv.opt("volumes")).let { a -> (0 until a.length()).map { a.opt(it) } }.mapNotNull { v ->
                when (v) {
                    is JSONObject -> { val src = str(v, "source"); val tgt = str(v, "target"); if (tgt.isEmpty()) null else if (src.isNotEmpty()) "$src → $tgt" else tgt }
                    is String -> v.takeIf { it.isNotBlank() }?.replaceFirst(":", " → ")
                    else -> null
                }
            }
        }.distinct()
        val env = svcs.flatMap { sv ->
            when (val e = sv.opt("environment")) {
                is JSONObject -> e.keys().asSequence().map { k -> k to (e.opt(k)?.takeIf { it != JSONObject.NULL }?.toString() ?: "") }.toList()
                is JSONArray -> (0 until e.length()).map { e.optString(it) }.map { it.substringBefore("=") to it.substringAfter("=", "") }
                else -> emptyList()
            }
        }.distinctBy { it.first }
        val images = svcs.mapNotNull { str(it, "image").takeIf { i -> i.isNotEmpty() } }.distinct()
        val co = ctrs as? JSONObject
        val list = co?.optJSONObject("containers")?.let { m -> m.keys().asSequence().mapNotNull { m.optJSONObject(it) }.toList() }
            ?: arrOf(ctrs, "containers").objs()
        val cs = list.map { c ->
            ZCtrInfo(str(c, "Name", "name", "Service").removePrefix("/"), str(c, "Image", "image"), str(c, "State", "state"), str(c, "Health", "health"))
        }
        return ZAppDetail(str(o, "status"), o.optBoolean("update_available", false), co?.optString("main").orEmpty(), cs, ports, folders, env, images)
    }

    suspend fun detail(s: Settings, app: String): ZAppDetail {
        val d = get(s, "/v2/app_management/compose/${enc(app)}", timeout = 15.0)
        val c = opt(s, "/v2/app_management/compose/${enc(app)}/containers")
        return parseDetail(d, c)
    }

    // The app's docker compose file (YAML), as ZimaOS keeps it
    suspend fun composeYaml(s: Settings, app: String): String {
        val r = Zima.call(s, "/v2/app_management/compose/${enc(app)}", timeout = 15.0, headers = mapOf("Accept" to "application/yaml"))!!
        if (r.code == 404) throw ZimaErr(NOT_OFFERED)
        if (r.code >= 400) Zima.data(r)
        var y = r.body
        if (y.trimStart().startsWith("{")) {
            val d = try { JSONObject(y).opt("data") } catch (e: Exception) { null }
            y = when {
                d is String -> d
                d is JSONObject && d.opt("compose") is String -> d.optString("compose")
                else -> throw ZimaErr("ZimaOS sent the settings as JSON, not as a compose file. Edit them in ZimaOS.")
            }
        }
        return y.replace("\r", "")
    }

    // Saves a changed compose file: ZimaOS recreates the app with it (its data stays)
    suspend fun saveCompose(s: Settings, app: String, yaml: String) {
        val r = Zima.call(s, "/v2/app_management/compose/${enc(app)}?check_port_conflict=false", "PUT", yaml, timeout = 300.0,
            headers = mapOf("Content-Type" to "application/yaml"), exactType = true, dropOk = true) ?: return
        if (r.code == 404 || r.code == 405) throw ZimaErr(NOT_OFFERED)
        Zima.data(r)
    }
}
